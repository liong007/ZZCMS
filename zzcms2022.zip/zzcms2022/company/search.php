<?php
require("../inc/conn.php");
require("../inc/fy.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("../inc/label.php");

$strout=read_tpl('company_search.htm');//读取模板文件
require("../inc/get_cs_search.php");//获取参数
$list=strbetween($strout,"{loop}","{/loop}");	

if ($c<>""){
$tables=$table.$cid;//这里有命名不要与showclass中的重名
	if(mysqli_num_rows(query("SHOW TABLES LIKE '".$tables."'"))<>1) {
	addtable($table,$cid);//加表
	}
}else{
$tables=$table;
}
	
$sql="select count(*) as total from `$tables` where  usersf='公司' and lockuser=0 and passed<>0  ";
$sql2='';
if ($keyword<>""){
$sql2=$sql2." and comane like '%".$keyword."%' ";
}
if ($province<>""){
$sql2=$sql2." and province='".$province."'";
}
if ($city<>""){
$sql2=$sql2." and city='".$city."'";
}
if ($xiancheng<>""){
$sql2=$sql2." and xiancheng='".$xiancheng."'";
}
//if ($c<>"") {
//$sql2=$sql2." and classid='".$cid."' ";
//}

if (@$renzheng<>"") {
$sql2=$sql2." and renzheng=1 ";
}
$rs =query($sql.$sql2); 
$row = fetch_array($rs);
$totlenum = $row['total'];
$offset=($page-1)*$page_size;//$page_size在上面被设为COOKIESS
$totlepage=ceil($totlenum/$page_size);
$sql="select * from `$tables` where passed=1 and usersf='公司' and lockuser=0 ";
$sql=$sql.$sql2;
$sql=$sql." order by groupid desc,elite desc,id desc limit $offset,$page_size";
//echo $sql;
$rs = query($sql); 
if(!$totlenum){
	$strout=str_replace("{loop}".$list."{/loop}","暂无信息",$strout) ;
	$strout=str_replace("{#fenyei}","",$strout) ;
}else{
$list2="";
$i=0;
while($row= fetch_array($rs)){
if (sdomain=="Yes"){
$zturl="http://".$row["username"].".".substr(siteurl,strpos(siteurl,".")+1);
}else{
$zturl=getpageurl_zt("zhanting",$row["id"]);
}

$rsn=query("select grouppic,groupname from zzcms_usergroup where groupid=".$row["groupid"]."");
$rown=fetch_array($rsn);
$usergrouppic=$rown["grouppic"];
$usergroupname=$rown["groupname"];

$usergroup="<img src='".$usergrouppic."' alt='".$usergroupname."'>";
if ($row["renzheng"]==1) {
$usergroup=$usergroup."<img src='/image/ico_renzheng.png' alt='认证会员'>";
}

$rsn=query("select xuhao,title,id from zzcms_zhaoshang where editor='".$row["username"]."' and passed=1 order by xuhao asc limit 0,3");
$rown=mysqli_num_rows($rsn);
$cp="";
if ($rown){
	while($rown=fetch_array($rsn)){
	$cp=$cp."<a href='".getpageurl("zhaoshang",$rown["id"])."'>".cutstr($rown["proname"],8)."</a>&nbsp;&nbsp;";
       } 
}else{
$cp="暂无产品";
}

if ($row["elite"]>0){
$list2 = $list2. str_replace("{#comane}" ,$row["comane"]." <img src='/image/ico_jian.png' title='推荐值：".$row["elite"]."'>",$list) ;
}else{
$list2 = $list2. str_replace("{#comane}" ,$row["comane"],$list) ;
}
$list2 =str_replace("{#zturl}" ,$zturl,$list2) ;
$list2 =str_replace("{#usergroup}" ,$usergroup,$list2) ;
$list2 =str_replace("{#address}" ,$row["address"],$list2) ;
$list2 =str_replace("{#phone}" ,$row["phone"],$list2) ;
$list2 =str_replace("{#title}" ,$cp,$list2) ;
$list2 =str_replace("{#imgbig}" ,$row["img"],$list2) ;		
$list2 =str_replace("{#img}" ,getsmallimg($row["img"]),$list2) ;	
$i=$i+1;
}
$strout=str_replace("{loop}".$list."{/loop}",$list2,$strout) ;
$strout=str_replace("{#fenyei}",showpage1("company"),$strout) ;
}

if ($province=="") {
$strout=str_replace("{#formprovince}",formprovince(),$strout);
}else{
$strout=str_replace("{#formprovince}","",$strout);
}
if ($city=="") {
$strout=str_replace("{#formcity}",formcity(),$strout);
}else{
$strout=str_replace("{#formcity}","",$strout);
}
$strout=str_replace("{#formxiancheng}",formxiancheng(),$strout);
$strout=str_replace("{#selected}",$selected,$strout);
$strout=str_replace("{#keyword}",$keyword,$strout);
$pagetitle=$province.companylisttitle.$classname.sitename;
$pagekeywords=$province.$classname.companylistkeyword;
$pagedescription=$province.$classname.companylistdescription;
require("../inc/replace_tpl.php");//替换模板中的变量标签
?>