<?php
require("../inc/conn.php");
require("../inc/fy.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("../inc/label.php");

$strout=read_tpl('company_list.htm');//读取模板文件
require("../inc/get_cs.php");//获取参数
if ($c<>""){
$tables=$table.$cid;//这里有命名不要与showclass中的重名
	if(mysqli_num_rows(query("SHOW TABLES LIKE '".$tables."'"))<>1) {
	addtable($table,$cid);//加表
	}
}else{
$tables=$table;
}
$clist=strbetween($strout,"{loop}","{/loop}");
$sql="select count(*) as total from `$tables` where  usersf='公司' and lockuser=0 and passed<>0  ";
$sql2='';

$rs =query($sql.$sql2); 
$row = fetch_array($rs);
$totlenum = $row['total'];
$offset=($page-1)*$page_size;//$page_size在上面被设为COOKIESS
$totlepage=ceil($totlenum/$page_size);

$sql="select * from `$tables` where passed=1 and usersf='公司' and lockuser=0 ";
$sql=$sql.$sql2;
$sql=$sql." order by groupid desc,elite desc,id desc limit $offset,$page_size";
$rs = query($sql); 
if(!$totlenum){
$strout=str_replace("{loop}".$clist."{/loop}","暂无信息",$strout) ;
$strout=str_replace("{#fenyei}","",$strout) ;
}else{
$i=0;
$clist2="";
while($row= fetch_array($rs)){
$zturl=getpageurlzt($row["username"],$row["id"]);

$rsn=query("select grouppic,groupname from zzcms_usergroup where groupid=".$row["groupid"]."");
$rown=fetch_array($rsn);
$usergrouppic=$rown["grouppic"];
$usergroupname=$rown["groupname"];

$usergroup="<img src='".$usergrouppic."' alt='".$usergroupname."' title='".$usergroupname."'>";
if ($row["renzheng"]==1) {
$usergroup=$usergroup."<img src='/image/ico_renzheng.png' alt='认证会员' title='认证会员'>";
}

$rsn=query("select xuhao,title,id from zzcms_zhaoshang where editor='".$row["username"]."' and passed=1 order by xuhao asc limit 0,3");
$rown=mysqli_num_rows($rsn);
$cp="";
if ($rown){
	while($rown=fetch_array($rsn)){
	$cp=$cp."<a href='".getpageurl("zhaoshang",$rown["id"])."'>".cutstr($rown["title"],8)."</a>&nbsp;&nbsp;";
       } 
}else{
$cp="暂无产品";
}

if ($row["elite"]>0){
$clist2 = $clist2. str_replace("{#comane}" ,$row["comane"]." <img src='/image/ico_jian.png' title='推荐值：".$row["elite"]."'>",$clist) ;
}else{
$clist2 = $clist2. str_replace("{#comane}" ,$row["comane"],$clist) ;
}
$clist2 =str_replace("{#zturl}" ,$zturl,$clist2) ;
$clist2 =str_replace("{#usergroup}" ,$usergroup,$clist2) ;
$clist2 =str_replace("{#address}" ,$row["address"],$clist2) ;
$clist2 =str_replace("{#phone}" ,$row["phone"],$clist2) ;
$clist2 =str_replace("{#title}" ,$cp,$clist2) ;
$clist2 =str_replace("{#imgbig}" ,$row["img"],$clist2) ;	
$clist2 =str_replace("{#img}" ,getsmallimg($row["img"]),$clist2) ;	
$i=$i+1;
}
$strout=str_replace("{loop}".$clist."{/loop}",$clist2,$strout) ;
$strout=str_replace("{#fenyei}",showpage2("company"),$strout) ;
}

$pagetitle=companylisttitle.$classname.sitename;
$pagekeywords=$classname.companylistkeyword;
$pagedescription=$classname.companylistdescription;
require("../inc/replace_tpl.php");//替换模板中的变量标签
?>