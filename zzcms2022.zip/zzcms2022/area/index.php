<?php
require("../inc/conn.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("../inc/label.php");
require("../inc/fly.php");
if (isset($_GET["province"])){$province=$_GET["province"];}else{$province="";}
$province_hz=trim(province_zm2hz($province));//省份名从记事本中的数组中读出的，得加trim去除去两端空白内容，否则无法从数据库中读取到内容

//$f=zzcmsroot."html/".$siteskin."/".$channel."/index.html";
//if (html_update_time!=0 && file_exists($f) && time()-filemtime($f)<3600*24*html_update_time) {
//echo file_get_contents($f);//第三种方法,这种比require("$f")打开速度要快很多
//}else{

$fp="../template/".$siteskin."/area_select.htm";
if (file_exists($fp)==false){tsmsg($fp.'模板文件不存在');exit;}
$f = fopen($fp,'r');
$strout = fread($f,filesize($fp));
fclose($f);
$strout=str_replace("{#siteskin}",$siteskin,$strout) ;
$strout=str_replace("{#sitename}",sitename,$strout) ;
$strout=str_replace("{#siteurl}",siteurl,$strout) ;
$strout=str_replace("{#pagetitle}",$province_hz.sitetitle,$strout);
$strout=str_replace("{#pagekeywords}",$province_hz.sitekeyword,$strout);
$strout=str_replace("{#pagedescription}",$province_hz.sitedescription,$strout);
$strout=str_replace("{#province}",province_all(),$strout) ;
$strout=str_replace("{#sitebottom}",sitebottom(),$strout);
$strout=str_replace("{#sitetop}",sitetop(),$strout);
$strout=showlabel($strout);
if (flyadisopen=="Yes") {
$strout=str_replace("{#flyad}",showflyad("首页","漂浮广告"),$strout);
}else{
$strout=str_replace("{#flyad}","",$strout);
}
if (duilianadisopen=="Yes"){
$strout=str_replace("{#duilianad}",showduilianad("首页","对联广告左侧","对联广告右侧"),$strout);
}else{
$strout=str_replace("{#duilianad}","",$strout);
}
echo  $strout;

//直接写到当前目录，直接打开
if (html_update_time!=0 ){
	$fpath="index.htm";
	$fp=@fopen($fpath,"w+");//fopen()的其它开关请参看相关函数
	fputs($fp,stripfxg($strout));//写入文件
	fclose($fp);
}

/* 统一写到html
if (html_update_time!=0 ){
	if (!file_exists(zzcmsroot."html/".$siteskin."/".$channel)) {
		mkdir(zzcmsroot."html/".$siteskin."/".$channel,0777, true);
	}
	$fpath=zzcmsroot."html/".$siteskin."/".$channel."/index.htm";
	$fp=@fopen($fpath,"w+");//fopen()的其它开关请参看相关函数
	fputs($fp,stripfxg($strout));//写入文件
	fclose($fp);
}
*/

//}
?>