<?php
require("../inc/conn.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("../inc/label.php");
require("sub.php");
require("../inc/get_cs_show.php");//获取参数
$sql="select * from zzcms_baojia where id='$id'";
$rs=query($sql);
$row=fetch_array($rs);
if (!$row){
echo showmsg("不存在相关信息！");
}else{
query("update zzcms_baojia set hit=hit+1 where id='$id'");
$cid=$row["classid"];
$title=$row["title"];
$province=$row["province"];
$city=$row["city"];
$xiancheng=$row["xiancheng"];
$sendtime=$row["sendtime"];
$price=$row["price"];
$danwei=$row["danwei"];
$truename=$row["truename"];
$address=$row["address"];
$tel=$row["tel"];

$pagetitle=$title."-".baojiashowtitle;
$pagekeywords=$title."-".baojiashowkeyword;
$pagedescription=$title."-".baojiashowdescription;

$showlx="<ul>";
$showlx=$showlx."<li>联系人：".$truename."</li>";
$showlx=$showlx."<li>地址：".$address."</li>";
$showlx=$showlx."<li>电话：".$tel."</li> ";
$showlx=$showlx." </ul> ";        
$strout=read_tpl('baojia_show.htm');//读取模板文件

$strout=str_replace("{#title}",$title,$strout);
$strout=str_replace("{#province}",$province,$strout);
$strout=str_replace("{#city}",$city,$strout);
$strout=str_replace("{#xiancheng}",$xiancheng,$strout);
$strout=str_replace("{#sendtime}",$sendtime,$strout);
$strout=str_replace("{#contact}",$showlx,$strout);
$strout=str_replace("{#price}",$price,$strout);
$strout=str_replace("{#danwei}",$danwei,$strout);

require("../inc/replace_tpl.php");//替换模板中的变量标签
}
?>