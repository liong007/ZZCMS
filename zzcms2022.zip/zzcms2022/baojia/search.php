<?php
require("../inc/conn.php");
require("../inc/fy.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("sub.php");
require("../inc/label.php");

require("../inc/get_cs_search.php");//获取参数
$strout=read_tpl("baojia_search.htm");//读取模板文件
require("../inc/get_list_search.php");//获取列表数据,并从模板中替换
$pagetitle=$province.$classname.baojialisttitle."-".sitename;
$pagekeywords=$province.$classname.baojialisttitle."-".sitename;
$pagedescription=$province.$classname.baojialistdescription."-".sitename;
require("../inc/replace_tpl.php");//替换模板中的变量标签	
?>