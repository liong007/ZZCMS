<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
<script language="javascript" src="../js/gg.js"></script>
<script language = "JavaScript">
function CheckForm(){
if (document.myform.classid.value==""){
    alert("请选择类别！");
	document.myform.classid.focus();
	return false;
  }
  if (document.myform.cpname.value==""){
    alert("名称不能为空！");
	document.myform.cpname.focus();
	return false;
}
}
</script>
</head>
<body> 
<?php 
if ($action=="add") {
?>
<div class="admintitle">发布品牌信息</div>
<form action="pp_edit.php?action=add" method="post" name="myform" id="myform" onSubmit="return CheckForm();">
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td width="15%" align="right" class="border">名称 <font color="#FF0000">*</font></td>
      <td width="85%" class="border"> <input name="cpname" type="text" id="cpname" value="" size="45"></td>
    </tr>
    <tr> 
      <td align="right" class="border"> 类别 <font color="#FF0000">*</font></td>
      <td class="border"><?php
        $rs=get_class_list("zzcms_zhaoshangclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==@$_COOKIE['pinpaiclassid']) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?></td>
    </tr>
	 
    <tr> 
      <td align="right" class="border">说明：</td>
      <td class="border"> <textarea name="content" cols="60" rows="5" id="content"></textarea></td>
    </tr>
    <tr> 
      <td align="right" class="border">图片： 
 <input name="img" type="hidden" id="img" value="/image/nopic.gif" size="45"></td>
      <td class="border"> <table height="120" border="0" cellpadding="5" cellspacing="1" bgcolor="#999999">
          <tr> 
            <td width="120" align="center" bgcolor="#FFFFFF" id="showimg" onClick="openwindow('/up/uploadimg_form.php',400,300)"> 
             <input name='Submit2' type='button'  value='上传图片'/>
			          </td>
          </tr>
        </table></td>
    </tr>
    <tr> 
      <td align="right" class="border">发布人：</td>
      <td class="border"><input name="editor" type="text" id="editor" value="<?php echo $_SESSION["admin"]?>" size="45"></td>
    </tr>
    <tr> 
      <td align="right" class="border">审核：</td>
      <td class="border"><label><input name="passed" type="checkbox" id="passed" value="1">
        （选中为通过审核） </label></td>
    </tr>
    
    <tr> 
      <td align="center" class="border">&nbsp;</td>
      <td class="border"><input type="submit" name="Submit" value="发布"></td>
    </tr>
  </table>
</form>
<?
}

if ($action=="modify") {
?>
<div class="admintitle">修改品牌信息</div>
<?php
//checkadminisdo("pp_modify");
$page = isset($_GET['page'])?$_GET['page']:1;
checkid($page);
$id = isset($_GET['id'])?$_GET['id']:0;
checkid($id,1);
$sql="select * from zzcms_pinpai where id='$id'";
$rs=query($sql);
$row=fetch_array($rs);
?>
<form action="pp_edit.php?action=modify" method="post" name="myform" id="myform" onSubmit="return CheckForm();">
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td width="15%" align="right" class="border">名称 <font color="#FF0000">*</font></td>
      <td width="85%" class="border"> <input name="cpname" type="text" id="cpname" value="<?php echo $row["title"]?>" size="45"></td>
    </tr>
    <tr> 
      <td align="right" class="border"> 类别 <font color="#FF0000">*</font></td>
      <td class="border"><?php
        $rs=get_class_list("zzcms_zhaoshangclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==$row["classid"]) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?></td>
    </tr>
	 
    <tr> 
      <td align="right" class="border">说明：</td>
      <td class="border"> <textarea name="content" cols="60" rows="5" id="content"><?php echo $row["content"]?></textarea></td>
    </tr>
    <tr> 
      <td align="right" class="border">图片： 
 <input name="img" type="hidden" id="img" value="<?php echo $row["img"]?>" size="45"></td>
      <td class="border"> <table height="120" border="0" cellpadding="5" cellspacing="1" bgcolor="#999999">
          <tr> 
            <td width="120" align="center" bgcolor="#FFFFFF" id="showimg" onClick="openwindow('/up/uploadimg_form.php',400,300)"> 
              <?php
				  if($row["img"]<>""){
				  echo "<img src='".$row["img"]."' border=0 width=120 /><br>点击可更换图片";
				  }else{
				  echo "<input name='Submit2' type='button'  value='上传图片'/>";
				  }
				  
				  ?>            </td>
          </tr>
        </table></td>
    </tr>
    <tr> 
      <td align="right" class="border">发布人：</td>
      <td class="border"><input name="editor" type="text" id="editor" value="<?php echo $row["editor"]?>" size="45"> 
        <input name="oldeditor" type="hidden" id="oldeditor" value="<?php echo $row["editor"]?>"></td>
    </tr>
    <tr> 
      <td align="right" class="border">审核：</td>
      <td class="border"><input name="passed" type="checkbox" id="passed" value="1"  <?php if ($row["passed"]==1) { echo "checked";}?>>
        （选中为通过审核） </td>
    </tr>
    
    <tr> 
      <td align="center" class="border">&nbsp;</td>
      <td class="border"><input name="id" type="hidden" value="<?php echo $row["id"]?>"> 
        <input name="sendtime" type="hidden" id="sendtime" value="<?php echo $row["sendtime"]?>"> 
        <input name="page" type="hidden" id="page" value="<?php echo $page?>">
        <input type="submit" name="Submit" value="修 改"></td>
    </tr>
  </table>
</form>
<?php
}

?>
</body>
</html>