<?php 
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<title></title>
<?php
checkadminisdo("label");
$action = isset($_REQUEST['action'])?$_REQUEST['action']:"";
$channel = isset($_GET['channel'])?$_GET['channel']:"";

$arr_tab=get_table();
$table=$arr_tab[0];

if ($action=="add") {
checkadminisdo("label_add");
$pic = isset($_POST['pic'])?$_POST['pic'][0]:0;
$flv = isset($_POST['flv'])?$_POST['flv'][0]:0;
$elite = isset($_POST['elite'])?$_POST['elite'][0]:0;
$saver = isset($_POST['saver'])?$_POST['saver'][0]:0;//代理用
if ($channel!='about'){
checkstr($numbers,'num','调用记录数');
}
checkstr($column,'num','列数');
$start=stripfxg($_POST["start"],true);
$mids=stripfxg($_POST["mids"],true);
$ends=stripfxg($_POST["ends"],true);
if ($title==''){echo 'title不能为空';exit;}//必须服务器端判断，如会建空文件：admin/labelshow.php?action=add&channel=zhaoshangshow
if (!file_exists("../template/".siteskin."/label/".$channel)) {mkdir("../template/".siteskin."/label/".$channel,0777,true);}
$f="../template/".siteskin."/label/".$channel."/".$title.".txt";
$fp=fopen($f,"w+");//fopen()的其它开关请参看相关函数
if ($channel=='zhaoshang'){
$str=$title ."|||".$cid ."|||" .$groupid."|||".$pic."|||".$flv ."|||".$elite ."|||" . $numbers ."|||".$orderby ."|||" .$column ."|||" .$start ."|||" .$mids. "|||".$ends;
}elseif($channel=='ask'){
$str=$title ."|||" .$cid ."|||".$pic ."|||".$elite."|||".$typeid ."|||" . $numbers ."|||" .$orderby ."|||" .$column . "|||" .$start ."|||" . $mids ."|||" . $ends;
}elseif($channel=='pinpai'){
$str=$title."|||".$cid."|||".$pic."|||".$numbers."|||".$orderby."|||" .$column."|||" .$start."|||" .$mids."|||" . $ends;
}elseif($channel=='zixun'|| $channel=='special'){
$str=$title."|||".$cid."|||".$pic."|||".$elite."|||".$numbers."|||" . $orderby ."|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}elseif($channel=='daili'){
$str=$title . "|||" .$cid . "|||" .$saver."|||" . $numbers . "|||" . $orderby ."|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}elseif($channel=='baojia'){
$str=$title . "|||" .$cid . "|||" . $numbers . "|||" . $orderby ."|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}elseif($channel=='job'){
$str=$title . "|||" .$cid ."|||" . $numbers . "|||" . $orderby ."|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}elseif($channel=='zhanhui'){
$str=$title . "|||" .$cid . "|||".$elite . "|||" . $numbers . "|||" . $orderby ."|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}elseif($channel=='wangkan'){
$str=$title . "|||" .$cid . "|||".$elite . "|||" . $numbers . "|||" . $orderby ."|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}elseif($channel=='link'){
$str=$title . "|||" .$cid . "|||".$pic ."|||".$elite . "|||" . $numbers . "|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}elseif($channel=='help'){
$str=$title . "|||".$elite . "|||" . $numbers . "|||" . $orderby ."|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}elseif($channel=='guestbook'){
$str=$title . "|||" . $numbers ."|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}elseif($channel=='company'){
$str=$title . "|||" .$cid . "|||".$groupid . "|||".$pic . "|||".$flv ."|||".$elite . "|||" . $numbers . "|||" . $orderby ."|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}elseif($channel=='about'){
$str=$title . "|||" .$id ."|||" . $column . "|||" . $start . "|||" . $mids . "|||" . $ends;
}

$isok=fputs($fp,$str);
fclose($fp);

if ($isok){
$title==$title_old ?$msg='修改成功':$msg='添加成功';
}else{
$msg="失败";
}

echo "<script>alert('".$msg."');location.href='?channel=".$channel."&labelname=".$title.".txt'</script>";
}

if ($action=="del") {
checkadminisdo("label_del");
$f="../template/".siteskin."/label/".$channel."/".safe_replace($_POST["title"]).".txt";
	if (file_exists($f)){
	unlink($f);
	}else{
	echo "<script>alert('请选择要删除的标签');history.back()</script>";
	}	
}
?>

<script language = "JavaScript">
function CheckForm(){
var re=/^[0-9a-zA-Z_]{1,20}$/; //只输入数字和字母的正则
if (document.myform.title.value==""){
    alert("标签名称不能为空！");
	document.myform.title.focus();
	return false;
  }
if(document.myform.title.value.search(re)==-1)  {
    alert("标签名称只能用字母，数字，_ 。且长度小于20个字符！");
	document.myform.title.focus();
	return false;
  }  
if (document.myform.cid.value=="") {
    alert("请选择类别！");
	document.myform.cid.focus();
	return false;
  } 
}  

</script>
</head>
<body>
<div class="admintitle"><?php echo $channel?>内容标签</div>
<form action="" method="post" name="myform" id="myform" onSubmit="return CheckForm();">        
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td width="150" align="right" class="border" >现有标签</td>
      <td class="border" >
	  <div class="boxlink"> 
        <?php
$labelname="";
if (isset($_GET['labelname'])){
$labelname=$_GET['labelname'];
if (substr($labelname,-3)!='txt'){
showmsg('只能是txt这种格式');//防止直接输入php 文件地址显示PHP代码
}
}
if (file_exists("../template/".siteskin."/label/".$channel."")==false){
echo '文件不存在';
}else{			
$dir = opendir("../template/".siteskin."/label/".$channel."");
while(($file = readdir($dir))!=false){
	if ($file!="." && $file!="..") { //不读取. ..
    //$f = explode('.', $file);//用$f[0]可只取文件名不取后缀。
		if ($labelname==$file){
  		echo "<li><a href='?channel=".$channel."&labelname=".$file."' style='color:#000000;background-color:#FFFFFF'>".$file."</a></li>";
		}else{
		echo "<li><a href='?channel=".$channel."&labelname=".$file."'>".$file."</a></li>";
		}
	} 
}
closedir($dir);	  
}	
$title='';$id='';$cid='';$groupid='';$pic='';$flv='';$elite='';$typeid='';$saver='';$numbers='';$orderby='';$column='';$start='';$mids='';$ends='';	
//读取现有标签中的内容
if (isset($_REQUEST["labelname"])){
$fp="../template/".siteskin."/label/".$channel."/".$labelname;
$fcontent=file_get_contents($fp);
$fcontent=removeBOM($fcontent);//去除BOM信息，使修改时不用再重写标签名
$f=explode("|||",$fcontent) ;
if ($channel=='zhaoshang'){
$title=$f[0];$cid=$f[1];$groupid=$f[2];$pic=$f[3];$flv=$f[4];$elite=$f[5];$numbers=$f[6];$orderby=$f[7];$column=$f[8];$start=$f[9];$mids=$f[10];$ends=$f[11];	
}elseif($channel=='ask'){
$title=$f[0];$cid=$f[1];$pic=$f[2];$elite=$f[3];$typeid=$f[4];$numbers=$f[5];$orderby=$f[6];$column=$f[7];$start=$f[8];$mids=$f[9];$ends=$f[10];
}elseif($channel=='pinpai'){
$title=$f[0];$cid=$f[1];$pic=$f[2];$numbers=$f[3];$orderby=$f[4];$column=$f[5];$start=$f[6];$mids=$f[7];$ends=$f[8];
}elseif($channel=='zixun'|| $channel=='special'){
$title=$f[0];$cid=$f[1];$pic=$f[2];$elite=$f[3];$numbers=$f[4];$orderby=$f[5];$column=$f[6];$start=$f[7];$mids=$f[8];$ends=$f[9];
}elseif($channel=='daili'){
$title=$f[0];$cid=$f[1];$saver=$f[2];$numbers=$f[3];$orderby=$f[4];$column=$f[5];$start=$f[6];$mids=$f[7];$ends=$f[8];
}elseif($channel=='baojia'){
$title=$f[0];$cid=$f[1];$numbers=$f[2];$orderby=$f[3];$column=$f[4];$start=$f[5];$mids=$f[6];$ends=$f[7];
}elseif($channel=='job'){
$title=$f[0];$cid=$f[1];$numbers=$f[2];$orderby=$f[3];$column=$f[4];$start=$f[5];$mids=$f[6];$ends=$f[7];
}elseif($channel=='zhanhui'){
$title=$f[0];$cid=$f[1];$elite=$f[2];$numbers=$f[3];$orderby=$f[4];$column=$f[5];$start=$f[6];$mids=$f[7];$ends=$f[8];
}elseif($channel=='wangkan'){
$title=$f[0];$cid=$f[1];$elite=$f[2];$numbers=$f[3];$orderby=$f[4];$column=$f[5];$start=$f[6];$mids=$f[7];$ends=$f[8];	
}elseif($channel=='link'){
$title=$f[0];$cid=$f[1];$pic=$f[2];$elite=$f[3];$numbers=$f[4];$column=$f[5];$start=$f[6];$mids=$f[7];$ends=$f[8];	
}elseif($channel=='help'){
$title=$f[0];$elite=$f[1];$numbers=$f[2];$orderby=$f[3];$column=$f[4];$start=$f[5];$mids=$f[6];$ends=$f[7];	
}elseif($channel=='guestbook'){
$title=$f[0];$numbers=$f[1];$column=$f[2];$start=$f[3];$mids=$f[4];$ends=$f[5];	
}elseif($channel=='company'){
$title=$f[0];$cid=$f[1];$groupid=$f[2];$pic=$f[3];$flv=$f[4];$elite=$f[5];$numbers=$f[6];$orderby=$f[7];$column=$f[8];$start=$f[9];$mids=$f[10];$ends=$f[11];	
}elseif($channel=='about'){
$title=$f[0];$id=$f[1];$column=$f[2];$start=$f[3];$mids=$f[4];$ends=$f[5];
}

} 
	   ?>
	   </div>      </td>
    </tr>
    <tr> 
      <td align="right" class="border" >标签名称</td>
      <td class="border" >
<input name="title" type="text" id="title" value="<?php echo $title?>" size="50" maxlength="255">
<input name="title_old" type="hidden" id="title_old" value="<?php echo $title?>" size="50" maxlength="255">      </td>
    </tr>
    <tr> 
      <td align="right" class="border" >调用内容</td>
      <td class="border" >   
<?php 
if ($channel!='about'&&$channel!='guestbook'&&$channel!='help'){

        $rs=get_class_list($table);
        $str="<select name='cid' id='cid'>";
		$str.="<option value=0>".str_repeat('&nbsp;',8)."不指定类别</option>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==$cid) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
}

		if ($channel=='zhaoshang'||$channel=='company'){
		?>
		<select name="groupid">
		 <option value="0" >所的会员</option>
          <?php
			$rsn=query("select groupid,groupname from zzcms_usergroup order by groupid asc");
			$r=num_rows($rsn);
			if ($r){
			while ($r=fetch_array($rsn)){
				if ($r["groupid"]==$groupid){
			 	echo "<option value='".$r["groupid"]."' selected>".$r["groupname"]."</option>";
				}else{
				echo "<option value='".$r["groupid"]."' >".$r["groupname"]."</option>";
				}
			}
			}
			?>
        </select>
		<?php
		}
		if ($channel=='zhaoshang' ||$channel=='company'||$channel=='pinpai'||$channel=='zixun'||$channel=='special'||$channel=='link'){
		?>
        <label><input name="pic[]" type="checkbox" id="pic" value="1" <?php if ($pic==1){ echo " checked";}?>>
        有图片的 </label>
		<?php
		}
		if ($channel=='zhaoshang'||$channel=='company'){
		?>
        <label><input name="flv[]" type="checkbox" id="flv[]" value="1" <?php if ($flv==1){ echo " checked";}?>>
        有视频的 </label> 
		<?php
		}
		if ($channel=='zhaoshang'||$channel=='company'||$channel=='zixun'||$channel=='zhanhui'||$channel=='special'||$channel=='wangkan'||$channel=='link'||$channel=='help'){
		?>
        <label><input name="elite[]" type="checkbox" id="elite" value="1" <?php if ($elite==1) { echo " checked";}?>>
        推荐的 </label> 
		<?php
		}
		if ($channel=='ask'){
		?>
		
		  <select name="typeid" id="typeid">
		 <option value="999">问题类型</option>
		  <option value="999" <?php if ($typeid==999) { echo "selected";}?>>全部</option>
          <option value="1" <?php if ($typeid==1) { echo "selected";}?>>已解决</option>
          <option value="0" <?php if ($typeid==0) { echo "selected";} ?>>待解决</option>
        </select>
		<?php
		}
		if ($channel=='daili'){
		?>
		   <label><input name="saver[]" type="checkbox" id="saver" value="1" <?php if ($saver==1){ echo " checked";}?>>
只调用<?php channeldl?>留言 </label>
		<?php
		}
		if ($channel=='about'){
		?>
		<select name="id">
          <option value="0" selected>调用全部</option>
          <?php
       $sql = "select id,title from zzcms_about order by id desc";
       $rs=query($sql);
		   while($r=fetch_array($rs)){
			?>
          <option value="<?php echo $r["id"]?>" <?php if ($r["id"]==$id) { echo "selected";}?>> 
          <?php echo $r["title"]?></option>
          <?php   
    	     }	
		 ?>
        </select>
		<?php
		}
		?>		</td>
    </tr>
	 <?php
		if ($channel!='about'){
		?>
    <tr> 
      <td align="right" class="border" >调用记录条数</td>
      <td class="border" >
	  <input name="numbers" type="text"  value="<?php echo $numbers?>" size="10" maxlength="255">      </td>
    </tr>
	  <?php
		}
		?>
    <tr> 
      <td align="right" class="border" >排序方式设置</td>
      <td class="border" > <select name="orderby" id="orderby">
          <option value="id" <?php if ($orderby=="id") { echo "selected";}?>>最新发布</option>
		   <option value="sendtime" <?php if ($orderby=="sendtime") { echo "selected";} ?>>最近更新</option>
          <option value="hit" <?php if ($orderby=="hit") { echo "selected";}?>>最多点击</option>
        <option value="rand" <?php if ($orderby=="rand") { echo "selected";}?>>随机显示</option>
		</select></td>
    </tr>
	
    <tr> 
      <td align="right" class="border" >列数</td>
      <td class="border" > <input name="column" type="text" id="column" value="<?php echo $column?>" size="20" maxlength="255">
        （分几列显示）</td>
    </tr>
    <tr> 
      <td align="right" class="border" >解释（开始）</td>
      <td class="border" ><textarea name="start" cols="100" rows="6" id="start" style="width:100%"><?php echo $start?></textarea></td>
    </tr>
    <tr> 
      <td align="right" class="border" >解释（循环）</td>
      <td class="border" ><textarea name="mids" cols="100" rows="6" id="mids" style="width:100%"><?php echo $mids ?></textarea>      </td>
    </tr>
    <tr> 
      <td align="right" class="border" >解释（结束）</td>
      <td class="border" ><textarea name="ends" cols="100" rows="6" id="ends" style="width:100%"><?php echo $ends ?></textarea></td>
    </tr>
    <tr> 
      <td align="right" class="border" >&nbsp;</td>
      <td class="border" > <input type="submit" name="Submit" value="添加/修改" onClick="myform.action='?action=add&channel=<?php echo $channel?>'"> 
        <input type="submit" name="Submit2" value="删除选中的标签" onClick="myform.action='?action=del&channel=<?php echo $channel?>'"></td>
    </tr>
  </table>
</form>		  
</body>
</html>