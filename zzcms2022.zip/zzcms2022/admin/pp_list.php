<?php
require("admin.php");
require("../inc/fy.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="/js/gg.js"></script>
<?php
checkadminisdo("pp");
require("get_cs_list.php");
$table='zzcms_pinpai';
require("../inc/pass.php");
?>
</head>
<body>
<div class="admintitle">品牌信息管理
<span>
<form name="form1" method="post" action="?">
        <input type="radio" name="kind" value="editor" <?php if ($kind=="editor") { echo "checked";}?>>
        按发布人 
        <input type="radio" name="kind" value="ppname" <?php if ($kind=="ppname") { echo "checked";}?>>
        按名称 
        <input name="keyword" type="text" id="keyword" size="25" value="<?php echo  $keyword?>">
        <input type="submit" name="Submit" value="查寻">
</form>
</span>
<input name="submit3" type="submit" class="buttons" onClick="javascript:location.href='pp.php?action=add'" value="发布品牌信息">
</div>
<div class="border2">
    <?php	
echo c('zzcms_zhaoshangclass',$b);
 ?>		  
</div>
        
<?php
$page_size=pagesize_ht;  //每页多少条数据
$offset=($page-1)*$page_size;
$sql="select count(*) as total from zzcms_pinpai where (1=1) ";
$sql2='';
if ($shenhe=="no") {  		
$sql2=$sql2." and passed=0 ";
}

if ($b<>'') {
$bidsNew=displaylist('zzcms_zhaoshangclass',$_GET['b']);
setcookie("bids",$bidsNew,time()+3600*24,"admin");
$bids=$bidsNew;
}else{
$bids=isset($_COOKIE['bids'])?$_COOKIE['bids']:'';
}

if ($b<>'') {
$sql2=$sql2." and classid in ($bids)";
}

if ($keyword<>"") {
	switch ($kind){
	case "editor";
	$sql2=$sql2. " and editor like '%".$keyword."%' ";
	break;
	case "ppname";
	$sql2=$sql2. " and title like '%".$keyword."%'";
	break;
	default:
	$sql2=$sql2. " and editor like '%".$keyword."%'";
	}
}

$rs =query($sql.$sql2); 
$row = fetch_array($rs);
$totlenum = $row['total'];  
$totlepage=ceil($totlenum/$page_size);

$sql="select * from zzcms_pinpai where (1=1) ";
$sql=$sql.$sql2;
$sql=$sql . " order by id desc limit $offset,$page_size";
$rs = query($sql); 
if(!$totlenum){
echo "暂无信息";
}else{
//echo $sql;
?>
<form name="myform" id="myform" method="post" action="" onSubmit="return anyCheck(this.form)">
  <table width="100%" border="0" cellpadding="5" cellspacing="1" class="bgcolor2">
    <tr class="trtitle"> 
      <td width="5%" height="25" align="center"><label for="chkAll" style="cursor: pointer;">全选</label></td>
      <td width="5%" height="25" align="center">图片</td>
      <td width="10%" height="25" align="center">名称</td>
      <td width="10%" align="center">类别</td>
      <td width="10%" height="25" align="center">发布人</td>
      <td width="10%" align="center">发布时间</td>
      <td width="5%" align="center">信息状态</td>
      <td width="5%" align="center">操作</td>
    </tr>
<?php
while($row = fetch_array($rs)){
?>
    <tr class="trcontent"> 
      <td align="center" class="docolor"> <input name="id[]" type="checkbox" id="id2" value="<?php echo $row["id"]?>"></td>
      <td align="center" ><a href="<?php echo $row["img"]?>" target="_blank"><img src="<?php echo getsmallimg($row['img'])?>" width="60"></a></td>
      <td align="center" ><a href="<?php echo getpageurl("pinpai",$row["id"]) ?>" target="_blank"><?php  echo $row["title"]?></a></td>
      <td align="center"><?php echo "<a href=?b=".$row['classid'].">" .getclassname('zzcms_zhaoshangclass',$row["classid"])."</a>"; ?></td>
      <td align="center"><a href="usermanage.php?keyword=<?php echo $row["editor"]?>" ><?php echo $row["editor"]?></a><br>userid:<?php echo $row["userid"]?></td>
      <td align="center" title="<?php echo $row["sendtime"]?>"><?php echo date("Y-m-d",strtotime($row["sendtime"]))?></td>
      <td align="center">
	   <?php if ($row["passed"]==1) { echo "已审核";} else {echo "<font color=red>未审核</font>";}?>      </td>
      <td align="center" class="docolor"><a href="pp.php?action=modify&id=<?php echo $row["id"] ?>&page=<?php echo $page ?>">修改</a></td> 
    </tr>
 <?php
 }
 ?>
  </table>
  <div class="border"> <input name="chkAll" type="checkbox" id="chkAll" onClick="CheckAll(this.form)" value="checkbox">
        <label for="chkAll" style="cursor: pointer;">全选</label> 
        <input type="submit" onClick="myform.action='?action=pass'" value="【取消/审核】选中的信息"> 
        <input type="submit" onClick="myform.action='del.php';myform.target='_self';return ConfirmDel()" value="删除选中的信息">
      <input name="pagename" type="hidden"  value="pp_list.php?b=<?php echo $b?>&shenhe=<?php echo $shenhe?>&page=<?php echo $page ?>">
      <input name="tablename" type="hidden"  value="zzcms_pinpai">
  </div>
</form>
<div class="border center"><?php echo showpage_admin()?></div>
<?php
}
?>
</body>
</html>