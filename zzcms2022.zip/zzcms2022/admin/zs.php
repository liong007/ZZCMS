<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
<script language="javascript" src="../js/timer.js"></script>
<script language = "JavaScript" src="../js/gg.js"></script>
<script type="text/javascript" src="../js/jquery.js"></script>  
<script language="javascript">  
$(document).ready(function(){  
  $("#classid").change(function() { //jquery 中change()函数  
	$("#quote").load(encodeURI("../ajax/shuxing_ajax.php?id="+$("#classid").val()));//jqueryajax中load()函数 加encodeURI，否则IE下无法识别中文参数 
  });  
});  

function CheckForm(){
if (document.myform.classid.value==""){
    alert("请选择产品类别！");
	return false;
  }
  if (document.myform.proname.value==""){
    alert("产品名称不能为空！");
	document.myform.proname.focus();
	return false;
  }
  if (document.myform.prouse.value==""){
    alert("产品特点不能为空！");
	document.myform.prouse.focus();
	return false;
  } 
	document.getElementById('loading').style.display='block'   
}
</script>  
</head>
<body>

<?php 
if ($action=="add") {
?>
<div class="admintitle">添加<?php echo channelzs?>信息</div>
<form action="zs_edit.php?action=add" method="post" name="myform" id="myform" onSubmit="return CheckForm();">
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr>
      <td align="right" class="border"> 所属类别</td>
      <td class="border"><?php
        $rs=get_class_list("zzcms_zhaoshangclass");
        $str="<select name='classid' id='classid'>";
		$str.="<option value=0>请选择类别</option>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==@$_COOKIE['zsclassid']) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?>
      </td>
    </tr>
    <tr> 
      <td width="15%" align="right" class="border">产品名称</td>
      <td width="82%" class="border"> <input name="proname" type="text" id="proname" value="" size="45" maxlength="50"></td>
    </tr>
	  
    <tr> 
      <td align="right" class="border">产品特点</td>
      <td class="border"> <textarea name="prouse" cols="60" rows="3" id="prouse"></textarea></td>
    </tr>
	<tr>
	 <td align="right" class="border">属性</td>
      <td class="border"><span id="quote">
	  
	  <?php 
if(isset($_COOKIE['zsclassid'])){
	$sql="select * from zzcms_shuxing where classid='". $_COOKIE['zsclassid'] ."'";
	$rs=query($sql);
	?>
	<table>
	<?php
	while ($row=fetch_array($rs)){
	?>
	<tr>
      <td align="right" class="border" > <?php echo $row["sxname"]?></td>
      <td class="border" >
	   <?php
	   if ($row["sxz"]<>''){
	   ?>
	   <select name='sx[]'>
	    <?php
	   $shuxing_value = explode("|",$row["sxz"]);
	for ($i=0; $i< count($shuxing_value);$i++){
	  ?>
	  <option value="<?php echo $shuxing_value[$i]?>"><?php echo $shuxing_value[$i]?></option>
	  <?php
	  }
	   ?>
	  </select>
	   <?php
	  }else{
	   ?>
	  <input name="sx[]" type="text" value="" size="45">
	   <?php
	 }
	   ?>
	  
	  </td>
    </tr>
	<?php
	}
?> 
</table>
<?php
	}
?> 
	  </span></td>
	</tr>

    <tr> 
      <td align="right" class="border">产品说明</td>
      <td class="border"> 
	  <textarea name="sm" id="sm"></textarea> 
             <script type="text/javascript" src="/3/ckeditor/ckeditor.js"></script>
			  <script type="text/javascript">CKEDITOR.replace('sm');</script>	  </td>
    </tr>
    <tr> 
      <td align="right" class="border">图片地址 
        <input name="img" type="hidden" id="img" value="/image/nopic.gif" size="45"> </td>
      <td class="border"> <table height="140"  width="140" border="0" cellpadding="5" cellspacing="1" bgcolor="#999999">
          <tr> 
            <td align="center" bgcolor="#FFFFFF" id="showimg" onClick="openwindow('/up/uploadimg_form.php',400,300)"> 
              <input name='Submit2' type='button'  value='上传图片'/>			            </td>
          </tr>
        </table></td>
    </tr>
    <tr> 
      <td align="right" class="border">视频地址</td>
      <td class="border"> <input name="flv" type="text" id="flv" value="" size="60"></td>
    </tr>
    <tr> 
      <td align="right" class="border">可提供的支持</td>
      <td class="border"> <textarea name="zc" cols="60" rows="3" id="zc"></textarea>      </td>
    </tr>
    <tr> 
      <td align="right" class="border">对<?php echo channeldl?>商的要求</td>
      <td class="border"> <textarea name="yq" cols="60" rows="3" id="yq"></textarea>      </td>
    </tr>
    <tr> 
      <td align="right" class="border">发布人</td>
      <td class="border"><input name="editor" type="text" id="editor" value="<?php echo $_SESSION['admin']?>" size="45"> </td>
    </tr>
    <tr> 
      <td align="right" class="border">审核</td>
      <td class="border"><input name="passed" type="checkbox" id="passed" value="1">
        （选中为通过审核） </td>
    </tr>
    <tr>
      <td align="right" class="border">&nbsp;</td>
      <td class="border"><input type="submit" name="Submit22" value="添加" class="buttons"></td>
    </tr>
	 <tr> 
      <td colspan="2" class="userbar">SEO设置</td>
    </tr>
    <tr>
      <td align="right" class="border" >标题（title）</td>
      <td class="border" ><input name="title" type="text" id="title" value="" size="60" maxlength="255"></td>
    </tr>
    <tr>
      <td align="right" class="border" >关键词（keywords）</td>
      <td class="border" ><input name="keywords" type="text" id="keywords" value="" size="60" maxlength="255">
        (多个关键词以“,”隔开)</td>
    </tr>
    <tr>
      <td align="right" class="border" >描述（description）</td>
      <td class="border" ><input name="description" type="text" id="description" value="" size="60" maxlength="255">
        (适当出现关键词，最好是完整的句子)</td>
    </tr>
    <tr> 
      <td align="right" class="border">&nbsp;</td>
      <td class="border"><input type="submit" name="Submit2" value="添加" class="buttons"></td>
    </tr>
    <tr> 
      <td colspan="2" class="userbar">排名（推荐）设置，在这里设置，不会扣除用户的积分</td>
    </tr>
    <tr> 
      <td align="right" class="border">排名到期时间</td>
      <td class="border"><input name="eliteendtime" type="text" value="<?php echo date('Y-m-d H:i:s')?>" size="20" onFocus="JTC.setday(this)" autocomplete="off">      </td>
    </tr>
    <tr>
      <td align="right" class="border" >积分/天</td>
      <td class="border" ><input name="elite" type="text" id="elite" class="biaodan" value="" size="10" maxlength="20">
        （设值范围为0-127，0为取消排名，积分高的排名靠前）</td>
    </tr>
    <tr> 
      <td align="right" class="border">搜索热门词</td>
      <td class="border"><input name="tag" type="text" id="tag" value="" size="45">
        (多个词可用 , 隔开) </td>
    </tr>
    <tr>
      <td colspan="2" class="userbar">模板选择</td>
    </tr>
	  <tr>
            <td align="right" class="border" >模板</td>
            <td class="border" >
              <label><input type="radio" name="skin" value="cp" id="cp" />
              产品型</label>
              <label><input type="radio" name="skin" value="xm" id="xm" />
              项目型</label>            </td>
    </tr>
	  <tr>
        <td align="right" class="border">外链地址</td>
	    <td class="border"><input name="link" type="text" id="link" value="" size="45"></td>
    </tr>
	  <tr id="trquanxian">
        <td colspan="2" class="userbar" >浏览权限设置</td>
    </tr>
	  <tr id="trquanxian2">
        <td align="right" class="border" >&nbsp;</td>
	    <td class="border" ><select name="groupid_guest" class="biaodan">
            <option value="0">全部用户</option>
            <?php
		  $rs_groupid=query("Select groupid,groupname from zzcms_usergroup ");
		  while($row_groupid = fetch_array($rs_groupid)){
			echo "<option value='".$row_groupid["groupid"]."'>".$row_groupid["groupname"]."</option>";
		  } 
	 ?>
          </select>
            <select name="jifen" id="jifen" class="biaodan">
              <option value="0">请选择无权限用户是否可用积分查看</option>
              <option value="0" >无权限用户不可用积分查看</option>
              <option value="1" >付我1积分可查看</option>
              <option value="2" >付我2积分可查看</option>
              <option value="5">付我5积分可查看</option>
              <option value="10">付我10积分可查看</option>
              <option value="20">付我20积分可查看</option>
              <option value="30" >付我30积分可查看</option>
              <option value="50">付我50积分可查看</option>
              <option value="100">付我100积分可查看</option>
            </select>        </td>
    </tr>	  
    <tr> 
      <td align="center" class="border">&nbsp;</td>
      <td class="border"><input type="submit" name="Submit" value="添加" class="buttons"></td>
    </tr>
  </table>
</form>

<?php
}

if ($action=="modify") {
?>
<div class="admintitle">修改<?php echo channelzs?>信息</div>
<?php
checkadminisdo("zs_modify");
$page=isset($_GET["page"])?$_GET["page"]:1;
checkid($page);
$id=isset($_GET["id"])?$_GET["id"]:0;
checkid($id,1);

$sql="select * from zzcms_zhaoshang where id='$id'";
$rs=query($sql);
$row=fetch_array($rs);
?>
<form action="zs_edit.php?action=modify" method="post" name="myform" id="myform" onSubmit="return CheckForm();">
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr>
      <td align="right" class="border"> 所属类别</td>
      <td class="border"><?php
        $rs=get_class_list("zzcms_zhaoshangclass");
        $str="<select name='classid' id='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==$row["classid"]) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?></td>
    </tr>
    <tr> 
      <td width="15%" align="right" class="border">产品名称</td>
      <td width="82%" class="border"> <input name="proname" type="text" id="proname" value="<?php echo $row["title"]?>" size="45" maxlength="50"> </td>
    </tr>
	  
    <tr> 
      <td align="right" class="border">产品特点</td>
      <td class="border"> <textarea name="prouse" cols="60" rows="3" id="prouse"><?php echo stripfxg($row["prouse"])?></textarea>      </td>
    </tr>
   
	<tr>
      <td align="right" class="border" >属性</td>
      <td class="border" >
	  <span id="quote">
	   <?php 
$shuxing_value = explode("|||",$row["shuxing_value"]);
	$sqln="select * from zzcms_shuxing where classid='". $row["classid"] ."'";
	$rsn=query($sqln);
	?>
	<table>
	<?php
	$i=0;
	while ($rown=fetch_array($rsn)){
	?>
	<tr>
      <td align="right" class="border" > <?php echo $rown["sxname"]?></td>
      <td class="border" >
	  
	   <?php
	   if ($rown["sxz"]<>''){
	   ?>
	   <select name='sx[]'>
	    <?php
	   $sxz = explode("|",$rown["sxz"]);
	   $sxz_num=count($sxz);
	for ($n=0; $n< $sxz_num;$n++){
	  ?>
	  <option value="<?php echo $sxz[$n]?>"  <?php if ($sxz[$n]==$shuxing_value[$i]){echo 'selected';}?>><?php echo $sxz[$n]?></option>
	  <?php
	  }
	   ?>
	  </select>
	   <?php
	  }else{
	   ?>
	  <input name="sx[]" type="text" value="<?php echo $shuxing_value[$i]?>" size="45">
	   <?php
	 }
	   ?>
	  
	  </td>
    </tr>
	<?php
	$i++;
	}
?> 
</table>
</span> </td>
	</tr>

    <tr> 
      <td align="right" class="border">产品说明</td>
      <td class="border"> 
	  <textarea name="sm" id="sm"><?php echo stripfxg($row["sm"]) ?></textarea> 
             <script type="text/javascript" src="/3/ckeditor/ckeditor.js"></script>
			  <script type="text/javascript">CKEDITOR.replace('sm');</script>	  </td>
    </tr>
    <tr> 
      <td align="right" class="border">图片地址 
        <input name="img" type="hidden" id="img" value="<?php echo $row["img"]?>" size="45"> </td>
      <td class="border"> <table height="140"  width="140" border="0" cellpadding="5" cellspacing="1" bgcolor="#999999">
          <tr> 
            <td align="center" bgcolor="#FFFFFF" id="showimg" onClick="openwindow('/up/uploadimg_form.php',400,300)"> 
              <?php
				  if($row["img"]<>""){
				  echo "<img src='".$row["img"]."' border=0 width=120 /><br>点击可更换图片";
				  }else{
				  echo "<input name='Submit2' type='button'  value='上传图片'/>";
				  }
				  ?>            </td>
          </tr>
        </table></td>
    </tr>
    <tr> 
      <td align="right" class="border">视频地址</td>
      <td class="border"> <input name="flv" type="text" id="flv" value="<?php echo $row["flv"]?>" size="60"></td>
    </tr>
    <tr> 
      <td align="right" class="border">可提供的支持</td>
      <td class="border"> <textarea name="zc" cols="60" rows="3" id="zc"><?php echo stripfxg($row["zc"])?></textarea>      </td>
    </tr>
    <tr> 
      <td align="right" class="border">对<?php echo channeldl?>商的要求</td>
      <td class="border"> <textarea name="yq" cols="60" rows="3" id="yq"><?php echo stripfxg($row["yq"])?></textarea>      </td>
    </tr>
    <tr> 
      <td align="right" class="border">发布人</td>
      <td class="border"><input name="editor" type="text" id="editor" value="<?php echo $row["editor"]?>" size="45"> 
        <input name="oldeditor" type="hidden" id="oldeditor" value="<?php echo $row["editor"]?>"></td>
    </tr>
    <tr> 
      <td align="right" class="border">审核</td>
      <td class="border"><input name="passed" type="checkbox" id="passed" value="1"  <?php if ($row["passed"]==1) { echo "checked";}?>>
        （选中为通过审核） </td>
    </tr>
    <tr>
      <td align="right" class="border">&nbsp;</td>
      <td class="border"><input type="submit" name="Submit22" value="修 改" class="buttons"></td>
    </tr>
	 <tr> 
      <td colspan="2" class="userbar">SEO设置</td>
    </tr>
    <tr>
      <td align="right" class="border" >标题（title）</td>
      <td class="border" ><input name="title" type="text" id="title" value="<?php echo $row["titles"] ?>" size="60" maxlength="255"></td>
    </tr>
    <tr>
      <td align="right" class="border" >关键词（keywords）</td>
      <td class="border" ><input name="keywords" type="text" id="keywords" value="<?php echo $row["keywords"] ?>" size="60" maxlength="255">
        (多个关键词以“,”隔开)</td>
    </tr>
    <tr>
      <td align="right" class="border" >描述（description）</td>
      <td class="border" ><input name="description" type="text" id="description" value="<?php echo $row["description"] ?>" size="60" maxlength="255">
        (适当出现关键词，最好是完整的句子)</td>
    </tr>
    <tr> 
      <td align="right" class="border">&nbsp;</td>
      <td class="border"><input type="submit" name="Submit2" value="修 改" class="buttons"></td>
    </tr>
    <tr> 
      <td colspan="2" class="userbar">排名（推荐）设置，在这里设置，不会扣除用户的积分</td>
    </tr>
    <tr> 
      <td align="right" class="border">排名到期时间</td>
      <td class="border"><input name="eliteendtime" type="text" value="<?php echo date("Y-m-d",strtotime($row['eliteendtime']))?>" size="20" onFocus="JTC.setday(this)" autocomplete="off">      </td>
    </tr>
    <tr>
      <td align="right" class="border" >积分/天</td>
      <td class="border" ><input name="elite" type="text" id="elite" class="biaodan" value="<?php echo $row["elite"] ?>" size="10" maxlength="20">
        （设值范围为0-127，0为取消排名，积分高的排名靠前）</td>
    </tr>
    <tr> 
      <td align="right" class="border">搜索热门词</td>
      <td class="border"><input name="tag" type="text" id="tag" value="<?php echo $row["tag"]?>" size="45">
        (多个词可用 , 隔开) </td>
    </tr>
    <tr>
      <td colspan="2" class="userbar">模板选择</td>
    </tr>
	  <tr>
            <td align="right" class="border" >模板</td>
            <td class="border" >
              <label><input type="radio" name="skin" value="cp" id="cp" <?php if ($row["skin"]=='cp'){ echo "checked";}  ?>/>
              产品型</label>
              <label><input type="radio" name="skin" value="xm" id="xm" <?php if ($row["skin"]=='xm'){ echo "checked";}  ?>/>
              项目型</label>            </td>
    </tr>
	  <tr>
        <td align="right" class="border">外链地址</td>
	    <td class="border"><input name="link" type="text" id="link" value="<?php echo $row["link"]?>" size="45"></td>
    </tr>
	  <tr id="trquanxian">
        <td colspan="2" class="userbar" >浏览权限设置</td>
    </tr>
	  <tr id="trquanxian2">
        <td align="right" class="border" >&nbsp;</td>
	    <td class="border" ><select name="groupid_guest" class="biaodan">
            <option value="0">全部用户</option>
            <?php
		  $rs_groupid=query("Select groupid,groupname from zzcms_usergroup ");
		  while($row_groupid = fetch_array($rs_groupid)){
		  	if ($row["groupid_guest"]== $row_groupid["groupid"]) {
		  	echo "<option value='".$row_groupid["groupid"]."' selected>".$row_groupid["groupname"]."</option>";
			}else{
			echo "<option value='".$row_groupid["groupid"]."'>".$row_groupid["groupname"]."</option>";
			}
		  } 
	 ?>
          </select>
            <select name="jifen" id="jifen" class="biaodan">
              <option value="0">请选择无权限用户是否可用积分查看</option>
              <option value="0" <?php if ($row["jifen"]==0) { echo "selected";}?>>无权限用户不可用积分查看</option>
              <option value="1" <?php if ($row["jifen"]==1) { echo "selected";}?>>付我1积分可查看</option>
              <option value="2" <?php if ($row["jifen"]==2) { echo "selected";}?>>付我2积分可查看</option>
              <option value="5" <?php if ($row["jifen"]==5) { echo "selected";}?>>付我5积分可查看</option>
              <option value="10" <?php if ($row["jifen"]==10) { echo "selected";}?>>付我10积分可查看</option>
              <option value="20" <?php if ($row["jifen"]==20) { echo "selected";}?>>付我20积分可查看</option>
              <option value="30" <?php if ($row["jifen"]==30) { echo "selected";}?>>付我30积分可查看</option>
              <option value="50" <?php if ($row["jifen"]==50) { echo "selected";}?>>付我50积分可查看</option>
              <option value="100" <?php if ($row["jifen"]==100) { echo "selected";}?>>付我100积分可查看</option>
            </select>        </td>
    </tr>	  
    <tr> 
      <td align="center" class="border">&nbsp;</td>
      <td class="border"><input type="submit" name="Submit" value="修 改" class="buttons">
		<input name="cpid" type="hidden" id="cpid" value="<?php echo $row["id"]?>">
		<input name="sendtime" type="hidden" id="sendtime" value="<?php echo $row["sendtime"]?>"> 
        <input name="page" type="hidden" id="page" value="<?php echo $page?>"> 
		<input name="kind" type="hidden" id="kind" value="<?php echo $_GET["kind"]?>"> 
		<input name="keyword" type="hidden" id="keyword" value="<?php echo $_GET["keyword"]?>"></td>
    </tr>
  </table>
</form>
<div id='loading' style="display:none">正在保存，请稍候...</div>
<?php
}
?>
</body>
</html>