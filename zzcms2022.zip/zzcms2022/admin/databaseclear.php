<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
<script>
function ConfirmClear(){
   if(confirm("初始化数据库后将不能恢复！确定初始化么？"))
     return true;
   else
     return false;	 
}
function CheckAll(form){
  for (var i=0;i<form.elements.length;i++){
    var e = form.elements[i];
    if (e.Name != "chkAll")
       e.checked = form.chkAll.checked;
    }
}
</script>
<script src="../js/echarts.min.js"></script>
</head>
<body>
<div class="admintitle">初始化数据库</div>
<?php
if (!isset($_POST["action"])) {
?>
<form name="form1" method="post" action="" onSubmit="return ConfirmClear();">
<div class="box">	
<?php 
$rs = query("SHOW TABLES"); 
$i=1;
$date_s="[";
$date_title='';$date_content='';$date_pie='';
while($row = fetch_array($rs)) { 
	if ($row[0]=='zzcms_admin' || $row[0]=='zzcms_admingroup'){
	echo "<li title='管理员相关表，初始化后不能登录'><label><span style='padding:0 5px 0 25px' >".addzero($i)."</span>".$row[0]."</label></li>"; 
	}else{
	echo "<li><label><input name='table[]' type='checkbox'  value='".$row[0]."'><span style='padding:0 5px'>".addzero($i)."</span>".$row[0]; 
	
	$sqlN="select * from ".$row[0];
	$rsN=query($sqlN);
	$rowN=num_rows($rsN);
	echo " (共<span class='bigword'> ".$rowN." </span>条记录)";
	echo "</label></li>";
	}
$date_title=$date_title."'".$row[0]."',";//柱状图用
$date_content=$date_content.$rowN.",";//柱状图用
$date_pie=$date_pie."{ value:".$rowN.",name:'".$row[0]."'},";//饼状图用

$i++;
}

$date_pie=cutfgx($date_pie,','); //饼状图用

$date_title=cutfgx($date_title,','); //柱状图用
$date_content=cutfgx($date_content,',');//柱状图用

$date_e="]";

$date_title=$date_s.$date_title.$date_e;
$date_content=$date_s.$date_content.$date_e;
//echo $date_title."<br/>".$date_content;
//echo $date_pie;
?>	
<div style="clear:both;padding:10px 0"><label> <input type="checkbox" id="chkAll" name="chkAll"  onClick="CheckAll(this.form)" value="checkbox">全选</label>
              <input name="Submit24" type="submit" class="buttons" value="初始化"> 
              <input name="action" type="hidden" id="action" value="clear"></div>
	
</div>			
			
    
      </form>
<?php
}else{
checkadminisdo("siteconfig");
?>
<div class="border">
<?php
if(!empty($_POST['table'])){
    for($i=0; $i<count($_POST['table']);$i++){
	query("truncate ".trim($_POST['table'][$i])."");
	echo $table[$i]."表已被初始化<br>"; 
    }	
	echo "<a href='javascript:history.back()'>返回</a>";	
}else{
showmsg('操作失败！至少要选中一条信息。');
}
?>
</div>
<?php
}
?>

<div id="main" style="width: 100%;height:1000px;margin:20px 0"></div>		
<script type="text/javascript">
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById('main'));
      // 指定图表的配置项和数据
     /*
	 //柱状============================================
	 var option = {
        title: {
          text: '数据库记录数对比表'
        },
        tooltip: {},
        legend: {
          data: ['记录数']
        },
        xAxis: {
          //data: ['衬衫', '羊毛衫', '雪纺衫', '裤子', '高跟鞋', '袜子']
		  data: <?php echo $date_title?>
        },
        yAxis: {},
        series: [
          {
            name: '记录数',
            type: 'bar',
            data: <?php echo $date_content?>
          }
        ]
      };

	 
	  //玫瑰状===========================================
	  option = {
  legend: {
    top: 'bottom'
  },
  toolbox: {
    show: true,
    feature: {
      mark: { show: true },
      dataView: { show: true, readOnly: false },
      restore: { show: true },
      saveAsImage: { show: true }
    }
  },
  series: [
    {
      name: '数据库记录数对比表',
      type: 'pie',
      radius: [20, 150],
      center: ['50%', '50%'],
      roseType: 'area',
      itemStyle: {
        borderRadius: <?php echo $i?>
      },
      data: [
        <?php echo $date_pie?>
      ]
    }
  ]
};
*/

//饼状========================================
option = {
  title: {
    text: '数据库记录数对比表',
    subtext: '记录数对比表',
    left: 'center'
  },
  tooltip: {
    trigger: 'item'
  },
  legend: {
    orient: 'vertical',
    left: 'left'
  },
  series: [
    {
      name: '记录数',
      type: 'pie',
      radius: '50%',
      data: [
       <?php echo $date_pie?>
      ],
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      }
    }
  ]
};

 myChart.setOption(option);
    </script>		
</body>
</html>