<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../3/ckeditor/ckeditor.js"></script>
<script language = "JavaScript">
function CheckForm(){
/*if (document.myform.bigclassid.value==""){
    alert("请选择网刊类别！");
	document.myform.bigclassid.focus();
	return false;
  }	*/ 	  
if (document.myform.title.value==""){
    alert("网刊名称不能为空！");
	document.myform.title.focus();
	return false;
  }
}    
</script>
</head>
<body>
<?php

if ($action=="add") {
//checkadminisdo("wangkan_add");
?>
<div class="admintitle">发布网刊信息</div>
<form action="wangkan_edit.php?action=add" method="post" name="myform" target="_self" id="myform" onSubmit="return CheckForm();">      
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td align="right" class="border">所属类别</td>
      <td class="border"><?php
        $rs=get_class_list("zzcms_wangkanclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==@$_COOKIE['wangkanclassid']) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?></td>
    </tr>
    <tr> 
      <td width="100" align="right" class="border" >名称</td>
      <td class="border" > <input name="title" type="text" id="title" size="50" maxlength="50"></td>
    </tr>
    <tr> 
      <td width="100" align="right" class="border" >内容</td>
      <td class="border" > <textarea  name="content" id="content"></textarea>
	  	<script type="text/javascript">CKEDITOR.replace('content');	</script>      </td>
    </tr>
    <tr> 
      <td align="right" class="border" >置顶值</td>
      <td class="border" ><input name="elite" type="text" id="elite" value="0" size="10" maxlength="3">
        (0-255之间的数字，数值大的排在前面) </td>
    </tr>
    <tr> 
      <td align="right" class="border" >&nbsp;</td>
      <td class="border" ><input type="submit" name="Submit" value="发 布" ></td>
    </tr>
  </table>
</form>
<?php
}

if ($action=="modify") {
//checkadminisdo("wangkan_modify");
$page = isset($_GET['page'])?$_GET['page']:1;
checkid($page);
$id = isset($_GET['id'])?$_GET['id']:0;
checkid($id,1);
?>
<div class="admintitle">修改网刊信息</div>
<?php
$sql="select * from zzcms_wangkan where id='$id'";
$rs=query($sql);
$row=fetch_array($rs);
?>
<form action="wangkan_edit.php?action=modify" method="post" name="myform"  id="myform" onSubmit="return CheckForm();">     
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td align="right" class="border">所属类别</td>
      <td class="border"><?php
        $rs=get_class_list("zzcms_wangkanclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==$row["classid"]) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?></td>
    </tr>
    <tr> 
      <td width="100" align="right" class="border">名称</td>
      <td class="border"> <input name="title" type="text" id="title22" value="<?php echo $row["title"]?>" size="50" maxlength="255"></td>
    </tr>
    <tr> 
      <td width="100" align="right" class="border">内容</td>
      <td class="border"><textarea name="content" id="content" ><?php echo stripfxg($row["content"])?></textarea> 
       	<script type="text/javascript">CKEDITOR.replace('content');	</script></td>
    </tr>
    <tr> 
      <td align="right" class="border">审核</td>
      <td class="border"><input name="passed" type="checkbox" id="passed" value="1" <?php if ($row["passed"]==1){ echo "checked";}?>>
        （选中为通过审核）</td>
    </tr>
    <tr> 
      <td align="right" class="border">置顶值</td>
      <td class="border"> <input name="elite" type="text" id="elite" value="<?php echo $row["elite"]?>" maxlength="3">
        (0-127之间的数字，数值大的排在前面) </td>
    </tr>
    <tr> 
      <td align="right" class="border">&nbsp;</td>
      <td class="border"><input name="Submit" type="submit" id="Submit" value="修 改" >
        <input name="id" type="hidden" id="id" value="<?php echo $row["id"]?>">
      <input name="page" type="hidden" id="page" value="<?php echo $page?>"></td>
    </tr>
  </table>
</form> 
<?php
}
?> 
</body>
</html>