<?php
require("admin.php");
require("../inc/fy.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
$page=isset($_GET["page"])?$_GET["page"]:1;
checkid($page);
$keyword=isset($_POST["keyword"])?$_POST["keyword"]:'';
?>

<div class="admintitle0">
<span>
			<form name="form1" method="post" action="?">
              <input name="keyword" type="text" id="keyword" value="<?php echo $keyword?>" placeholder="请输入ip"> 
              <input type="submit" name="Submit" value="查找">
			  </form>
            </span>
          管理员操作日志 
</div>
<?php
$page_size=pagesize_ht;  //每页多少条数据
$offset=($page-1)*$page_size;
$sql="select count(*) as total from zzcms_adminlog where id<>0 ";
$sql2='';

if ($keyword<>"") {
$sql2=$sql2. " and ip like '%".$keyword."%' ";
}
$result =query($sql.$sql2); 
$row = fetch_array($result);
$totlenum = $row['total'];    
$totlepage=ceil($totlenum/$page_size);

$sql="select * from zzcms_adminlog where id<>0 ";
$sql=$sql.$sql2;
$sql=$sql . " order by id desc limit $offset,$page_size";
$result = query($sql); 
if(!$totlenum){
echo "暂无信息";
}else{
?>

      <table width="100%" border="0" cellpadding="5" cellspacing="1" class="bgcolor2">
    <tr class="trtitle"> 
      <td width="10%">admin</td>
      <td width="10%">ip</td>
      <td width="10%">url</td>
      <td width="10%">时间</td>
      </tr>
<?php
while($row = fetch_array($result)){
?>
	<tr class="trcontent">  
      <td><?php echo $row["admin"]?> </td>
      <td><?php echo $row["ip"]?></td>
      <td><?php echo $row["url"]?></td>
      <td><?php echo $row["sendtime"]?></td>
      </tr>
<?php
}
?>
  </table>
<div class="border center"><?php echo showpage_admin()?></div>
<?php
}
free_result();
close();
?>
</body>
</html>