<?php 
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
$page = isset($_POST['page'])?$_POST['page']:1;//只从修改页传来的值
checkid($page);
$id = isset($_POST['id'])?$_POST['id']:0;
checkid($id,1);
$passed = isset($_POST['passed'])?$_POST['passed']:0;
checkid($passed,1);
$elite = isset($_POST['elite'])?$_POST['elite']:0;
checkid($elite,1);

$classid = isset($_POST['classid'])?$_POST['classid']:0;
checkid($classid,1);

$FriendSiteName=trim($_POST["sitename"]);
$url=addhttp($url);
$logo=addhttp($logo);

if ($_REQUEST["action"]=="add"){
checkadminisdo("friendlink_add");
$isok=query("INSERT INTO zzcms_link (classid,sitename,url,img,content,passed,elite,sendtime)VALUES('$classid','$FriendSiteName','$url','$logo','$content','$passed','$elite','".date('Y-m-d H:i:s')."')");
}elseif ($_REQUEST["action"]=="modify") {
checkadminisdo("friendlink_modify");
$isok=query("update zzcms_link set classid='$classid',sitename='$FriendSiteName',url='$url',img='$logo',content='$content',passed='$passed',elite='$elite',sendtime='".date('Y-m-d H:i:s')."' where id='$id'");	
}
setcookie("linkclassid",$classid,time()+3600*24,"/admin");
?>

<div class="boxsave"> 
    <div class="title">
	<?php
	if ($_REQUEST["action"]=="add") {echo "添加 ";}else{echo"修改";}
	if ($isok){echo"成功";}else{echo "失败";}
     ?>
	</div>
	<div class="content_a">
	名称：<?php echo $FriendSiteName?>
	<div class="editor">
	<li><a href="link.php?action=add">[继续添加]</a></li>
	<li><a href="link.php?action=modify&id=<?php echo $id?>">[修改]</a></li>
	<li><a href="link_list.php?b=<?php echo $classid?>&page=<?php echo $page?>">[返回]</a></li>
	</div>
	</div>
	</div>
</body>
</html>