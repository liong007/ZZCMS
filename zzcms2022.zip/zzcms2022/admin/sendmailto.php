<?php
require("admin.php");
set_time_limit(1800) ;
ob_end_clean();//终止缓冲。这样就不用等到有4096bytes的缓冲之后才被发送出去了。
echo str_pad(" ",256);//IE需要接受到256个字节之后才开始显示。
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="border" style="padding:10px"> 
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../3/PHPMailer/src/Exception.php';
require '../3/PHPMailer/src/PHPMailer.php';
require '../3/PHPMailer/src/SMTP.php';

checkadminisdo("sendmail");
	$fp="../template/".siteskin."/email.htm";
	$f= fopen($fp,'r');
	$strout = fread($f,filesize($fp));
	fclose($f);
	$strout=str_replace("{#body}",$mailbody,$strout) ;
	$strout=str_replace("{#siteurl}",siteurl,$strout) ;
	$strout=str_replace("{#logourl}",logourl,$strout) ;
	$mailbody=$strout;

$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
//try {
    //服务器配置
    $mail->CharSet ="UTF-8";                     //设定邮件编码
    $mail->SMTPDebug = 0;                        // 调试模式输出
    $mail->isSMTP();                             // 使用SMTP
    $mail->Host = smtpserver;                // SMTP服务器
    $mail->SMTPAuth = true;                      // 允许 SMTP 认证
    $mail->Username = sender;                // SMTP 用户名  即邮箱的用户名
    $mail->Password = smtppwd;             // SMTP 密码  部分邮箱是授权码(例如163邮箱)
    $mail->SMTPSecure = 'ssl';                    // 允许 TLS 或者ssl协议
    $mail->Port = 465;                            // 服务器端口 25 或者465 具体要看邮箱服务器支持

    $mail->setFrom(sender, 'Mailer');  //发件人
    //$mail->addAddress('ellen@example.com');  // 可添加多个收件人
    $mail->addReplyTo(sender, 'info'); //回复的时候回复给哪个邮箱 建议和发件人一致
    //$mail->addCC('cc@example.com');                    //抄送
    //$mail->addBCC('bcc@example.com');                    //密送
    //发送附件
    // $mail->addAttachment('../xy.zip');         // 添加附件
    // $mail->addAttachment('../thumb-1.jpg', 'new.jpg');    // 发送附件并且重命名
    //Content
    $mail->isHTML(true);                                  // 是否以HTML文档格式发送  发送后客户端可直接显示对应HTML内容
    $mail->Subject = $subject ;
    $mail->Body    = $mailbody ;
    $mail->AltBody = '如果邮件客户端不支持HTML则显示此内容';
if ($tomail<>""){//对于单一用户发信
	$mail->addAddress($tomail, 'Joe');  // 收件人
    $ok=$mail->send();
	if($ok){
	echo "邮件发送到".$tomail."成功";
   	}else{
	echo "邮件发送到".$tomail."失败: ", $mail->ErrorInfo;
	}

}else{
  $mail->Subject = $subject ;
  $mail->Body    = $mailbody ;
$size=2;//每轮群发个数
$sleeps=3;//每个间隔时间
$n=isset($_GET['n'])?$_GET['n']:0;
	$sql="select email from zzcms_user where groupid=$groupid order by id asc limit $n,$size";
	echo $sql;
	$rs=query($sql); 
	$row=num_rows($rs); 
	if ($row){
		while ($row=fetch_array($rs)){
		$tomail=$row['email']; //收件人
		$mail->addAddress($tomail, 'Joe');  // 收件人
		$ok=$mail->send();
		if($ok){echo "<li>第".($n+1)."个，发送到".$tomail."成功</li>";}else{echo "<li>第".($n+1)."个，发送到".$tomail."失败</li>";}
		flush();  //不在缓冲中的或者说是被释放出来的数据发送到浏览器    
		sleep($sleeps);
		$n++;
		
		}
		echo "<br><b>本轮群发第".$n."个完成，正在转入下一轮</b><br/>";
		echo"<meta http-equiv=\"refresh\" content=\"1;url=sendmailto.php?n=$n&subject=$subject&groupid=$groupid\">";   
	}else{
	echo '完成';//当无记录时提示完成
	}
}

//} catch (Exception $e) {
    //echo '邮件发送失败: ', $mail->ErrorInfo;
//}
?>
</div>
</body>
</html>