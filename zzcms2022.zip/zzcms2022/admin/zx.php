<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../3/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="../js/jquery.js"></script>  
<script language="javascript">  
$(document).ready(function(){  
  $("#title").change(function() { //jquery 中change()函数  
	$("#quote").load(encodeURI("../ajax/zxtitlecheck_ajax.php?id="+$("#title").val()));//jqueryajax中load()函数 加encodeURI，否则IE下无法识别中文参数 
  });  
});  

function CheckForm(){
/*if (document.myform.bigclassid.value==""){
    alert("请选择大类别！");
	document.myform.bigclassid.focus();
	return false;
  } */
if (document.myform.title.value==""){
    alert("标题不能为空！");
	document.myform.title.focus();
	return false;
  }
  
//创建正则表达式
var re=/^[0-9]*$/;		
	if(document.myform.elite.value==""){
		alert("请输入数值！");
		document.myform.elite.focus();
		return false;
	}
	if(document.myform.elite.value.search(re)==-1)  {
    alert("必须为正整数！");
	document.myform.elite.value="";
	document.myform.elite.focus();
	return false;
  	}
	if(document.myform.elite.value>127)  {
    alert("不得大于127");
	document.myform.elite.focus();
	return false;
  	}
	document.getElementById('loading').style.display='block';      
} 

function showlink(){
whichEl = eval("link");
if (whichEl.style.display == "none"){
eval("link.style.display=\"\";");
eval("trlaiyuan.style.display=\"none\";");
eval("trcontent.style.display=\"none\";");
eval("trimg.style.display=\"none\";");
eval("trseo.style.display=\"none\";");
eval("trkeywords.style.display=\"none\";");
eval("trdescription.style.display=\"none\";");
eval("trquanxian.style.display=\"none\";");
eval("trquanxian1.style.display=\"none\";");
eval("trquanxian2.style.display=\"none\";");
eval("trquanxian3.style.display=\"none\";");
}else{
eval("link.style.display=\"none\";");
eval("trlaiyuan.style.display=\"\";");
eval("trcontent.style.display=\"\";");
eval("trimg.style.display=\"\";");
eval("trseo.style.display=\"\";");
eval("trkeywords.style.display=\"\";");
eval("trdescription.style.display=\"\";");
eval("trquanxian.style.display=\"\";");
eval("trquanxian1.style.display=\"\";");
eval("trquanxian2.style.display=\"\";");
eval("trquanxian3.style.display=\"\";");
}
}  
</script>
</head>
<body>
<?php

if ($action=="add") {
//checkadminisdo("zx_add");
?>
<div class="admintitle">发布资讯信息</div>
<form action="zx_edit.php?action=add" method="post" name="myform" id="myform" onSubmit="return CheckForm();">        
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td width="15%" align="right" class="border" >所属类别</td>
      <td width="85%" class="border" ><?php
        $rs=get_class_list("zzcms_zixunclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==@$_COOKIE['zxclassid']) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?>
        <select name="province">
<?php
echo formprovince_select();
?>	
</select>
 </td>
    </tr>
    <tr> 
      <td align="right" class="border" >标题 </td>
      <td class="border" > 	
        <input name="title" type="text" id="title" size="50" maxlength="255"> 
        <label><input type="checkbox" name="checkbox" value="checkbox" onClick="showlink()">
        外链新闻</label> 
        <span id="quote"></span>		</td>
    </tr>
    <tr id="link" style="display:none"> 
      <td align="right" class="border" >链接地址</td>
      <td class="border" ><input name="link" type="text" id="laiyuan3" size="50" maxlength="255">      </td>
    </tr>
    <tr id="trlaiyuan"> 
      <td align="right" class="border" >信息来源</td>
      <td class="border" ><input name="laiyuan" type="text" id="laiyuan2" size="50" maxlength="50"></td>
    </tr>
    <tr id="trcontent"> 
      <td align="right" class="border" >内容</td>
      <td class="border" ><textarea name="content" type="hidden" id="content"></textarea> 
        <script type="text/javascript">CKEDITOR.replace('content');	</script>      </td>
    </tr>
    <tr id="trimg">
      <td align="right" class="border" >封面图片</td>
      <td class="border" ><input name="img" type="text" size="50" maxlength="255" />
        （如果内容中有图片，这里可以留空，会自动获取内容中的第一张图片）</td>
    </tr>
    <tr>
      <td align="right" class="border" >&nbsp;</td>
      <td class="border" ><input type="submit" name="Submit" value="发 布" ></td>
    </tr>
    <tr id="trseo">
      <td colspan="2" class="admintitle2" >SEO设置</td>
    </tr>
    <tr id="trkeywords">
      <td align="right" class="border" >关键词（keywords）</td>
      <td class="border" ><input name="keywords" type="text" id="keywords" size="50" maxlength="255"></td>
    </tr>
    <tr id="trdescription">
      <td align="right" class="border" >描述（description）</td>
      <td class="border" ><input name="description" type="text" id="description" size="50" maxlength="255"></td>
    </tr>
    <tr id="trquanxian">
      <td colspan="2" class="admintitle2" >属性设置</td>
    </tr>
    <tr id="trquanxian1"> 
      <td align="right" class="border" >审核</td>
      <td class="border" ><input name="passed" type="checkbox" id="passed" value="1">
      （选中为通过审核）</td>
    </tr>
    <tr id="trquanxian2">
      <td align="right" class="border" >推荐值</td>
      <td class="border" ><input name="elite" type="text" id="elite" value="0" size="4" maxlength="4">
(0-127之间的数字，数值大的排在前面) </td>
    </tr>
    <tr id="trquanxian3"> 
      <td align="right" class="border" >浏览权限</td>
      <td class="border" ><select name="groupid">
          <option value="0">全部用户可看</option>
          <?php
		  $rs=query("Select groupid,groupname from zzcms_usergroup ");
		  while($row = fetch_array($rs)){
		  echo "<option value='".$row["groupid"]."'>".$row["groupname"]."可看</option>";
		  }
	 ?><option value="999">全部用户不可看</option>
        </select> <select name="jifen" id="jifen">
          <option value="0">请选择无权限用户是否可用积分查看</option>
          <option value="0">无权限用户不可用积分查看</option>
          <option value="1">付我1积分可查看</option>
		  <option value="5">付我5积分可查看</option>
		  <option value="10">付我10积分可查看</option>
          <option value="20">付我20积分可查看</option>
          <option value="30">付我30积分可查看</option>
          <option value="50">付我50积分可查看</option>
          <option value="100">付我100积分可查看</option>
   
        </select> </td>
    </tr>
    <tr> 
      <td align="right" class="border" >&nbsp;</td>
      <td class="border" > <input type="submit" name="Submit" value="发 布" >
      <input name="action" type="hidden" id="action" value="add" /></td>
    </tr>
  </table>
</form>	
<?php
}

if ($action=="modify") {
//checkadminisdo("zx_modify");
?>
<div class="admintitle">修改资讯信息</div>
<?php
$page = isset($_GET['page'])?$_GET['page']:1;
checkid($page);
$id = isset($_GET['id'])?$_GET['id']:0;
checkid($id,1);
$rs = query("select * from zzcms_zixun where id='$id'"); 
$row= fetch_array($rs);
?>
<form action="zx_edit.php?action=modify" method="post" name="myform" id="myform" onSubmit="return CheckForm();">      
  <table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tr> 
      <td width="15%" align="right" class="border">所属类别</td>
      <td width="85%" class="border"><?php
        $rs=get_class_list("zzcms_zixunclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==$row["classid"]) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?>
        <select name="province">
  <?php
echo formprovince_select($row["province"]);
?>	
  </select>
</td></tr>
    <tr> 
      <td align="right" class="border">标题</td>
      <td class="border"> 
        <input name="title" type="text" id="title2" value="<?php echo $row["title"]?>" size="50" maxlength="255">      </td>
    </tr>
    <tr id="link" style="display:"> 
      <td align="right" class="border" >链接地址</td>
      <td class="border" ><input name="link" type="text" id="laiyuan3" value="<?php echo $row["link"]?>" size="50" maxlength="255">      </td>
    </tr>
    <tr id="trlaiyuan"> 
      <td align="right" class="border" >信息来源</td>
      <td class="border" > <input name="laiyuan" type="text" id="title2" value="<?php echo $row["laiyuan"]?>" size="50" maxlength="50"></td>
    </tr>
    <tr id="trcontent"> 
      <td width="12%" align="right" class="border">内容</td>
      <td class="border"> <textarea name="content" id="content" ><?php echo stripfxg($row["content"])?></textarea> 
        <script type="text/javascript">CKEDITOR.replace('content');	</script> 
        <input name="id" type="hidden" id="id" value="<?php echo $row["id"]?>"> 
        <input name="page" type="hidden" id="page" value="<?php echo $page?>"> </td>
    </tr>
    <tr id="trkeywords">
      <td align="right" class="border" >封面图片</td>
      <td class="border" ><input name="img" type="text" value="<?php echo $row["img"]?>" size="50" maxlength="255" /></td>
    </tr>
    <tr>
      <td align="right" class="border">&nbsp;</td>
      <td class="border"><input type="submit" name="Submit" value="提交"></td>
    </tr>
    <tr id="trkeywords">
      <td colspan="2" class="admintitle2" >SEO</td>
    </tr>
    <tr id="trkeywords">
      <td align="right" class="border" >关键词（keywords）</td>
      <td class="border" ><input name="keywords" type="text" id="title2" value="<?php echo $row["keywords"]?>" size="50" maxlength="255"></td>
    </tr>
    <tr id="trkeywords">
      <td align="right" class="border" >描述（description）</td>
      <td class="border" ><input name="description" type="text" id="title2" value="<?php echo $row["description"]?>" size="50" maxlength="255"></td>
    </tr>
    <tr id="trkeywords">
      <td colspan="2" class="admintitle2" >属性设置</td>
    </tr>
    <tr>
      <td align="right" class="border">审核</td>
      <td class="border"><input name="passed" type="checkbox" id="passed" value="1"  <?php if ($row["passed"]==1) { echo "checked";}?>>
        （选中为通过审核） </td>
    </tr>
    <tr> 
      <td align="right" class="border">推荐值</td>
      <td class="border"> <input name="elite" type="text" id="elite" value="<?php echo $row["elite"]?>" size="4" maxlength="3">
        (0-127之间的数字，数值大的排在前面) </td>
    </tr>
    <tr> 
      <td align="right" class="border" >浏览权限</td>
      <td class="border" > <select name="groupid">
          <option value="0">全部用户可看</option>
          <?php
		  $rsn=query("Select groupid,groupname from zzcms_usergroup ");
		  $rown = num_rows($rsn);
		  if ($rown){
		  while($rown = fetch_array($rsn)){
		  	if ($rown["groupid"]== $row["groupid"]) {
		  	echo "<option value='".$rown["groupid"]."' selected>".$rown["groupname"]."可看</option>";
			}else{
			echo "<option value='".$rown["groupid"]."'>".$rown["groupname"]."可看</option>";
			}
		  }
		  }
	 ?><option value="999">全部用户不可看</option>
        </select> <select name="jifen" id="jifen">
          <option value="0">请选择无权限用户是否可用积分查看</option>
          <option value="0" <?php if ($row["jifen"]==0) { echo "selected";}?>>无权限用户不可用积分查看</option>
		  <option value="1" <?php if ($row["jifen"]==1) { echo "selected";}?>>付我1积分可查看</option>
		  <option value="5" <?php if ($row["jifen"]==5) { echo "selected";}?>>付我5积分可查看</option>
          <option value="10" <?php if ($row["jifen"]==10) { echo "selected";}?>>付我10积分可查看</option>
          <option value="20" <?php if ($row["jifen"]==20) { echo "selected";}?>>付我20积分可查看</option>
          <option value="30" <?php if ($row["jifen"]==30) { echo "selected";}?>>付我30积分可查看</option>
          <option value="50" <?php if ($row["jifen"]==50) { echo "selected";}?>>付我50积分可查看</option>
          <option value="100" <?php if ($row["jifen"]==100) { echo "selected";}?>>付我100积分可查看</option>
         
        </select> </td>
    </tr>
    <tr> 
      <td align="right" class="border">&nbsp;</td>
      <td class="border"> <input type="submit" name="Submit" value="提交">
      <input name="action" type="hidden" id="action" value="modify"></td>
    </tr>
  </table>
</form>
<?php
}
?> 
<div id='loading' style="display:none">正在保存，请稍候...</div>
</body>
</html>