<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../3/ckeditor/ckeditor.js"></script>
<script language="JavaScript">
function CheckForm(){
if (document.myform.title.value==""){
    alert("标题不能为空！");
	document.myform.title.focus();
	return false;
  }
} 
</script>

</head>
<body>
<?php 
if ($action=="add") {
?>
<div class="admintitle">添加单页</div>
<form action="about_edit.php?action=add" method="POST" name="myform" id="myform" onSubmit="return CheckForm();">
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td width="10%" align="right" class="border">名称</td>
      <td width="90%" class="border"><input name="title" type="text" id="title"></td>
    </tr>
    <tr> 
      <td align="right" class="border">内容</td>
      <td class="border"> <textarea name="content" id="content" ></textarea> 
       	<script type="text/javascript">CKEDITOR.replace('content');	</script>      </td>
    </tr>
    <tr id="trkeywords">
      <td align="right" class="border" >应用模板文件</td>
      <td class="border" ><select name="skin" id="skin">
          <?php
$dir = opendir("../template/".siteskin);
while(($file = readdir($dir))!=false){
	 if ($file!="." && $file!=".." && strpos($file,"about")!==false) { //不读取. ..
	?>
          <option value="<?php echo $file?>"><?php echo $file?></option>
          <?php
}
}
closedir($dir);
?>
      </select></td>
    </tr>
    <tr> 
      <td align="right" class="border"><input name="link" type="hidden" value=""></td>
      <td class="border"> 
        <input type="submit" name="Submit" value="提 交" ></td>
    </tr>
</table>
</form>
<?php
}

if ($action=="modify") {
//checkadminisdo("about_modify");
$sql="select * from zzcms_about where id='".$id."'";
$rs=query($sql);
$row=fetch_array($rs);
?>
<div class="admintitle">修改单页信息</div>  
<form action="about_edit.php?action=modify" method="POST" name="myform" id="myform" onSubmit="return CheckForm();">
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td width="10%" align="right" class="border">名称</td>
      <td width="90%" class="border"><input name="title" type="text" id="title" value="<?php echo $row["title"]?>"></td>
    </tr>
    <tr> 
      <td align="right" class="border">内容</td>
      <td class="border"> <textarea name="content" id="content" ><?php echo stripfxg($row["content"])?></textarea> 
	  	<script type="text/javascript">CKEDITOR.replace('content');	</script>        </td>
    </tr>
    <tr id="trkeywords">
      <td align="right" class="border" >应用模板文件</td>
      <td class="border" ><select name="skin" id="skin">
          <?php
$dir = opendir("../template/".siteskin);
while(($file = readdir($dir))!=false){
  if ($file!="." && $file!=".." && strpos($file,"about")!==false) { //不读取. ..
	?>
          <option value="<?php echo $file?>" <?php if ( $row["skin"]==$file){ echo  "selected";}?>><?php echo $file?></option>
          <?php
}
}
closedir($dir);
?>
      </select></td>
    </tr>
    <tr> 
      <td align="right" class="border">链接地址</td>
      <td class="border"><input name="link" type="text"  value="<?php if ($row["link"]<>"") { echo $row["link"]; }else{ echo "/one/siteinfo.php?id=".$row["id"]."";}?>"> </td>
    </tr>
    <tr>
      <td align="right" class="border"><input name="id" type="hidden"  value="<?php echo $row["id"]?>"></td>
      <td class="border">
<input type="submit" name="Submit2" value="提 交"></td>
    </tr>
</table>
</form>
<?php
}
?>
</body>
</html>