<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../js/jquery.js"></script>  
<script type="text/javascript" src="../3/ckeditor/ckeditor.js"></script>
<script language="javascript">  
$(document).ready(function(){  
  $("#title").change(function() { //jquery 中change()函数  
	$("#quote").load(encodeURI("../ajax/asktitlecheck_ajax.php?id="+$("#title").val()));//jqueryajax中load()函数 加encodeURI，否则IE下无法识别中文参数 
  });  
});  

function CheckForm(){
/*if (document.myform.bigclassid.value==""){
    alert("请选择大类别！");
	document.myform.bigclassid.focus();
	return false;
} */
if (document.myform.title.value==""){
    alert("标题不能为空！");
	document.myform.title.focus();
	return false;
}
  
//创建正则表达式
var re=/^[0-9]*$/;		
	if(document.myform.elite.value==""){
		alert("请输入数值！");
		document.myform.elite.focus();
		return false;
	}
	if(document.myform.elite.value.search(re)==-1)  {
    alert("必须为正整数！");
	document.myform.elite.value="";
	document.myform.elite.focus();
	return false;
  	}
	
	if(document.myform.elite.value>127)  {
    alert("不得大于127");
	document.myform.elite.focus();
	return false;
  	} 
	document.getElementById('loading').style.display='block'; 	    
} 
</script>
</head>

<body>
<?php
if ($action=="add") {
//checkadminisdo("ask_add");
?>
<div class="admintitle">发布问答</div>
<form action="ask_edit.php?action=add" method="post" name="myform" id="myform" onSubmit="return CheckForm();">
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td width="12%" align="right" class="border" >所属类别</td>
      <td width="88%" class="border" ><?php
        $rs=get_class_list("zzcms_askclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==@$_COOKIE['askclassid']) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?></td>
    </tr>
    <tr> 
      <td align="right" class="border" >标题 </td>
      <td class="border" > 
        <input name="title" type="text" id="title" size="50" maxlength="255">
		<span id="quote"></span>	
		</td>
    </tr>
    <tr> 
      <td align="right" class="border" >内容</td>
      <td class="border" ><textarea name="content" type="hidden" id="content"></textarea> 
        <script type="text/javascript">CKEDITOR.replace('content');	</script>      </td>
    </tr>
    <tr>
      <td align="right" class="border" >封面图片</td>
      <td class="border" ><input name="img" type="text" id="title2" size="50" maxlength="255" />
        （如果内容中有图片，这里可以留空，会自动获取内容中的第一张图片）</td>
    </tr>
    <tr>
      <td colspan="2" class="admintitle2" >属性设置</td>
    </tr>
    <tr> 
      <td align="right" class="border" >审核</td>
      <td class="border" ><input name="passed" type="checkbox" id="passed" value="1">
      （选中为通过审核）</td>
    </tr>
    <tr>
      <td align="right" class="border" >推荐值</td>
      <td class="border" ><input name="elite" type="text" id="elite" value="0" size="4" maxlength="4">
(0-127之间的数字，数值大的排在前面) </td>
    </tr>
    <tr> 
      <td align="right" class="border" >&nbsp;</td>
      <td class="border" > <input type="submit" name="Submit" value="发 布" ></td>
    </tr>
  </table>
</form>	
<?php
}
if ($action=="modify") {
checkadminisdo("ask_modify");
?>
<div class="admintitle">修改问答信息</div>
<?php
$page = isset($_GET['page'])?$_GET['page']:1;
checkid($page);
$id = isset($_GET['id'])?$_GET['id']:0;
checkid($id,1);

$rs = query("select * from zzcms_ask where id='$id'"); 
$row= mysqli_fetch_array($rs);
?>
<form action="ask_edit.php?action=modify" method="post" name="myform" id="myform" onSubmit="return CheckForm();">
        
  <table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tr> 
      <td width="12%" align="right" class="border">所属类别</td>
      <td width="88%" class="border"><?php
        $rs=get_class_list("zzcms_askclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==$row["classid"]) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?></td>
    </tr>
    <tr> 
      <td align="right" class="border">标题</td>
      <td class="border"> 
        <input name="title" type="text" id="title2" value="<?php echo $row["title"]?>" size="50" maxlength="255">      </td>
    </tr>
    <tr id="trcontent"> 
      <td width="12%" align="right" class="border">内容</td>
      <td class="border"> <textarea name="content" id="content" ><?php echo stripfxg($row["content"])?></textarea> 
        <script type="text/javascript">CKEDITOR.replace('content');	</script> 
        <input name="id" type="hidden" id="id" value="<?php echo $row["id"]?>"> 
        <input name="page" type="hidden" id="page" value="<?php echo $page?>"> </td>
    </tr>
    <tr id="trkeywords">
      <td align="right" class="border" >封面图片</td>
      <td class="border" ><input name="img" type="text" id="title2" value="<?php echo $row["img"]?>" size="50" maxlength="255">
      （如果内容中有图片，这里可以留空，会自动获取内容中的第一张图片）</td>
    </tr>
    <tr id="trkeywords">
      <td colspan="2" class="admintitle2" >属性设置</td>
    </tr>
    <tr>
      <td align="right" class="border">审核</td>
      <td class="border"><input name="passed[]" type="checkbox" id="passed[]" value="1"  <?php if ($row["passed"]==1) { echo "checked";}?>>
        （选中为通过审核） </td>
    </tr>
    <tr> 
      <td align="right" class="border">推荐值</td>
      <td class="border"> <input name="elite" type="text" id="elite" value="<?php echo $row["elite"]?>" size="4" maxlength="3">
        (0-127之间的数字，数值大的排在前面) </td>
    </tr>
    <tr> 
      <td align="right" class="border">&nbsp;</td>
      <td class="border"> <input type="submit" name="Submit" value="提交">
      </td>
    </tr>
  </table>
</form> 
<?php
}
?> 

</body>
</html>