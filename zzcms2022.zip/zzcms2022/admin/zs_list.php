<?php
$t1 = microtime(true);
require("admin.php");
require("../inc/fy.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../js/gg.js"></script>
<?php
checkadminisdo("zs");
require("get_cs_list.php");
$table='zzcms_zhaoshang';
require("../inc/pass.php");
?>
</head>
<body>
<div class="admintitle">
<span>
<form name="form1" method="get" action="?">
        <label><input type="radio" name="kind" value="editor" <?php if ($kind=="editor") { echo "checked";}?>>按发布人</label>
        <label><input type="radio" name="kind" value="proname" <?php if ($kind=="proname") { echo "checked";}?>>按产品名称</label>
        <input name="keyword" type="text" id="keyword" size="25" value="<?php echo  $keyword?>">
        <input type="submit" name="Submit" value="查寻">
       <a href="?showwhat=elite">固顶的信息</a> <a href="?showwhat=vip">VIP会员的信息</a> 
  </form>
</span>
<?php echo channelzs?>信息管理 <input name="submit3" type="submit" class="buttons" onClick="javascript:location.href='zs.php?action=add'" value="发布<?php echo channelzs?>信息">
</div> 	
<div class="border"><?php 	echo c('zzcms_zhaoshangclass',$b);?></div>

<?php
$page_size=pagesize_ht;  //每页多少条数据
$offset=($page-1)*$page_size;
$sql="select count(*) as total from zzcms_zhaoshang where (1=1) ";
$sql2='';
if ($shenhe=="no") {  		
$sql2=$sql2." and passed=0 ";
}

if ($b<>"") {
$bidsNew=displaylist('zzcms_zhaoshangclass',$b);
setcookie("bids",$bidsNew,time()+3600*24,"admin");
$bids=$bidsNew;
}else{
$bids=isset($_COOKIE['bids'])?$_COOKIE['bids']:'';
}

if ($b<>"") {
$sql2=$sql2." and classid in ($bids)";
}

if ($keyword<>"") {
	switch ($kind){
	case "editor";$sql2=$sql2. " and editor like '%".$keyword."%' ";break;
	case "proname";$sql2=$sql2. " and proname like '%".$keyword."%'";break;
	default:$sql2=$sql2. " and editor like '%".$keyword."%'";
	}
}

if ($showwhat=="elite" ){		
	$sql2=$sql2." and tag<>'' ";
}

if ($showwhat=="vip" ){		
	$sql2=$sql2." and editor in(select username from zzcms_user where groupid>1) ";
}

$rs =query($sql.$sql2); 
$row =fetch_array($rs);
$totlenum = $row['total'];
$totlepage=ceil($totlenum/$page_size);

$sql="select * from zzcms_zhaoshang where (1=1) ";
$sql=$sql.$sql2;
$sql=$sql . " order by id desc limit $offset,$page_size";
$rs = query($sql); 
if(!$totlenum){
echo $lang['nomsg'];//加入了语言包
}else{
//echo $sql;
?>
<form name="myform" id="myform" method="post" action=""  onSubmit="return anyCheck(this.form)">
  <div class="border2">
  <input name="submit" type="submit" onClick="myform.action='?action=pass'" value="【取消/审核】选中的信息">
  <input name="submit" type="submit" onClick="myform.action='del.php';myform.target='_self';return ConfirmDel()" value="删除选中的信息">
  </div>
  <table width="100%" border="0" cellpadding="5" cellspacing="1" class="bgcolor2">
    <tr class="trtitle"> 
      <td width="2%"  align="center"> <label for="chkAll" style="cursor: pointer;">全选</label></td>
      <td width="5%"  align="center">图片</td>
      <td width="10%"align="center" >产品名称</td>
      <td width="10%" align="center">类别</td>
      <td width="10%" align="center"><?php echo channelzs?>区域</td>
      <td width="10%"  align="center">发布人</td>
      <td width="10%" align="center">发布时间</td>
      <td width="5%" align="center">信息状态</td>
      <td width="5%" align="center">操作</td>
    </tr>
<?php
while($row = fetch_array($rs)){
?>
    <tr class="trcontent"> 
      <td align="center" class="docolor"> <input name="id[]" type="checkbox" id="id2" value="<?php echo $row["id"]?>"></td>
      <td align="center" ><a href="<?php echo $row["img"]?>" target="_blank"><img src="<?php echo getsmallimg($row['img'])?>" width="60"></a></td>
      <td align="center" ><a href="<?php echo getpageurl("zhaoshang",$row["id"]) ?>" target="_blank"><?php  echo $row["title"]?></a></td>
      <td align="center"><?php echo "<a href=?b=".$row['classid'].">" .getclassname('zzcms_zhaoshangclass',$row["classid"])."</a>"; ?></td>
      <td align="center"><?php echo $row["province"]."-".$row["city"]?></td>
      <td align="center"><a href="usermanage.php?keyword=<?php echo $row["editor"]?>" ><?php echo $row["editor"]?></a><br>
      用户组ID:<?php echo $row["groupid"]?></td>
      <td align="center" title="<?php echo $row["sendtime"]?>"><?php echo date("Y-m-d",strtotime($row["sendtime"]))?></td>
      <td align="center">
	   <?php 
	   if ($row["passed"]==1) { echo "已审核";} else {echo "<font color=red>未审核</font>";}
	   if ($row["tag"]<>'') { echo "<br/><font color=green>固顶值:".$row['elite']."<br/>关键词:".$row['tag']."</font>";}
	   ?>      </td>
      <td align="center" class="docolor">
	  <a href="zs.php?action=modify&id=<?php echo $row["id"] ?>&page=<?php echo $page ?>&kind=<?php echo $kind ?>&keyword=<?php echo $keyword ?>">修改</a></td> 
      
    </tr>
 <?php
 }
 ?>
  </table>
  <div class="border">
    <input name="chkAll" type="checkbox" id="chkAll" onClick="CheckAll(this.form)" value="checkbox">
         <label for="chkAll" style="cursor: pointer;">全选/不选</label> 
        <input type="submit" onClick="myform.action='?action=pass'" value="【取消/审核】选中的信息"> 
        <input type="submit" onClick="myform.action='del.php';myform.target='_self';return ConfirmDel()" value="删除选中的信息">
        <input name="pagename" type="hidden"  value="zs_list.php?b=<?php echo $b?>&shenhe=<?php echo $shenhe?>&keyword=<?php echo $keyword?>&page=<?php echo $page ?>">
        <input name="tablename" type="hidden"  value="zzcms_zhaoshang">
  </div>
</form>
<div class="border center"><?php echo showpage_admin()?></div>
<?php
}
$t2 = microtime(true);
echo formatnumber($totlenum) ."条,耗时".round($t2-$t1,3)."秒";
?>
</body>
</html>