<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
$page=isset($_POST["page"])?$_POST["page"]:1;//只从修改页传来的值,返回列表页用
checkid($page);
$id=isset($_POST["id"])?$_POST["id"]:0;
checkid($id,1);

$title=str_replace("{","",$title);//过滤{ 如果这里填写调用标签如{#showad:4,0,yes,yes,首页第一行}就会在label中反复替换出现布局上的错乱
$link=str_replace("{","",$link);

if (isset($_POST["noimg"])){$img='';}

$bigclassname=$_POST["bigclassid"];
$smallclassname=$_POST["smallclassid"];

if ($starttime=="") {$starttime=date('Y-m-d');}
if ($endtime==""){$endtime=date('Y-m-d',time()+60*60*24*365);}
$elite=$_POST["elite"];
checkid($elite,1);

$msg='';
if ($img<>''){
	if (substr($img,0,4) == "http"){
		$img_bendi=grabimg($img,"");//如果是远程图片保存到本地
		if($img_bendi):$msg="远程图片".$img."已保存到本地：".$img_bendi."<br>";else:$msg="远程图片".$img."保存到本地 失败";endif; 
		$img=substr($img_bendi,strpos($img_bendi,"/uploadfiles"));//注：这里变量要换成$img以供入库用。在grabimg函数中$img被加了zzcmsroot这里要去掉 
	}
		
	$imgsmall=str_replace(siteurl,"",getsmallimg($img));
	if (file_exists(zzcmsroot.$imgsmall)===false && file_exists(zzcmsroot.$img)!==false){//小图不存在，且大图存在的情况下，生成缩略图
	makesmallimg($img);//同grabimg一样，函数里加了zzcmsroot
	}	
}


checkstr($img,"upload");//入库前查上传文件地址是否合格

if(isset($action)&&$action=='add'){
checkadminisdo("adv_add");
$isok=query("INSERT INTO zzcms_ad (bigclassname,smallclassname,province,city,title,titlecolor,link,img,username,starttime,endtime,elite,sendtime)
VALUES
('$bigclassname','$smallclassname','$province','$city','$title','$titlecolor','$link','$img','$username','$starttime','$endtime','$elite','".date('Y-m-d H:i:s',time()-(showadvdate+1)*60*60*24)."')");
$id=insert_id();

}elseif(isset($action)&&$action=='modify'){
checkadminisdo("adv_modify");
$isok=query("update zzcms_ad set bigclassname='$bigclassname',smallclassname='$smallclassname',province='$province',city='$city',title='$title',titlecolor='$titlecolor',link='$link',
img='$img',username='$username',nextuser='$nextuser',
starttime='$starttime',endtime='$endtime',elite='$elite' where id='$id'");		
}
setcookie("title",$title,time()+3600*24,"/admin");
setcookie("bigclassid",$bigclassname,time()+3600*24,"/admin");
setcookie("smallclassid",$smallclassname,time()+3600*24,"/admin");
setcookie("province",$province,time()+3600*24,"/admin");
setcookie("link",$link,time()+3600*24,"/admin");
?>
  
<div class="boxsave"> 
    <div class="title">
	<?php
	if ($_REQUEST["action"]=="add") {echo "添加 ";}else{echo"修改";}
	if ($isok){echo"成功";}else{echo "失败";}
     ?>
	</div>
	<div class="content_a">
	标题：<span style="color:<?php echo $titlecolor?>"><?php echo $title?></span><br/>
	链接：<?php echo $link?>
	<div class="editor">
	<li><a href="ad.php?action=add">[继续添加]</a></li>
	<li><a href="ad.php?action=modify&id=<?php echo $id?>">[修改]</a></li>
	<li><a href="ad_list.php?b=<?php echo $bigclassname?>&s=<?php echo $smallclassname?>&page=<?php echo $page?>">[返回]</a></li>
	</div>
	</div>
	</div>

<?php
if ($msg<>'' ){echo "<div class='border'>" .$msg."</div>";}
?>
</body>
</html>