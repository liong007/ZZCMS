<?php
require("admin.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<title></title>
</head>
<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td class="admintitle">从Excel(要保存为97-2003兼容格式)导入<?php echo channeldl?>商信息</td>
  </tr>
</table>
<div class="border2" style="padding:10px"> <strong>要导入的文件要求：Excel表格文件(扩展名为.xls，要保存为97-2003兼容格式，列名可以不同，没有的列用空列填充<br>
  </strong>列顺序为：classid（大类ID），<?php echo channeldl?>商姓名，电话，Email，<?php echo channeldl?>产品，<?php echo channeldl?>区域，<?php echo channeldl?>商简介，接收人（用户名）<br>
    <strong>第二步：点击下面的选择文件，上传</strong>  
<hr/>
<iframe src="../up/uploadxls_form.php" width="100%" height="50" frameborder="0" scrolling="no"></iframe>	
</div>
<form action="" method="post" name="myform" id="myform" onSubmit="return CheckForm();">        
  <table width="100%" border="0" cellpadding="5" cellspacing="1" class="bgcolor2">
    <tr class="trtitle"> 
      <td width="20%"  >文件名</td>
      <td width="10%" > 文件大小</td>
      <td width="33%"  >操作</td>
    </tr>
	<?php
	$dir = opendir("../daili_excel");
while(($file = readdir($dir))!=false){
 if ($file!="." && $file!="..") { //不读取. ..
    //$f = explode('.', $file);//用$f[0]可只取文件名不取后缀。
	?>
    <tr class="trcontent"> 
      <td  > 
        <?php
		echo "<a>".$file."</a>";
		?>
      </td>
      <td ><?php 
	  $fp="../daili_excel/".$file;
	  echo filesize($fp)/1024 ?>K</td>
      <td>
	  <a href="dl_data_add.php?filename=<?php echo $file?>">导入到数据库</a>
	 | <a href="?action=del">清空所有上传文件</a>
	 
	
	  </td>
    </tr>
	<?php
	}
	}
closedir($dir);	 	

if ($_REQUEST["action"]=='del'){
del_dirandfile("../daili_excel",false) ;
echo "<script>location.href='?'</script>";
}
?>
</table>
</form>
		  				   	 
</body>
</html>