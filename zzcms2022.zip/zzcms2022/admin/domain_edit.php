<?php
require("admin.php");
checkadminisdo("user");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<?php
$go=0;
$id=isset($_REQUEST['id'])?$_REQUEST['id']:0;
checkid($id,1);

	if ($action=="add"){
	query("insert into zzcms_userdomain (username,domain)VALUES('$username','$domain') ");
	$go=1;
	}elseif ($action=="modify"){
	query("update zzcms_userdomain set domain='$domain' where id='". $id."' ");
	$go=1;
	}

?>
</head>
<body>
<?php
if ($go==1){
echo "<script>location.href='domain_list.php'</script>";
}
?>
</body>
</html>