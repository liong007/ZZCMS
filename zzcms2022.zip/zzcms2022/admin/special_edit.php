<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../3/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="../js/jquery.js"></script>  
<script language = "JavaScript">
$(document).ready(function(){  
  $("#title").change(function() { //jquery 中change()函数  
	$("#quote").load(encodeURI("../ajax/specialtitlecheck_ajax.php?id="+$("#title").val()));//jqueryajax中load()函数 加encodeURI，否则IE下无法识别中文参数 
  });  
});  

function CheckForm(){
/*if (document.myform.bigclassid.value==""){
    alert("请选择大类别！");
	document.myform.bigclassid.focus();
	return false;
  } */
if (document.myform.title.value==""){
    alert("标题不能为空！");
	document.myform.title.focus();
	return false;
  } 
//创建正则表达式
var re=/^[0-9]*$/;		
	if(document.myform.elite.value==""){
		alert("请输入数值！");
		document.myform.elite.focus();
		return false;
	}
	if(document.myform.elite.value.search(re)==-1)  {
    alert("必须为正整数！");
	document.myform.elite.value="";
	document.myform.elite.focus();
	return false;
  	}
	
	if(document.myform.elite.value>127)  {
    alert("不得大于127");
	document.myform.elite.focus();
	return false;
  	} 
	document.getElementById('loading').style.display='block'; 	    
} 
</script>
</head>
<body>
<?php
$page = isset($_POST['page'])?$_POST['page']:1;//只从修改页传来的值
checkid($page);
$id = isset($_POST['id'])?$_POST['id']:0;
checkid($id,1);
$passed = isset($_POST['passed'])?$_POST['passed']:0;
checkid($passed,1);

$classid = isset($_POST['classid'])?$_POST['classid']:0;
checkid($classid,1);

$newtable="zzcms_special".$classid;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$newtable."'"))<>1) {
addtable("zzcms_special",$classid);//加表
}

$classname="";
$rs = query("select classname from zzcms_specialclass where classid='".$classid."'"); 
$row= fetch_array($rs);
$classname=$row["classname"];

//---保存内容中的远程图片，并替换内容中的图片地址
$msg='';
$imgs=getimgincontent(stripfxg($content,true),2);
if (is_array($imgs)){
foreach ($imgs as $value) {
	checkstr($value,"upload");//入库前查上传文件地址是否合格
	if (substr($value,0,4) == "http"){
	$value=getimg2($value);//做二次提取，过滤后面的图片样式
	$img_bendi=grabimg($value,"");//如果是远程图片保存到本地
	if($img_bendi):$msg=$msg."远程图片：".$value."已保存为本地图片：".$img_bendi."<br/>";else:$msg=$msg."远程图片：".$value."保存失败<br/>";endif;
	$img_bendi=substr($img_bendi,strpos($img_bendi,"/uploadfiles"));//在grabimg函数中$img被加了zzcmsroo这里要去掉
	$content=str_replace($value,$img_bendi,$content);//替换内容中的远程图片为本地图片
	}
}
}
//---end

//---保存封面图片，单张
if ($img==''){//放到内容下面，避免多保存一张远程图片
$img=getimgincontent(stripfxg($content,true));
$img=getimg2($img);
}

if ($img<>''){
checkstr($img,"upload");//入库前查上传文件地址是否合格
	if (substr($img,0,4) == "http"){//$img=trim($_POST["img"])的情况下，这里有可能是远程图片地址
		$img=grabimg($img,"");//如果是远程图片保存到本地
		if($img):$msg=$msg. "远程图片已保存到本地：".$img."<br>";else:$msg=$msg. "false";endif; 
		$img=substr($img,strpos($img,"/uploadfiles"));//在grabimg函数中$img被加了zzcmsroo。这里要去掉 
	}
		
	$imgsmall=str_replace(siteurl,"",getsmallimg($img));
	if (file_exists(zzcmsroot.$imgsmall)===false && file_exists(zzcmsroot.$img)!==false){//小图不存在，且大图存在的情况下，生成缩略图
	makesmallimg($img);//同grabimg一样，函数里加了zzcmsroot
	}	
}
//---end

if ($keywords=="" ){$keywords=$title;}

if (isset($_POST["elite"])){
$elite=$_POST["elite"];
	if ($elite>127){
	$elite=127;
	}elseif ($elite<0){
	$elite=0;
	}
}else{
$elite=0;
}
checkid($elite,1);
$jifen=$_POST["jifen"];
checkid($jifen,1);
if ($_REQUEST["action"]=="add"){
checkadminisdo("special_add");
//判断是不是重复信息,为了修改信息时不提示这段代码要放到添加信息的地方
//$sql="select title,editor from zzcms_special where title='".$title."'";
//$rs = query($sql); 
//$row= fetch_array($rs);
//if ($row){
//showmsg('此信息已存在，请不要发布重复的信息！','special_add.php');
//}

$isok=query("insert into zzcms_special
(classid,classname,title,laiyuan,keywords,description,content,img,groupid,jifen,elite,passed,sendtime) 
values
('$classid','$classname','$title','$laiyuan','$keywords','$description','$content','$img','$groupid','$jifen','$elite','$passed','".date('Y-m-d H:i:s')."')");  
$id=insert_id();
//分表
$isok=query("insert into `".$newtable."`
(zid,classname,title,laiyuan,keywords,description,content,img,groupid,jifen,elite,passed,sendtime) 
values
('$id','$classname','$title','$laiyuan','$keywords','$description','$content','$img','$groupid','$jifen','$elite','$passed','".date('Y-m-d H:i:s')."')"); 

	
}elseif ($_REQUEST["action"]=="modify"){
checkadminisdo("special_modify");
$isok=query("update zzcms_special set classid='$classid',classname='$classname',title='$title',laiyuan='$laiyuan',keywords='$keywords',description='$description',
content='$content',img='$img',groupid='$groupid',jifen='$jifen',sendtime='".date('Y-m-d H:i:s')."',elite='$elite',passed='$passed' where id='$id'");	

//分表
$sql="select zid from `".$newtable."` where zid='$id' ";
$rs =query($sql); 
$row = num_rows($rs);
if ($row){//如果分表有此记录则更新
$isok=query("update `".$newtable."` set classname='$classname',title='$title',laiyuan='$laiyuan',keywords='$keywords',description='$description',
content='$content',img='$img',groupid='$groupid',jifen='$jifen',sendtime='".date('Y-m-d H:i:s')."',elite='$elite',passed='$passed' where zid='$id'");	
}else{//如果分表无有此记录则插入
$isok=query("insert into `".$newtable."`
(zid,classname,title,laiyuan,keywords,description,content,img,groupid,jifen,elite,passed,sendtime) 
values
('$id','$classname','$title','$laiyuan','$keywords','$description','$content','$img','$groupid','$jifen','$elite','$passed','".date('Y-m-d H:i:s')."')"); 
}

}
setcookie("specialclassid",$classid,time()+3600*24,"/admin");
?>

<div class="boxsave"> 
    <div class="title">
	<?php
	if ($_REQUEST["action"]=="add") {echo "添加 ";}else{echo"修改";}
	if ($isok){echo"成功";}else{echo "失败";}
     ?>
	</div>
	<div class="content_a">
	名称：<?php echo $title?><br/>
	类别：<?php echo $classname ?><br/>
	推荐： <?php if ($elite<>0){echo "是" ;}else{ echo "否" ;}?>
	<div class="editor">
	<li><a href="special.php?action=add">[继续添加]</a></li>
	<li><a href="special.php?action=modify&id=<?php echo $id?>">[修改]</a></li>
	<li><a href="special_list.php?b=<?php echo $classid?>&page=<?php echo $page?>">[返回]</a></li>
	<li><a href="<?php echo getpageurl("special",$id)?>" target="_blank">[预览]</a></li>
	</div>
	</div>
	</div>
	
<?php
if ($msg<>'' ){echo "<div class='border'>" .$msg."</div>";}
?>
</body>
</html>