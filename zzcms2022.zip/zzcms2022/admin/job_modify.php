<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
<script language = "JavaScript">
function CheckForm(){
if (document.myform.bigclassid.value==""){
    alert("请选择类别！");
	document.myform.bigclassid.focus();
	return false;
}
if (document.myform.jobname.value==""){
    alert("名称不能为空！");
	document.myform.jobname.focus();
	return false;
}
}
</script>
</head>
<body>
<?php
//checkadminisdo("job_modify");
$page = isset($_GET['page'])?$_GET['page']:1;
checkid($page);
$id = isset($_GET['id'])?$_GET['id']:0;
checkid($id,1);
$sql="select * from zzcms_job where id='$id'";
$rs=query($sql);
$row=fetch_array($rs);
?>   
<div class="admintitle">修改招聘信息</div>
<form action="?do=save" method="post" name="myform" id="myform" onSubmit="return CheckForm();">
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td width="18%" align="right" class="border"> 类别 <font color="#FF0000">*</font></td>
      <td width="82%" class="border"><?php
        $rs=get_class_list("zzcms_jobclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==$row["classid"]) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?></td>
    </tr>
    <tr>
      <td align="right" class="border">职位<font color="#FF0000">*</font></td>
      <td class="border"><input name="jobname" type="text" id="cpname" value="<?php echo $row["title"]?>" size="45"></td>
    </tr>
	 
    <tr> 
      <td align="right" class="border">说明：</td>
      <td class="border"> <textarea name="sm" cols="40" rows="5" id="sm"><?php echo $row["sm"]?></textarea></td>
    </tr>
    <tr> 
      <td align="right" class="border">发布人：</td>
      <td class="border"><input name="editor" type="text" id="editor" value="<?php echo $row["editor"]?>" size="45"> 
        <input name="oldeditor" type="hidden" id="oldeditor" value="<?php echo $row["editor"]?>"></td>
    </tr>
    <tr> 
      <td align="right" class="border">审核：</td>
      <td class="border"><input name="passed" type="checkbox" id="passed" value="1"  <?php if ($row["passed"]==1) { echo "checked";}?>>
        （选中为通过审核） </td>
    </tr>
    
    <tr> 
      <td align="center" class="border">&nbsp;</td>
      <td class="border"><input name="id" type="hidden" id="id" value="<?php echo $row["id"]?>"> 
        <input name="sendtime" type="hidden" id="sendtime" value="<?php echo $row["sendtime"]?>"> 
        <input name="page" type="hidden" id="page" value="<?php echo $page?>"> 
        <input type="submit" name="Submit" value="修 改"></td>
    </tr>
  </table>
</form>
<?php
$do=isset($_GET['do'])?$_GET['do']:'';
if ($do=="save"){
checkadminisdo("job_modify");

$page = isset($_POST['page'])?$_POST['page']:1;//只从修改页传来的值
checkid($page);
$id = isset($_POST['id'])?$_POST['id']:0;
checkid($id,1);
$passed = isset($_POST['passed'])?$_POST['passed']:0;
checkid($passed,1);

$classid = isset($_POST['classid'])?$_POST['classid']:0;
checkid($classid,1);

$newtable="zzcms_job".$classid;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$newtable."'"))<>1) {
addtable("zzcms_job",$classid);//加表
}

query("update zzcms_job set classid='$classid',title='$jobname',sm='$sm',sendtime='$sendtime',passed='$passed' where id='$id'");

//分表
$sql="select zid from `".$newtable."` where zid='$id' ";
$rs =query($sql); 
$row = num_rows($rs);
if ($row){//如果分表有此记录则更新
$sql="update `".$newtable."` set title='$jobname',sm='$sm',sendtime='$sendtime',passed='$passed' where zid='$id'";
query($sql) or die (showmsg('出现错误'));
}else{//如果分表无有此记录则插入
$sql="INSERT INTO `".$newtable."`(zid,title,sm,sendtime,passed)VALUES('$id','$jobname','$sm','$sendtime','$passed')";
query($sql) or die (showmsg('INSERT分表出现错误'));
}

if ($editor<>$oldeditor) {
$rs=query("select comane,id from zzcms_user where username='".$editor."'");
$row = num_rows($rs);
if ($row){
$row = fetch_array($rs);
$userid=$row["id"];
$comane=$row["comane"];
}else{
$userid=0;
$comane="";
}
query("update zzcms_job set editor='$editor',userid='$userid',comane='$comane' where id='$id'");
query("update `".$newtable."` set editor='$editor',userid='$userid',comane='$comane' where zid='$id'");
}

echo "<script>location.href='job_list.php?page=".$page."'</script>";
}
?>
</body>
</html>