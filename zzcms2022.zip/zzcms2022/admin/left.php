<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
function showsubmenu(n){
//alert(document.getElementById("submenu"+n).style.height)
if (document.getElementById("submenu"+n).style.height==""||document.getElementById("submenu"+n).style.height=="0px"){
	var box=document.getElementById("left_div");
	items=box.getElementsByTagName("ul");
	for (var i=0;i<items.length;i++){			
	//items[i].style.cssText="height:0px";
	document.getElementById("submenu"+i).style.cssText="height:0px;";
	document.getElementById("showsubmenu"+i).style.cssText = 'transform: rotate(0deg);';
	}
	var box=document.getElementById("submenu"+n);
	var alinks=box.getElementsByTagName("a");
	var num=alinks.length;
	var ul_height=num*35;
	document.getElementById("submenu"+n).style.cssText="height:"+ul_height+"px";
	document.getElementById("showsubmenu"+n).style.cssText = 'transform: rotate(180deg);';
}else{
	document.getElementById("submenu"+n).style.cssText="height:0px";
	document.getElementById("showsubmenu"+n).style.cssText = 'transform: rotate(0deg);';
}
}
	
function changeCss(obj,lis){ 
for(var i=0;i<lis.length;i++){
lis[i].style.cssText="";} 
obj.style.cssText="background-color:#00AAFF;color:#FFF";} 
window.onload=function(){
var box=document.getElementById("left_div");
alinks=box.getElementsByTagName("a");
for(var i=0;i<alinks.length;i++){
alinks[i].onclick=function(){changeCss(this,alinks)}}}
</script>
</head>
<body>
<div id="left_div">
<h3 onClick="showsubmenu(0)" title="网站参数及功能设置"><img src="image/set.png"> 设置<span id="showsubmenu0"></span></h3>
<ul id="submenu0"> 
	<li><a href="wjtset.php" target="frmright">文件头</a></li>			
	<li><a href="siteconfig.php#siteskin" target="frmright">风格</a></li>
	<li><a href="siteconfig.php#SiteInfo" target="frmright">基本信息</a></li>
	<li><a href="siteconfig.php#SiteOpen" target="frmright">运行状态</a></li>
	<li><a href="siteconfig.php#SiteOption" target="frmright">功能参数</a></li>
    <li><a href="about_list.php" target="frmright">底部链接</a></li> 
	<li><a href="siteconfig.php#stopwords" target="frmright">限制字符</a></li> 
	<li><a href="siteconfig.php#SiteOpen" target="frmright">限制来访IP</a></li>
    <li><a href="siteconfig.php#qiangad" target="frmright">广告设置</a></li>
	<li><a href="siteconfig.php#userjf" target="frmright">积分功能</a></li>
	<li><a href="siteconfig.php#UpFile" target="frmright">上传文件</a></li>
	<li><a href="siteconfig.php#addimage" target="frmright">添加水印功能</a></li>	 
	<li><a href="siteconfig.php#alipay_set" target="frmright">支付接口</a></li>	 
    <li><a href="siteconfig.php#sendmail" target="frmright">发邮件接口</a></li>
	<li><a href="siteconfig.php#sendsms" target="frmright">发手机短信接口</a></li>
	<li><a href="qqlogin_set.php" target="frmright">QQ互联接口</a></li> 
	<li><a href="ucenter_config.php" target="frmright">整合Discuz! Ucenter接口</a></li> 
</ul>
<h3 onClick="showsubmenu(1)" title="单页"><img src="image/item.png"> 单页<span id="showsubmenu1"></span></h3>
	<ul id="submenu1">
	<li><a href="about_list.php"  target="frmright">单页管理</a></li>
	<li><a href="about.php?action=add"  target="frmright"><img src="image/icobig.gif"> 增加新单页</a></li>
	   <?php
$sql="select * from zzcms_about";
$rs=query($sql);
$row=num_rows($rs);
if (!$row){
echo "暂无单页";
}else{
while($row = fetch_array($rs)){
?>	
	<li><a href="about.php?action=modify&id=<?php echo $row["id"]?>" target="frmright"><?php echo $row["title"]?></a></li>
<?php
}
}
?>	
</ul>	
<h3 onClick="showsubmenu(2)" title="用户发布的各类信息在这里管理"><img src="image/info2.png"> 信息<span id="showsubmenu2"></span></h3>
<ul id="submenu2"> 
	  <li><a href="zs_list.php" target="frmright"><?php echo channelzs?></a><a href="tag.php?tablename=zzcms_tagzs" target="frmright"><?php echo channelzs?>关键词</a></li> 
	  <li><a href="dl_list.php" target="frmright"><?php echo channeldl?></a></li>
	<?php
	if (str_is_inarr(channel,'zixun')=='yes'){
	?>  
<li><a href="zx_list.php" target="frmright">资讯</a><a href="tag.php?tablename=zzcms_tagzx" target="frmright">资讯关键词</a><a href="pinglun_list.php" target="frmright">资讯评论</a></li>  
<?php
	  }
	if (str_is_inarr(channel,'pinpai')=='yes'){
	?>
	  <li><a href="pp_list.php" target="frmright">品牌</a></li> 
	<?php
	}
	if (str_is_inarr(channel,'job')=='yes'){
	?>  
	<li><a href="job_list.php" target="frmright">招聘</a></li>
	<?php
	}
	if (str_is_inarr(channel,'zhanhui')=='yes'){
	?>
	  <li><a href="zh_list.php" target="frmright">展会</a></li> 
	
	<?php
	}
	if (str_is_inarr(channel,'wangkan')=='yes'){
	?>	 
		 <li><a href="wangkan_list.php" target="frmright">网刊</a></li> 
	<?php
	}
	if (str_is_inarr(channel,'baojia')=='yes'){
	?>	 
		  <li><a href="baojia_list.php" target="frmright" >报价</a></li>
	<?php
	}
	if (str_is_inarr(channel,'special')=='yes'){
	?>	  
	<li><a href="special_list.php" target="frmright">专题</a></li> 
	<?php
	}
	if (str_is_inarr(channel,'ask')=='yes'){
	?>
	 <li><a href="ask_list.php" target="frmright">问答-问题</a><a href="answer_list.php" target="frmright">问答-答案</a></li> 
	 <?php
	}
	?>
	<li><a href="ztliuyan_list.php" target="frmright">展厅留言</a></li>
	<li><a href="usermessage.php" target="frmright">用户返馈</a></li> 
	<li><a href="licence.php" target="frmright">资质证书</a></li> 
	<li><a href="link_list.php" target="frmright">友情链接</a></li> 
	<li><a href="help_list.php?b=2" target="frmright">公告信息</a></li>
	<li><a href="help_list.php?b=1" target="frmright">帮助信息</a></li>
	<li><a href="domain_list.php" target="frmright">展厅域名</a></li>
	<li><a href="msg.php" target="frmright">用户短信模板</a></li> 
</ul>
	  
<h3 onClick="showsubmenu(3)" title="各类信息的类别在这里设置"><img src="image/info.png"> 类别<span id="showsubmenu3"></span></h3>
<ul id="submenu3">  
	<li><a href="class.php?tablename=zzcms_zhaoshangclass" target="frmright"><?php echo channelzs?>/<?php echo channeldl?>/品牌类别</a></li> 
	 <li><a href="class_sx.php" target="frmright">类别属性设置</a></li>
	 <?php
	//if (str_is_inarr(channel,'pinpai')=='yes'){
	//echo " <li><a href=\"class.php?tablename=zzcms_pinpaiclass\" target=\"frmright\">品牌类别</a></li>";
	//}
	if (str_is_inarr(channel,'zixun')=='yes'){
	?>
	  <li><a href="class.php?tablename=zzcms_zixunclass" target="frmright">资讯类别</a></li>
	  <?php
	}
	if (str_is_inarr(channel,'special')=='yes'){
	?>
	   <li><a href="class.php?tablename=zzcms_specialclass" target="frmright">专题类别</a></li> 
	   <?php
	}
	if (str_is_inarr(channel,'job')=='yes'){
	?>
	  <li><a href="class.php?tablename=zzcms_jobclass" target="frmright">招聘类别</a></li>
	<?php
	}
	if (str_is_inarr(channel,'ask')=='yes'){
	?>
	  <li><a href="class.php?tablename=zzcms_askclass" target="frmright">问答类别</a></li> 
	    <?php
	}
	if (str_is_inarr(channel,'zhanhui')=='yes'){
	?>  
      <li><a href="class.php?tablename=zzcms_zhanhuiclass" target="frmright">展会类别</a></li> 
	  <?php
	}
	if (str_is_inarr(channel,'wangkan')=='yes'){
	?>
	  <li><a href="class.php?tablename=zzcms_wangkanclass" target="frmright">网刊类别</a></li>  
	  <?php
	}
	?>
	<li><a href="class.php?tablename=zzcms_userclass" target="frmright">企业类别</a></li>
    <li><a href="adclass.php" target="frmright">广告类别</a></li> 
	<li><a href="class.php?tablename=zzcms_linkclass" target="frmright">友情链接类别</a></li> 
</ul>

<h3 onClick="showsubmenu(4)" title="网站上的广告在这里管理"><img src="image/ad.png"> 广告<span id="showsubmenu4"></span></h3>
<ul id="submenu4">  
<li><a href="ad_list.php" target="frmright">管理广告</a></li>
<li><a href="adclass.php" target="frmright">类别设置</a></li>
<li><a href="siteconfig.php?#qiangad" target="frmright">设置广告</a></li>
<li><a href="ad_user_manage.php" target="frmright">用户审请的广告</a></li>
</ul>

<h3 onClick="showsubmenu(5)" title="所有注册用户，用户组权限，所有管理员，管理员组权限，在这里管理"><img src="image/user.png"> 用户<span id="showsubmenu5"></span></h3>
<ul id="submenu5">  	
<li><a href="usermanage.php" target="frmright">用户管理</a><a href="usergroup.php?do=show" target="frmright">用户组</a></li>
		<li><a href="adminlist.php" target="frmright">管理员</a><a href="admingroup.php" target="frmright">管理员组</a></li>
		<li><a href="adminlog.php" target="frmright">管理员操作日志</a></li>
		<li><a href="siteconfig.php#usergr_power" target="frmright">个人用户权限设置</a></li>
	 	<li><a href="usernotreg.php" target="frmright" title="未进行邮箱验证的用户">未进行邮箱验证的用户</a></li>
 		<li><a href="domain_list.php" target="frmright" title="用户审请的展厅域名">用户审请的展厅域名</a></li>
		<li><a href="bad.php" target="frmright" title="用户不良操作记录">用户不良操作记录</a></li>	
		<li><a href="usermessage.php" target="frmright">用户返馈信息</a></li>     
</ul>	
		
<h3 onClick="showsubmenu(6)" title="所有的上传文件在这里管理"><img src="image/upfile.png"> 文件<span id="showsubmenu6"></span></h3>
<ul id="submenu6">  		
        <li><a href="siteconfig.php#UpFile" target="frmright">上传功能设置</a></li>
        <li><a href="siteconfig.php#addimage" target="frmright">水印功能设置</a></li>
        <li><a href="uploadfile_nouse.php" target="frmright"> 清理无用的上传文件</a></li>
</ul>
		 			
<h3 onClick="showsubmenu(7)" title="标签：显示指定的内容文章列表用的，并可控制内容的布局及显示顺序；配合模的使用，可以改变前台的任何内容、形式、风格。)"><img src="image/label.png"> 标签<span id="showsubmenu7"></span></h3>
<ul id="submenu7"> 			
			<li><a href="labelshow.php?channel=zhaoshang" target="frmright"><?php echo channelzs?>内容标签</a>
			<a href="labelclass.php?classname=zhaoshangclass" target="frmright"><?php echo channelzs?>类别标签</a></li>		
			<li><a href="labelshow.php?channel=daili" target="frmright"><?php echo channeldl?>内容标签</a>
			<a href="labelclass.php?classname=dailiclass" target="frmright"><?php echo channeldl?>类别标签</a></li>
<?php
	if (str_is_inarr(channel,'zixun')=='yes'){
	?>		
			<li><a href="labelshow.php?channel=zixun" target="frmright">资讯内容标签</a>
			<a href="labelclass.php?classname=zixunclass" target="frmright">资讯类别标签</a></li>			
			<?php
			}
	if (str_is_inarr(channel,'pinpai')=='yes'){
	?>
			<li><a href="labelshow.php?channel=pinpai" target="frmright">品牌内容标签</a>
			<a href="labelclass.php?classname=pinpaiclass" target="frmright">品牌类别标签</a></li>
	<?php
	}
	if (str_is_inarr(channel,'job')=='yes'){
	?>		
			<li><a href="labelshow.php?channel=job" target="frmright">招聘内容标签</a>
			<a href="labelclass.php?classname=jobclass" target="frmright">招聘类别标签</a></li>		
	
	<?php
	}
	if (str_is_inarr(channel,'wangkan')=='yes'){
	?>		
			<li><a href="labelshow.php?channel=wangkan" target="frmright">网刊内容标签</a>
			<a href="labelclass.php?classname=wangkanclass" target="frmright">网刊类别标签</a></li>
	<?php
	}
	if (str_is_inarr(channel,'baojia')=='yes'){
	?>		
			<li><a href="labelshow.php?channel=baojia" target="frmright">报价内容标签</a>
			<a href="labelclass.php?classname=baojiaclass" target="frmright">报价类别标签</a></li>
	<?php
	}
	if (str_is_inarr(channel,'special')=='yes'){
	?>		
			<li><a href="labelshow.php?channel=special" target="frmright">专题内容标签</a>
			<a href="labelclass.php?classname=specialclass" target="frmright">专题类别标签</a></li>
	<?php
	}
	if (str_is_inarr(channel,'zhanhui')=='yes'){
	?>		
			<li><a href="labelshow.php?channel=zhanhui" target="frmright">展会内容标签</a>
			<a href="labelclass.php?classname=zhanhuiclass" target="frmright">展会类别标签</a></li>
	<?php
	}
	if (str_is_inarr(channel,'ask')=='yes'){
	?>
	<li><a href="labelshow.php?channel=ask" target="frmright">问答内容标签</a>
	<a href="labelclass.php?classname=askclass" target="frmright">问答类别标签</a></li>
	<?php
	}
	?>	
			<li><a href="labelshow.php?channel=company" target="frmright">企业内容标签</a>
			<a href="labelclass.php?classname=companyclass" target="frmright">企业类别标签</a></li>
			<li><a href="labeladshow.php" target="frmright">广告内容标签</a>
			<a href="labeladclass.php" target="frmright">广告类别标签</a></li>
			<li><a href="labelshow.php?channel=link" target="frmright">友链内容标签</a>
			<a href="labelclass.php?classname=linkclass" target="frmright">友链类别标签</a></li>
			<li><a href="labelshow.php?channel=help" target="frmright">帮助内容标签</a></li>
			<li><a href="labelshow.php?channel=about" target="frmright">单页内容标签</a></li>
			<li><a href="labelshow.php?channel=guestbook" target="frmright">留言本内容标签</a></li>
</ul>
<h3 onClick="showsubmenu(8)" title="模板：指的是网站前台的皮肤文件，模板页内容为htm标签，自定义标签，css样式，js代码等。没有任何php源码。"><img src="image/template.png"> 模板<span id="showsubmenu8"></span></h3>
<ul id="submenu8"> 			
			<li><a href="template.php" target="frmright">网站模板</a></li>
			<li><a href="template_user.php" target="frmright">用户展厅模板</a></li>
</ul>

<h3 onClick="showsubmenu(9)" title="网站数据库在这里管理"><img src="image/data1.png"> 数据库<span id="showsubmenu9"></span></h3>
<ul id="submenu9"> 			
		<li><a href="databaseclear.php" target="frmright">初始化数据库</a></li>
		<li><a href="data_bak.html" target="frmright">备份/还原数据库</a></li>
</ul>
			
<h3 onClick="showsubmenu(10)" title="如果后台更新后，前台没有变化，点这里清理缓存"><img src="image/clear.png"> 清缓存<span id="showsubmenu10"></span></h3>
<ul id="submenu10"> 				
		<li><a href="cachedel.php" target="frmright">清理网站缓存</a></li>
		<li><a href="htmldel.php" target="frmright">清理HTML页</a></li>
		<li><a href="uploadfile_nouse.php" target="frmright"> 清理无用的上传文件</a></li>
</ul>

<h3 onClick="showsubmenu(11)" title="给注册用户发站内短消息，邮件，手机短信（需绑定第三方短信平台账号）"><img src="image/msg.png"> 发消息<span id="showsubmenu11"></span></h3>
<ul id="submenu11"> 
	<li><a href="message.php" target="frmright">站内短消息管理</a></li>
	<li><a href="sendmail.php" target="frmright">发E-mali</a><a href="siteconfig.php#sendmail" target="frmright">设置E-mali</a></li> 
	<li><a href="sendsms.php" target="frmright">发手机短信</a><a href="siteconfig.php#sendSms" target="frmright">设置手机短信</a></li>				
</ul>	
</div>
</body>
</html>