<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">  
</head>
<body>
<?php
checkid($classid);
$newtable="zzcms_zhaoshang".$classid;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$newtable."'"))<>1) {
addtable("zzcms_zhaoshang",$classid);//加表
}

$skin=isset($_POST['skin'])?$_POST["skin"]:"cp";
$shuxing_value="";
	if(!empty($_POST['sx'])){
    for($i=0; $i<count($_POST['sx']);$i++){
	$shuxing_value=$shuxing_value.($_POST['sx'][$i].'|||');
    }
	$shuxing_value=substr($shuxing_value,0,strlen($shuxing_value)-3);//去除最后面的"|||"
	}
$szm =getfirstchar_all($proname); 
//---保存内容中的远程图片，并替换内容中的图片地址
$msg='';
$imgs=getimgincontent(stripfxg($sm,true),2);
if (is_array($imgs)){
foreach ($imgs as $value) {
	checkstr($value,"upload");//入库前查上传文件地址是否合格
	if (substr($value,0,4) == "http"){
	$value=getimg2($value);//做二次提取，过滤后面的图片样式
	$img_bendi=grabimg($value,"");//如果是远程图片保存到本地
	if($img_bendi):$msg=$msg.  "远程图片：".$value."已保存为本地图片：".$img_bendi."<br>";else:$msg=$msg.  "远程图片".$value."保存到本地 失败";endif;
	$img_bendi=substr($img_bendi,strpos($img_bendi,"/uploadfiles"));//在grabimg函数中$img被加了zzcmsroo。这里要去掉
	$sm=str_replace($value,$img_bendi,$sm);//替换内容中的远程图片为本地图片
	}
}
}
//---end
if ($img==''){//放到内容下面，避免多保存一张远程图片
$img=getimgincontent(stripfxg($sm,true));
$img=getimg2($img);
}

if ($img<>''){
checkstr($img,"upload");//入库前查上传文件地址是否合格
	if (substr($img,0,4) == "http"){//$img=trim($_POST["img"])的情况下，这里有可能是远程图片地址
		$img=grabimg($img,"");//如果是远程图片保存到本地
		if($img):$msg=$msg.  "远程图片已保存到本地：".$img."<br>";else:$msg=$msg.  "远程图片保存到本地 失败";endif; 
		$img=substr($img,strpos($img,"/uploadfiles"));//在grabimg函数中$img被加了zzcmsroot这里要去掉 
	}
		
	$imgsmall=str_replace(siteurl,"",getsmallimg($img));
	if (file_exists(zzcmsroot.$imgsmall)===false && file_exists(zzcmsroot.$img)!==false){//小图不存在，且大图存在的情况下，生成缩略图
	makesmallimg($img);//同grabimg一样，函数里加了zzcmsroot
	}	
}

$passed=isset($_POST["passed"])?$_POST["passed"]:0;
checkid($passed,1);

if (isset($_POST["elite"])){
$elite=$_POST["elite"];
	if ($elite>127){
	$elite=127;
	}elseif ($elite<0){
	$elite=0;
	}
}else{
$elite=0;
}
if ($elite==''){$elite=0;}
checkid($elite,1);

if ($title=="") {$title=$proname;}
if ($keywords=="") {$keywords=$proname;}
if ($description=="") {$description=$proname;}
if ($eliteendtime=="") {$eliteendtime=date('Y-m-d H:i:s',time()+365*3600*24);}

if(isset($action)&&$action=='add'){
//checkadminisdo("zs_add");
$isok=query("insert into zzcms_zhaoshang
(classid,szm,prouse,title,sm,img,flv,zc,yq,shuxing_value,passed,elite,eliteendtime,titles,keywords,description,sendtime,tag,skin,link,groupid_guest,jifen,editor) 
values
('$classid','$szm','$prouse','$proname','$sm','$img','$flv','$zc','$yq','$shuxing_value','$passed','$elite','$eliteendtime','$title','$keywords','$description','".date('Y-m-d H:i:s')."','$tag','$skin','$link','$groupid_guest','$jifen','$editor')");  
$cpid=insert_id();

//分表中加记录
$isok=query("insert into `".$newtable."`
(zid,szm,prouse,title,sm,img,flv,zc,yq,shuxing_value,passed,elite,eliteendtime,titles,keywords,description,sendtime,tag,skin,link,groupid_guest,jifen,editor) 
values
('$cpid','$szm','$prouse','$proname','$sm','$img','$flv','$zc','$yq','$shuxing_value','$passed','$elite','$eliteendtime','$title','$keywords','$description','".date('Y-m-d H:i:s')."','$tag','$skin','$link','$groupid_guest','$jifen','$editor')"); 

}elseif (isset($action)&&$action=='modify'){
//更新主表记录
$isok=query("update zzcms_zhaoshang set classid='$classid',szm='$szm',prouse='$prouse',title='$proname',sm='$sm',img='$img',
flv='$flv',zc='$zc',yq='$yq',shuxing_value='$shuxing_value',passed='$passed',elite='$elite',eliteendtime='$eliteendtime',
titles='$title',keywords='$keywords',description='$description',sendtime='$sendtime',tag='$tag',skin='$skin',link='$link',groupid_guest='$groupid_guest',jifen='$jifen' where id='$cpid'");

//更新分表记录
$sql="select zid from `".$newtable."` where zid='$cpid' ";
$rs =query($sql); 
$row = num_rows($rs);
if ($row){//如果分表有此记录则更新
$isok=query("update `".$newtable."` set szm='$szm',prouse='$prouse',title='$proname',sm='$sm',img='$img',
flv='$flv',zc='$zc',yq='$yq',shuxing_value='$shuxing_value',passed='$passed',elite='$elite',eliteendtime='$eliteendtime',
titles='$title',keywords='$keywords',description='$description',sendtime='$sendtime',tag='$tag',skin='$skin',link='$link',groupid_guest='$groupid_guest',jifen='$jifen' where zid='$cpid'");
}else{//如果分表无有此记录则插入
$isok=query("insert into `".$newtable."`
(zid,szm,prouse,title,sm,img,flv,zc,yq,shuxing_value,passed,elite,eliteendtime,titles,keywords,description,sendtime,tag,skin,link,groupid_guest,jifen,editor) 
values
('$cpid','$szm','$prouse','$proname','$sm','$img','$flv','$zc','$yq','$shuxing_value','$passed','$elite','$eliteendtime','$title','$keywords','$description','".date('Y-m-d H:i:s')."','$tag','$skin','$link','$groupid_guest','$jifen','$editor')"); 
}

if ($editor<>$oldeditor) {
$rs=query("select groupid,qq,comane,id,renzheng,province,city,xiancheng from zzcms_user where username='".$editor."'");
$row = num_rows($rs);
if ($row){
$row = fetch_array($rs);
$groupid=$row["groupid"];
$userid=$row["id"];
$qq=$row["qq"];
$comane=$row["comane"];
$renzheng=$row["renzheng"];
$province_user=$row["province"];
$city_user=$row["city"];
$xiancheng_user=$row["xiancheng"];
}else{
$groupid=0;$userid=0;$qq="";$comane="";$renzheng=0;$province_user='';$city_user='';$xiancheng_user='';
}
$isok=query("update zzcms_zhaoshang set editor='$editor',userid='$userid',groupid='$groupid',qq='$qq',comane='$comane',province_user='$province_user',city_user='$city_user',xiancheng_user='$xiancheng_user',renzheng='$renzheng' where id='$cpid'");
$isok=query("update `".$newtable."` set editor='$editor',userid='$userid',groupid='$groupid',qq='$qq',comane='$comane',province_user='$province_user',city_user='$city_user',xiancheng_user='$xiancheng_user',renzheng='$renzheng' where cpid='$cpid'");
}

}
setcookie("zsclassid",$classid,time()+3600*24,"admin");
//echo "<script>location.href='zs_manage.php?keyword=".$_POST["editor"]."&page=".$_REQUEST["page"]."'<//script>";
?>
<div class="boxsave"> 
    <div class="title"> 
	<?php 
	if ($_REQUEST["action"]=="add") {echo "添加 ";}else{echo"修改";}
	if ($isok) {echo "成功";}else{echo "失败";}?>
	</div>
	<div class="content_a">
	名称：<?php echo $proname?><br>
	
	<div class="editor">
	<li><a href="zs.php?action=add">[继续添加]</a></li>
	<li><a href="zs.php?action=modify&id=<?php echo $cpid?>&page=<?php echo @$page?>&kind=<?php echo @$kind?>&keyword=<?php echo @$keyword?>">[修改]</a></li>
	<li><a href="<?php echo "zs_list.php?keyword=".@$keyword."&kind=".@$kind."&page=".@$page?>">[返回]</a></li>
	<li><a href="<?php echo getpageurl("zhaoshang",$cpid)?>" target="_blank">[预览]</a></li>
	</div>
	</div>
	</div>
<?php 
if ($msg<>'' ){echo "<div class='border'>" .$msg."</div>";}
?>
</body>
</html>