<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
$error=0;$msg='';
$page=isset($_POST["page"])?$_POST["page"]:1;//只从修改页传来的值
checkid($page);
$id=isset($_POST["id"])?$_POST["id"]:0;
checkid($id,1);

$passed=isset($_POST["passed"])?$_POST["passed"]:0;
checkid($passed,1);

$classid=isset($_POST["classid"])?$_POST["classid"]:0;
checkid($classid,1);

$newtable="zzcms_daili".$classid;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$newtable."'"))<>1) {
addtable("zzcms_daili",$classid);//加表
}

$companyname=isset($_POST["companyname"])?$_POST["companyname"]:"";
if ($dlsf=="个人" ){$companyname="";}

if ($cp=='' || $truename=='' || $tel==''){
$error=1;
$msg=$msg.'<li>请完整填写表单内容</li>';
}

if ($error==1){
tsmsg($msg);
}else{

	if(isset($action)&&$action=='add'){
	checkadminisdo("dl_add");
	$isok=query("insert into zzcms_daili(classid,cpid,title,province,city,xiancheng,content,company,companyname,truename,tel,address,email,sendtime) 		
	values('$classid','0','$cp','$province','$city','$xiancheng','$content','$dlsf','$companyname','$truename','$tel','$address','$email','".date('Y-m-d H:i:s')."')") ; 
	$id=insert_id(); 
	//分表
	$isok=query("insert into `".$newtable."`(zid,cpid,title,province,city,xiancheng,content,company,companyname,truename,tel,address,email,sendtime) 		
	values('$id',0,'$cp','$province','$city','$xiancheng','$content','$dlsf','$companyname','$truename','$tel','$address','$email','".date('Y-m-d H:i:s')."')") ; 
	
	}elseif (isset($action)&&$action=='modify'){
	checkadminisdo("dl_modify");
	$oldprovince=trim($_POST["oldprovince"]);
	if ($province=='请选择省份'){$province=$oldprovince;}
	//更新主表记录
	$isok=query("update zzcms_daili set classid='$classid',title='$cp',province='$province',city='$city',xiancheng='$xiancheng',content='$content',company='$dlsf',companyname='$companyname',
	truename='$truename',tel='$tel',address='$address',email='$email',saver='$saver',sendtime='".date('Y-m-d H:i:s')."',passed='$passed' where id='$id'");
	
	//更新分表记录
	$sql="select zid from `".$newtable."` where zid='$id' ";
	$rs =query($sql); 
	$row = num_rows($rs);
	if ($row){//如果分表有此记录则更新
	$isok=query("update `".$newtable."` set title='$cp',province='$province',city='$city',xiancheng='$xiancheng',content='$content',company='$dlsf',companyname='$companyname',
	truename='$truename',tel='$tel',address='$address',email='$email',saver='$saver',sendtime='".date('Y-m-d H:i:s')."',passed='$passed' where zid='$id'");
	}else{//如果分表无有此记录则插入
	$isok=query("insert into `".$newtable."`(zid,cpid,title,province,city,xiancheng,content,company,companyname,truename,tel,address,email,sendtime) 		
	values('$id',0,'$cp','$province','$city','$xiancheng','$content','$dlsf','$companyname','$truename','$tel','$address','$email','".date('Y-m-d H:i:s')."')") ; 
	}

	}
	if ($isok){echo "<script>location.href='dl_list.php?page=".$page."'</script>";}		
}

?>
</body>
</html>