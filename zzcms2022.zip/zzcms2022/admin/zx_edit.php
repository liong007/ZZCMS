<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
$page = isset($_POST['page'])?$_POST['page']:1;//只从修改页传来的值
checkid($page);
$id = isset($_POST['id'])?$_POST['id']:0;
checkid($id,1);
$classid = isset($_POST['classid'])?$_POST['classid']:0;
checkid($classid,1);

$newtable="zzcms_zixun".$classid;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$newtable."'"))<>1) {
addtable("zzcms_zixun",$classid);//加表
}
$link=addhttp($link);
//---保存内容中的远程图片，并替换内容中的图片地址
$msg='';
$imgs=getimgincontent(stripfxg($content,true),2);
if (is_array($imgs)){
foreach ($imgs as $value) {
	checkstr($value,"upload");//入库前查上传文件地址是否合格
	if (substr($value,0,4) == "http"){
	$value=getimg2($value);//做二次提取，过滤后面的图片样式
	$img_bendi=grabimg($value,"");//如果是远程图片保存到本地
	if($img_bendi):$msg=$msg."远程图片：".$value."已保存为本地图片：".$img_bendi."<br/>";else:$msg=$msg."远程图片：".$value."保存失败<br/>";endif;
	$img_bendi=substr($img_bendi,strpos($img_bendi,"/uploadfiles"));//在grabimg函数中$img被加了zzcmsroo这里要去掉
	$content=str_replace($value,$img_bendi,$content);//替换内容中的远程图片为本地图片
	}
}
}
//---end

//---保存封面图片，单张
checkstr($img,"upload");//入库前查上传文件地址是否合格
if ($img==''){//放到内容下面，避免多保存一张远程图片
$img=getimgincontent(stripfxg($content,true));
$img=getimg2($img);
}

if ($img<>''){
checkstr($img,"upload");//入库前查上传文件地址是否合格
	if (substr($img,0,4) == "http"){//$img=trim($_POST["img"])的情况下，这里有可能是远程图片地址
		$img=grabimg($img,"");//如果是远程图片保存到本地
		if($img):$msg=$msg. "远程图片已保存到本地：".$img."<br>";else:$msg=$msg. "false";endif; 
		$img=substr($img,strpos($img,"/uploadfiles"));//在grabimg函数中$img被加了zzcmsroo。这里要去掉 
	}
		
	$imgsmall=str_replace(siteurl,"",getsmallimg($img));
	if (file_exists(zzcmsroot.$imgsmall)===false && file_exists(zzcmsroot.$img)!==false){//小图不存在，且大图存在的情况下，生成缩略图
	makesmallimg($img);//同grabimg一样，函数里加了zzcmsroot
	}	
}
//---end

if ($keywords=="" ){$keywords=$title;}

if (isset($_POST["elite"])){
$elite=$_POST["elite"];
	if ($elite>127){
	$elite=127;
	}elseif ($elite<0){
	$elite=0;
	}
}else{
$elite=0;
}
checkid($elite,1);
$jifen=$_POST["jifen"];
checkid($jifen,1);
$passed = isset($_POST['passed'])?$_POST['passed']:0;
checkid($passed,1);
if ($_REQUEST["action"]=="add"){
checkadminisdo("zx_add");
//判断是不是重复信息,为了修改信息时不提示这段代码要放到添加信息的地方
//$sql="select title,editor from zzcms_zixun where title='".$title."'";
//$rs = query($sql); 
//$row= fetch_array($rs);
//if ($row){
//showmsg('此信息已存在，请不要发布重复的信息！','zx_add.php');
//}

$isok=query("insert into zzcms_zixun
(classid,province,title,link,laiyuan,keywords,description,content,img,groupid,jifen,elite,passed,sendtime) 
values
('$classid','$province','$title','$link','$laiyuan','$keywords','$description','$content','$img','$groupid','$jifen','$elite','$passed','".date('Y-m-d H:i:s')."')");  
$id=insert_id();

$isok=query("insert into `".$newtable."`
(zid,province,title,link,laiyuan,keywords,description,content,img,groupid,jifen,elite,passed,sendtime) 
values
('$id','$province','$title','$link','$laiyuan','$keywords','$description','$content','$img','$groupid','$jifen','$elite','$passed','".date('Y-m-d H:i:s')."')"); 
		
}elseif ($_REQUEST["action"]=="modify"){
checkadminisdo("zx_modify");
$isok=query("update zzcms_zixun set classid='$classid',province='$province',title='$title',link='$link',laiyuan='$laiyuan',keywords='$keywords',description='$description',content='$content',
img='$img',groupid='$groupid',jifen='$jifen',sendtime='".date('Y-m-d H:i:s')."',elite='$elite',passed='$passed' where id='$id'");	

//分表
$sql="select zid from `".$newtable."` where zid='$id' ";
$rs =query($sql); 
$row = num_rows($rs);
if ($row){//如果分表有此记录则更新
$isok=query("update `".$newtable."` set province='$province',title='$title',link='$link',laiyuan='$laiyuan',keywords='$keywords',description='$description',content='$content',
img='$img',groupid='$groupid',jifen='$jifen',sendtime='".date('Y-m-d H:i:s')."',elite='$elite',passed='$passed' where zid='$id'");	
}else{//如果分表无有此记录则插入
$isok=query("insert into `".$newtable."`
(zid,province,title,link,laiyuan,keywords,description,content,img,groupid,jifen,elite,passed,sendtime) 
values
('$id','$province','$title','$link','$laiyuan','$keywords','$description','$content','$img','$groupid','$jifen','$elite','$passed','".date('Y-m-d H:i:s')."')"); 
}

}
setcookie("zxclassid",$classid,time()+3600*24,"/admin");
?>

<div class="boxsave"> 
    <div class="title">
	<?php
	if ($_REQUEST["action"]=="add") {echo "添加 ";}else{echo"修改";}
	if ($isok){echo"成功";}else{echo "失败";}
     ?>
	</div>
	<div class="content_a">
	名称：<?php echo $title?><br/>
	推荐： <?php if ($elite<>0){echo "是" ;}else{ echo "否" ;}?>
	<div class="editor">
	<li><a href="zx.php?action=add">[继续添加]</a></li>
	<li><a href="zx.php?action=modify&id=<?php echo $id?>">[修改]</a></li>
	<li><a href="zx_list.php?b=<?php echo $classid?>&page=<?php echo $page?>">[返回]</a></li>
	<li><a href="<?php echo getpageurl("zixun",$id)?>" target="_blank">[预览]</a></li>
	</div>
	</div>
	</div>

<?php 
if ($msg<>'' ){echo "<div class='border'>" .$msg."</div>";}
?>
</body>
</html>