<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
checkadminisdo("zhanhui");
$page = isset($_POST['page'])?$_POST['page']:1;//只从修改页传来的值
checkid($page);
$id = isset($_POST['id'])?$_POST['id']:0;
checkid($id,1);
$classid = isset($_POST['classid'])?$_POST['classid']:0;
checkid($classid,1);
$newtable="zzcms_zhanhui".$classid;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$newtable."'"))<>1) {
addtable("zzcms_zhanhui",$classid);//加表
}
$passed = isset($_POST['passed'])?$_POST['passed']:0;
checkid($passed,1);

if (isset($_POST["elite"])){
$elite=$_POST["elite"];
	if ($elite>127){
	$elite=127;
	}elseif ($elite<0){
	$elite=0;
	}
}else{
$elite=0;
}
checkid($elite,1);

if(isset($action)&&$action=='add'){
checkadminisdo("zhanhui_add");
$sql="INSERT INTO zzcms_zhanhui (classid,title,province,timestart,timeend,content,passed,elite,sendtime)VALUES('$classid','$title','$address','$timestart','$timeend','$content','$passed','$elite','".date('Y-m-d H:i:s')."')";
query($sql) or die (showmsg('出现错误'));
$id=insert_id();
//分表
$sql="INSERT INTO `".$newtable."`(zid,title,province,timestart,timeend,content,passed,elite,sendtime)VALUES('$id','$title','$address','$timestart','$timeend','$content','$passed','$elite','".date('Y-m-d H:i:s')."')";
query($sql) or die (showmsg('INSERT分表出现错误'));

setcookie("zhclassid",$classid,time()+3600*24,"/admin");
}elseif(isset($action)&&$action=='modify'){
checkadminisdo("zhanhui_modify");
$sql="update zzcms_zhanhui set classid='$classid',title='$title',province='$address',timestart='$timestart',timeend='$timeend',content='$content',passed='$passed',elite='$elite',sendtime='".date('Y-m-d H:i:s')."' where id='$id'";
query($sql) or die (showmsg('出现错误'));

//分表
$sql="select zid from `".$newtable."` where zid='$id' ";
$rs =query($sql); 
$row = num_rows($rs);
if ($row){//如果分表有此记录则更新
$sql="update `".$newtable."` set title='$title',province='$address',timestart='$timestart',timeend='$timeend',content='$content',passed='$passed',elite='$elite',sendtime='".date('Y-m-d H:i:s')."' where zid='$id'";
query($sql) or die (showmsg('出现错误'));
}else{//如果分表无有此记录则插入
$sql="INSERT INTO `".$newtable."`(zid,title,province,timestart,timeend,content,passed,elite,sendtime)VALUES('$id','$title','$address','$timestart','$timeend','$content','$passed','$elite','".date('Y-m-d H:i:s')."')";
query($sql) or die (showmsg('INSERT分表出现错误'));
}
}
echo "<script>location.href='zh_list.php?page=$page'</script>";
?>	  
</body>
</html>