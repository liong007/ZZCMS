<?php
require("admin.php");
checkid($id,1);
if(isset($action)&&$action=='add'){
	checkadminisdo("about_add");
	$sql="insert into zzcms_about (title,content,skin)VALUES('$title','$content','$skin') ";
	
	query($sql) or die (tsmsg("保存失败",'about_list.php'));
	$id=insert_id();
	tsmsg('成功！',"about.php?action=modify&id=$id");	
	
}elseif (isset($action)&&$action=='modify'){
	checkadminisdo("about_modify");
	$sql="update zzcms_about set title='$title',content='$content',link='$link',skin='$skin' where id='". $id."' ";
	query($sql) or die (tsmsg("保存失败",'about_list.php'));
	tsmsg('成功！',"about.php?action=modify&id=$id");
}elseif(isset($action)&&$action=='del'){
	checkadminisdo("about_del");
	$sql="delete from zzcms_about where id='$id'";
	query($sql) or die (tsmsg("删除单页出现错误"));
	tsmsg('删除成功！',"about_list.php");
}
?>