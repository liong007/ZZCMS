<?php
session_start();
unset($_SESSION['admin']);
unset($_SESSION['pass']);
session_write_close();
//session_destroy();
echo "<script>location.href='../index.php'</script>";
?>