<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="style.css" rel="stylesheet" type="text/css">
<title></title>
<script language="JavaScript" src="../js/gg.js"></script>
<script language="JavaScript" src="../js/jquery.js"></script>
<script language="JavaScript" type="text/JavaScript">
function CheckForm(){  
if (document.form1.classname.value==""){
    alert("名称不能为空！");
	document.form1.classname.focus();
	return false;
}
}
</script>
</head>
<body>
<?php
if (isset($_GET['tablename'])){

setcookie("tablename",$_GET['tablename'],time()+3600*24,"admin");
echo "<script>location.href='?'</script>";
}
if ($_COOKIE['tablename']==''){
showmsg('tablename 无参数');
}
$tablenames='';
$rs = query("SHOW TABLES"); 
while($row = fetch_array($rs)) { 
$tablenames=$tablenames.$row[0]."#"; 
}
$tablenames=substr($tablenames,0,strlen($tablenames)-1);

if (str_is_inarr($tablenames,$_COOKIE['tablename'])=='no'){
showmsg('tablename 参数有误','index.php');//返回到首页避免造成死循环
}

$table=str_replace('class','',$_COOKIE['tablename']);//定义信息表变量供分表用

if ($_COOKIE['tablename']=="zzcms_zixunclass"){
$TitleClass="资讯";$TemplateFileName='zixun';
}elseif($_COOKIE['tablename']=="zzcms_zhaoshangclass"){
$TitleClass=channelzs."/".channeldl;$TemplateFileName='zhaoshang';
}elseif($_COOKIE['tablename']=="zzcms_pinpaiclass"){
$TitleClass="品牌";$TemplateFileName='pinpai';
}elseif($_COOKIE['tablename']=="zzcms_askclass"){
$TitleClass="问答";$TemplateFileName='ask';
}elseif($_COOKIE['tablename']=="zzcms_specialclass"){
$TitleClass="专题";$TemplateFileName='special';
}elseif($_COOKIE['tablename']=="zzcms_jobclass"){
$TitleClass="招聘";$TemplateFileName='job';
}elseif($_COOKIE['tablename']=="zzcms_userclass"){
$TitleClass="企业";$TemplateFileName='company';
}elseif($_COOKIE['tablename']=="zzcms_wangkanclass"){
$TitleClass="网刊";$TemplateFileName='wangkan';
}elseif($_COOKIE['tablename']=="zzcms_zhanhuiclass"){
$TitleClass="展会";$TemplateFileName='zhanhui';
}elseif($_COOKIE['tablename']=="zzcms_linkclass"){
$TitleClass="友情链接";$TemplateFileName='link';
}

$dowhat=isset($_REQUEST['dowhat'])?$_REQUEST['dowhat']:'';
switch ($dowhat){
case "addclass";
checkadminisdo("zxclass");
addclass();
break;
case "modifyclass";
checkadminisdo("zxclass");
modifyclass();
break;
default;
show_class();
}

function show_class(){
global $TitleClass;
$action=isset($_REQUEST['action'])?$_REQUEST['action']:'';
if ($action=="px") {
checkadminisdo("zxclass");
$sql="select * from `".$_COOKIE['tablename']."` where parentid=0";
$rs=query($sql);
while ($row=fetch_array($rs)){
$xuhao=$_POST["xuhao".$row["classid"].""];//表单名称是动态显示的，并于FORM里的名称相同。
	   if (trim($xuhao) == "" || is_numeric($xuhao) == false) {
	       $xuhao = 0;
	   }elseif ($xuhao < 0){
	       $xuhao = 0;
	   }else{
	       $xuhao = $xuhao;
	   }
query("update `".$_COOKIE['tablename']."` set xuhao='$xuhao' where classid='".$row['classid']."'");
}
}

if ($action=="del") {
checkadminisdo("zxclass");
$classid=trim($_GET["classid"]);
checkid($classid);
if ($classid<>"") {
$classids=displaylist($_COOKIE['tablename'],$classid);
$array_classids = explode(",",$classids);
foreach ($array_classids as $value) {
$newtable="zzcms_zhaoshang".$value;
query("DROP TABLE `$newtable`");//删除该类别及其下的所有子类招商分表
}	
query("delete from `".$_COOKIE['tablename']."` where classid in  ($classids)");//删除该类别及其下的所有子类
}     
echo "<script>location.href='?#B".$_GET["parentid"]."'</script>";
}
?>
<div class="admintitle0"><?php echo $TitleClass?>类别设置 <input type="submit" class="buttons"  onClick="javascript:location.href='?dowhat=addclass'" value="添加新类别"></div>
<form name="form1" method="post" action="?action=px">
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" class="bgcolor2">
    <tr class="trtitle"> 
      <td width="15%">类别名称</td>
      <td width="5%"  >classid</td>
      <td width="5%"  >parentid</td>
      <td width="15%"  >path</td>
      <td width="10%"  >拼音</td>
      <td width="5%" align="center" >前台显示</td>
      <td width="25%" >所用模板文件</td>
      <td width="10%"  >排序</td>
      <td width="10%" align="center"  >操作</td>
    </tr>
    <?php 
$rs=get_class_list($_COOKIE['tablename']);
foreach ($rs as $key => $val) {
	?>
    <tr class="trcontent"> 
      <td><a name="B<?php echo $val["classid"]?>"></a>
        <?php 
		if ($val["parentid"]==0){
		echo "<b>".$val["classname"]."</b>";
		}else{
		echo $val["classname"];
		}
		?></td>
      <td><?php echo $val["classid"]?></td>
      <td><?php echo $val["parentid"]?></td>
      <td><?php echo displaylink($_COOKIE['tablename'],$val["classid"])?></td>
      <td><?php echo $val["classzm"]?></td>
      <td align="center"><?php if ($val["isshow"]==1) { echo "显示";} else{ echo "<font color=red>不显</font>";}?></td>
      <td >
	  <?php
	   $skin=explode("|",$val["skin"]);
	  ?>
<a title="分类页所用模板" href="/template/<?php echo siteskin?>/<?php echo $skin[0]?>" target="_blank">分类页：<?php echo $skin[0]?></a><a title="列表页所用模板" href="/template/<?php echo siteskin?>/<?php echo @$skin[1]?>" target="_blank">列表页：<?php echo @$skin[1]?></a>	  </td>
      <td > <input name="<?php echo "xuhao".$val["classid"]?>" type="text"  value="<?php echo $val["xuhao"]?>" size="4"> 
      <input type="submit" name="Submit" value="更新序号"></td>
      <td align="center" >
	  <a href="?dowhat=modifyclass&classid=<?php echo $val["classid"]?>">修改</a>
	  <a href="?action=del&classid=<?php echo $val["classid"]?>&parentid=<?php echo $val["parentid"]?>" onClick="return ConfirmDel();">删除</a>
	  <a href="?dowhat=addclass&parentid=<?php echo $val["classid"]?>">添加子类</a></td>
    </tr>
    <?php
	}
	?>
  </table>
</form>
<?php
}

function addclass(){
global $table,$parentid,$TitleClass;
checkid($parentid,1);
$action=isset($_REQUEST['action'])?$_REQUEST['action']:'';
$FoundErr=0;$ErrMsg="";
if ($action=="add") {
    for($i=0; $i<count($_POST['classname']);$i++){
    	$classname=($_POST['classname'][$i]);
		$classzm=pinyin($classname);
		$isshow=isset($_POST['isshow'])?$_POST['isshow'][$i]:0;
		if ($classname!=''){
			$sql="select * from `".$_COOKIE['tablename']."` where parentid='" . $parentid . "' and classname='" . $classname . "'";
			$rs=query($sql);
			$row=num_rows($rs);
			if (!$row) {
				$sql="insert into `".$_COOKIE['tablename']."` (parentid,classname,classzm,isshow)values('$parentid','$classname','$classzm','$isshow')";
				query($sql) or die (tsmsg("失败，添加大类"));	
				$classid=insert_id();
				addtable($table,$classid);//加表
			}
		}
	}	
    echo "<script>location.href='?#B".$parentid."'</script>";	
}
if ($FoundErr==1){
tsmsg($ErrMsg);
}else{
?>

<div class="admintitle">添加<?php echo $TitleClass?>分类</div>
<form name="form" method="post" action="?dowhat=addclass" >
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0">
    <tr> 
      <td width="20%" align="right" class="border">所属父类</td>
      <td width="80%" class="border"> 
        <?php
        $rs=get_class_list($_COOKIE['tablename']);
        $str="<select name='parentid'>";
		$str.="<option value=0>".str_repeat('&nbsp;',8)."作为一级分类</option>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==$parentid) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?>
	 	 </td>
    </tr>
    <tr class="tdbg"> 
      <td align="right" class="border">&nbsp;</td>
      <td class="border">
	  <script language="javascript">   
//动态增加表单元素。
function AddElement(){   
var TemO=document.getElementById("add");  //得到需要被添加的html元素。 
if($.browser.msie) {
	var newInput = document.createElement("<input type='text' size='50' maxlength='50' name='classname[]' value='类别名称'>");
	TemO.appendChild(newInput);
	var newInput = document.createElement("<input name='isshow[]' type='checkbox' value='1' title='是否在前台显示该类别' checked>");
	TemO.appendChild(newInput);    
	}else{
	var newInput = document.createElement("input");
	newInput.type = "text";
	newInput.name = "classname[]";
	newInput.size = "50";
	newInput.maxlength = "50";
	newInput.value = "类别名称";
	TemO.appendChild(newInput);
	
	var newInput = document.createElement("input");
	newInput.type = "checkbox";
	newInput.name = "isshow[]";
	newInput.title = "是否在前台显示该类别";
	newInput.value = "1";
	newInput.checked =true;
	TemO.appendChild(newInput);
	}
	 
	var newline= document.createElement("hr"); 
	TemO.appendChild(newline);   
}   
</script>
<div id="add">
	   <input name="classname[]" type="text" size="50" maxlength="100" value="类别名称" style="margin:4px 0">
       <input name="isshow[]" type="checkbox" value="1" checked>
是否在前台显示该类别
<hr/>
	  </div> 
	  <img src="image/icobigx.gif" width="23" height="11"> <a href="javascript:void(0)" onClick='AddElement()'><img src='image/icobig.gif' border="0"> 添加新类别</a>	   
      <input name="action" type="hidden" id="action3" value="add">
      <input type="submit" value="提交"></td>
    </tr>
  </table>
</form>
<?php
}
}

function modifyclass(){
global $classid,$table,$TitleClass,$TemplateFileName;
checkid($classid);
$action=isset($_REQUEST['action'])?$_REQUEST['action']:'';
$FoundErr=0;$ErrMsg="";

if ($action=="modify"){
extract($_POST);//外部的在function不起作用
checkid($parentid,1);
$isshow=isset($_POST['isshow'])?$_POST['isshow'][0]:0;
$skin=$_POST["skin"][0]."|".$_POST["skin"][1];
if ($title=="") {$title=$classname;}
if ($keyword=="") {$keyword=$classname;}
if ($description==""){$description=$classname;}
if ($classzm==""){$classzm=pinyin($classname);}

	if ($classname==''){
	$FoundErr=1;
	$ErrMsg=$ErrMsg . "<li>请填类名！</li>";
	}
	
	if ($classid==$parentid){
	$FoundErr=1;
	$ErrMsg=$ErrMsg . "<li>父类id不能与子类id相同</li>";
	}
	
	$sql="select * from `".$_COOKIE['tablename']."` where classid='" .$classid."'";
	$rs=query($sql);
	$row=num_rows($rs);
	if (!$row){
	$FoundErr=1;
	$ErrMsg=$ErrMsg . "<li>此类不存在！</li>";
	}
	
	$sql="select * from `".$_COOKIE['tablename']."` where classzm='" .$classzm."' and classid<>'" .$classid."'";
	$rs=query($sql);
	$row=num_rows($rs);
	if ($row){
	$FoundErr=1;
	$ErrMsg=$ErrMsg . "<li>请更改类别字母，此字母已存在！</li>";
	}
	
	if ($classname<>$oldclassname || $parentid<>$oldparentid) {
	$sql="select * from `".$_COOKIE['tablename']."` where parentid='".$parentid."' and classname='".$classname."'";
	$rs=query($sql);
	$row=num_rows($rs);
	if ($row){
		$FoundErr=1;
		$ErrMsg=$ErrMsg . "<li>此名称已存在！</li>";
	}
	}
	
	if ($FoundErr==0) {
	$sql="update `".$_COOKIE['tablename']."` set parentid='$parentid',classname='$classname',classzm='$classzm',isshow='$isshow',title='$title',keyword='$keyword',description='$description',skin='$skin' where classid='$classid'";
	query($sql) or die (tsmsg("失败"));
	//addtable($table,$classid);//加表
	if ($classname<>$oldclassname) {//小类名改变的情况下
		if ($_COOKIE['tablename']=='zzcms_specialclass' ){//专题表中有classname其它没有
		query("Update `zzcms_".$TemplateFileName."` set classname='".$classname ."' where classname='".$oldclassname."'");
		}
	}
	echo "<script>location.href='?#S".$classid."'</script>";
	}
}

if ($FoundErr==1){
tsmsg($ErrMsg);
}else{
$sql="select * from `".$_COOKIE['tablename']."` where classid='".$classid."'";
$rs=query($sql);
$row=fetch_array($rs);
$parentid=$row['parentid'];
?>
<div class="admintitle">修改<?php echo $TitleClass?>类别</div>
<form name="form1" method="post" action="?dowhat=modifyclass" onSubmit="return CheckForm();">
  <table width="100%" border="0" cellpadding="5" cellspacing="0">
    <tr> 
      <td width="20%"  align="right" class="border">所属父类</td>
      <td width="80%" class="border"> 
	    <?php
        $rs=get_class_list($_COOKIE['tablename']);
        $str="<select name='parentid'>";
		$str.="<option value='0'>".str_repeat('&nbsp;',8)."作为一级分类</option>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==$parentid) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?>
      <input name="oldparentid" type="hidden" id="oldparentid" value="<?php echo $row["parentid"]?>"></td>
    </tr>
    <tr> 
      <td align="right" class="border">名称</td>
      <td class="border"> <input name="classname" type="text" id="classname" value="<?php echo $row["classname"]?>" size="60" maxlength="30">
        <input name="oldclassname" type="hidden" id="oldclassname" value="<?php echo $row["classname"]?>"></td>
    </tr>
    <tr>
      <td align="right" class="border">字母</td>
      <td class="border"><input name="classzm" type="text" id="classzm" value="<?php echo $row["classzm"]?>" size="60" maxlength="30"></td>
    </tr>
    <tr class="tdbg">
      <td align="right" class="border">是否显示该类别</td>
      <td class="border"><label>
        <input name="isshow[]" type="checkbox" id="isshow[]" value="1" <?php if ($row["isshow"]==1) { echo "checked";}?>>
        （选中为显示） </label></td>
    </tr>
    <tr> 
      <td colspan="2" class="border">SEO优化设置（如与大类名称相同，以下可以留空不填）</td>
    </tr>
    <tr> 
      <td align="right" class="border" >标题（title）</td>
      <td class="border" ><input name="title" type="text" id="title"  value="<?php echo $row["title"]?>" size="60" maxlength="255"></td>
    </tr>
    <tr> 
      <td align="right" class="border" >关键词（keyword）</td>
      <td class="border" ><input name="keyword" type="text" id="keyword"  value="<?php echo $row["keyword"]?>" size="60" maxlength="255">
        (多个关键词以“,”隔开)</td>
    </tr>
    <tr> 
      <td align="right" class="border" >描述（description）</td>
      <td class="border" ><input name="description" type="text" id="description"  value="<?php echo $row["description"]?>" size="60" maxlength="255">
        (适当出现关键词，最好是完整的句子)</td>
    </tr>
    <tr id="trseo">
      <td colspan="2" class="border" >模板选择</td>
    </tr>
    <tr id="trkeywords">
      <td align="right" class="border" >类别页模板文件</td>
      <td class="border" ><select name="skin[]" id="skin[]">
          <?php
$dir = opendir("../template/".siteskin);
$skin=explode("|",$row["skin"]);
while(($file = readdir($dir))!=false){
if ($file!="." && $file!=".." && strpos($file,$TemplateFileName."_class")!==false) { //不读取. ..
?>
          <option value="<?php echo $file?>" <?php if ($skin[0]==$file){ echo  "selected";}?>><?php echo $file?></option>
          <?php
}
}
closedir($dir);
?>
        </select>
      </td>
    </tr>
    <tr id="trkeywords">
      <td align="right" class="border" >列表页模板文件</td>
      <td class="border" ><select name="skin[]" id="skin[]">
          <?php
$dir = opendir("../template/".siteskin);
$skin=explode("|",$row["skin"]);
while(($file = readdir($dir))!=false){
if ($file!="." && $file!=".." && strpos($file,$TemplateFileName."_list")!==false) { //不读取. ..
?>
          <option value="<?php echo $file?>" <?php if (@$skin[1]==$file){ echo  "selected";}?>><?php echo $file?></option>
          <?php
}
}
closedir($dir);
?>
      </select></td>
    </tr>
    <tr> 
      <td class="border">&nbsp;</td>
      <td class="border"> <input name="classid" type="hidden" id="classid" value="<?php echo $row["classid"]?>">
        <input name="action" type="hidden" id="action4" value="modify"> 
        <input name="save" type="submit" id="save" value=" 修 改 "> </td>
    </tr>
  </table>
</form>
<?php
}
}
?>
</body>
</html>