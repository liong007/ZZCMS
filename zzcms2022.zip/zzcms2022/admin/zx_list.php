<?php
require("admin.php");
require("../inc/fy.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../js/gg.js"></script>
<?php
checkadminisdo("zx");
$action=isset($_REQUEST["action"])?$_REQUEST["action"]:'';
if( isset($_GET["page"]) && $_GET["page"]!="") {$page=$_GET['page'];}else{$page=1;}
checkid($page);
$shenhe=isset($shenhe)?$shenhe:'';
$keyword=isset($keyword)?$keyword:'';
$kind=isset($kind)?$kind:'title';
$b=isset($b)?$b:0;
$p=isset($_GET["p"])?$_GET["p"]:'';
$table='zzcms_zixun';
require("../inc/pass.php");
?>
</head>
<body>
<div class="admintitle">
<span> 
			  <form name="form1" method="post" action="?">
              <label><input type="radio" name="kind" value="editor" <?php if ($kind=="editor") { echo "checked";}?>>
              按发布人 </label>
              <label><input type="radio" name="kind" value="title" <?php if ($kind=="title") { echo "checked";}?>>
              按标题 </label>
              <input name="keyword" type="text" id="keyword" value="<?php echo $keyword?>"> 
              <input type="submit" name="Submit" value="查寻">
			  </form>
            </span>
			 资讯信息管理 <input name="submit3" type="submit" class="buttons" onClick="javascript:location.href='zx.php?action=add'" value="发布资讯信息">
</div>
<div class="border2">
<?php	
echo c('zzcms_zixunclass',$b);
?>
</div>
<?php
$page_size=pagesize_ht;  //每页多少条数据
$offset=($page-1)*$page_size;
$sql="select count(*) as total from zzcms_zixun where (1=1) ";
$sql2='';
if ($shenhe=="no") {  		
$sql2=$sql2." and passed=0 ";
}

if (isset($_GET['b'])){
$bidsNew=displaylist('zzcms_zixunclass',$_GET['b']);
setcookie("bids",$bidsNew,time()+3600*24,"admin");
$bids=$bidsNew;
}else{
$bids=isset($_COOKIE['bids'])?$_COOKIE['bids']:'';
}

if ($b<>0) {
$sql2=$sql2." and classid in ($bids)";
}

if ($p<>"") {  		
$sql2=$sql2." and province='".$p."' ";
}
if ($keyword<>"") {
	switch ($kind){
	case "editor";
	$sql2=$sql2. " and editor like '%".$keyword."%' ";
	break;
	case "title";
	$sql2=$sql2. " and title like '%".$keyword."%'";
	break;
	default:
	$sql2=$sql2. " and title like '%".$keyword."%'";
	}
}

$rs =query($sql.$sql2); 
$row = fetch_array($rs);
$totlenum = $row['total'];  
$totlepage=ceil($totlenum/$page_size);

$sql="select * from zzcms_zixun where (1=1) ";
$sql=$sql.$sql2;
$sql=$sql . " order by id desc limit $offset,$page_size";
$rs = query($sql); 
if(!$totlenum){
echo "暂无信息";
}else{
//echo $sql;
?>
<form name="myform" method="post" action=""> 
  
  <table width="100%" border="0" cellspacing="1" cellpadding="5" class="bgcolor2">
    <tr class="trtitle"> 
      <td width="2%" align="center" class="tdtitle">  <label for="chkAll" style="cursor: pointer;">全选</label> </td>
      <td width="10%" >所属类别</td>
      <td width="5%" >地区</td>
      <td width="20%" >标题</td>
      <td width="10%" >img</td>
      <td width="5%" align="center">信息状态</td>
      <td width="5%" align="center">发布时间</td>
      <td width="10%" align="center">发布人</td>
      <td width="5%" align="center">点击次数</td>
      <td width="5%" align="center">操作</td>
    </tr>
<?php
while($row = fetch_array($rs)){
?>
    <tr class="trcontent"> 
      <td align="center" class="docolor"> <input name="id[]" type="checkbox" id="id" value="<?php echo $row["id"]?>"></td>
      <td ><a href="?b=<?php echo $row["classid"]?>"><?php echo getclassname('zzcms_zixunclass',$row["classid"])?></a></td>
      <td ><a href="?p=<?php echo $row["province"]?>"><?php echo $row["province"]?></a></td>
      <td ><a href="<?php echo getpageurl("zixun",$row["id"])?>" target="_blank"><?php echo $row["title"]?></a></td>
      <td ><?php echo $row["img"]?></td>
      <td align="center" > <?php if ($row["passed"]==1){ echo"已审核";} else { echo"<font color=red>未审核</font>";}?><br>
<?php if ($row["elite"]<>0) { echo"<font color=red>被置顶(".$row["elite"].")</font>";}?> </td>
      <td align="center" title="<?php echo $row["sendtime"]?>"><?php echo date("Y-m-d",strtotime($row["sendtime"]))?></td>
      <td align="center"><?php echo $row["editor"]?></td>
      <td align="center"><?php echo $row["hit"]?></td>
      <td align="center" class="docolor"><a href="zx.php?action=modify&id=<?php echo $row["id"]?>&b=<?php echo $b?>&page=<?php echo $page?>">修改</a></td>
    </tr>
    <?php
}
?>
  </table>
  <div class="border"> <input name="chkAll" type="checkbox" id="chkAll" onClick="CheckAll(this.form)" value="checkbox">
        <label for="chkAll">全选</label>
        <input name="submit5" type="submit" onClick="myform.action='?action=pass'" value="【取消/审核】选中的信息">
        <input name="submit422" type="submit" onClick="myform.action='del.php';myform.target='_self';return ConfirmDel()" value="删除选中的信息"> 
      <input name="pagename" type="hidden"  value="zx_list.php?b=<?php echo $b?>&shenhe=<?php echo $shenhe?>&page=<?php echo $page ?>">
      <input name="tablename" type="hidden"  value="zzcms_zixun">
  </div>
</form>
<div class="border center"><?php echo showpage_admin()?></div>
<?php
}
?>
</body>
</html>