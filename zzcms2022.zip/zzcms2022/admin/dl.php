<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<script type="text/javascript" src="/js/jquery.js"></script>
<script type="text/javascript" language="JavaScript">
$.ajaxSetup ({
cache: false //close AJAX cache
});

function CheckForm(){
if (document.myform.cp.value==""){
    alert("请填写您要求<?php echo channeldl?>的产品名称！");
	document.myform.cp.focus();
	return false;
  }
if (document.myform.classid.value==""){
    alert("请选择产品类别！");
	document.myform.classid.focus();
	return false;
  }  
  if (document.myform.province.value=="请选择省份"){
    alert("请选择要<?php echo channeldl?>的省份！");
	document.myform.province.focus();
	return false;
  } 
if (document.myform.truename.value==""){
    alert("请填写真实姓名！");
	document.myform.truename.focus();
	return false;
}  
if (document.myform.tel.value==""){
    alert("请填写代联系电话！");
	document.myform.tel.focus();
	return false;
}   
if (document.myform.yzm.value==""){
    alert("请输入验证问题的答案！");
	document.myform.yzm.focus();
	return false;
}

function showsubmenu(sid){
whichEl = eval("submenu" + sid);
if (whichEl.style.display == "none"){
eval("submenu" + sid + ".style.display=\"\";");
}
}

function hidesubmenu(sid){
whichEl = eval("submenu" + sid);
if (whichEl.style.display == ""){
eval("submenu" + sid + ".style.display=\"none\";");
}
}
</SCRIPT>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>

<?php
if ($action=="add") {
?>
<div class="admintitle">发布<?php echo channeldl?>信息</div>
<form action="dl_edit.php?action=add" method="post" name="myform" id="myform" onSubmit="return CheckForm();">      
  <table width="100%" border="0" cellpadding="3" cellspacing="0">
    <tr> 
      <td align="right" class="border">想要<?php echo channeldl?>的产品</td>
      <td class="border"> <input name="cp" type="text" id="cp" size="45" maxlength="45">      </td>
    </tr>
    <tr> 
      <td align="right" class="border">产品类别</td>
      <td class="border"><?php
        $rs=get_class_list("zzcms_zhaoshangclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==@$_COOKIE['dlclassid']) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?></td>
    </tr>
    <tr> 
      <td width="130" align="right" class="border"><?php echo channeldl?>区域</td>
            <td class="border">
<script language="JavaScript" type="text/javascript">
$(document).ready(function(){  
	$("#tel").change(function() { //jquery 中change()函数  
	$("#telcheck").load(encodeURI("/ajax/dltelcheck_ajax.php?id="+$("#tel").val()));//jqueryajax中load()函数 加encodeURI，否则IE下无法识别中文参数 
	});  
});  
</script>
<select name="province" id="province"></select>
<select name="city" id="city"></select>
<select name="xiancheng" id="xiancheng"></select>
<script src="/js/areas.js"></script>
<script src="/js/area.js"></script>
<script type="text/javascript">
new PCAS('province', 'city', 'xiancheng', '<?php echo @$_COOKIE['province']?>', '<?php echo @$_COOKIE["city"]?>', '<?php echo @$_COOKIE["xiancheng"]?>');
</script>      </td>
    </tr>
    <tr> 
      <td width="130" align="right" class="border"><?php echo channeldl?>商介绍</td>
      <td class="border"> <textarea name="content" cols="45" rows="6" id="content"><?php echo @$_COOKIE["content"]?></textarea>      </td>
    </tr>
	
    <tr> 
      <td align="right" class="border"><?php echo channeldl?>身份</td>
      <td class="border"><input name="dlsf" id="dlsf_company" type="radio" value="公司" onClick="showsubmenu(1)">
         <label for="dlsf_company">公司 </label>
        <input name="dlsf" type="radio" id="dlsf_person" onClick="hidesubmenu(1)" value="个人" checked>
          <label for="dlsf_person">个人</label></td>
    </tr>
    <tr style="display:none" id='submenu1'>
      <td align="right" class="border">公司名称</td>
      <td class="border"><input name="company" type="text" id="yzm2" value="" size="45" maxlength="255" /></td>
    </tr>
    <tr> 
      <td align="right" class="border">真实姓名</td>
      <td class="border">
<input name="truename" type="text" id="truename" value="" size="45" maxlength="255" /></td>
    </tr>
    <tr> 
      <td align="right" class="border">电话</td>
      <td class="border">
	  <input name="tel" type="text" id="tel" value="" size="45" maxlength="255" />
	  <span id="telcheck"></span>
	  </td>
    </tr>
    <tr> 
      <td align="right" class="border">地址</td>
      <td class="border">
<input name="address" type="text" id="address" value="" size="45" maxlength="255" /></td>
    </tr>
    <tr> 
      <td align="right" class="border">E-mail</td>
      <td class="border"><input name="email" type="text" id="email" value="" size="45" maxlength="255" /></td>
    </tr>
    <tr> 
      <td align="right" class="border">&nbsp;</td>
      <td class="border"> 
        <input name="Submit" type="submit" class="buttons" value="发 布"></td>
    </tr>
  </table>
</form>
<?php
}

if ($action=="modify") {
checkadminisdo("dl");
$page = isset($_GET['page'])?$_GET['page']:1;
checkid($page);
$id = isset($_GET['id'])?$_GET['id']:0;
checkid($id,1);
$sql="select * from zzcms_daili where id='$id'";
$rs=query($sql);
$row=fetch_array($rs);
?>
<div class="admintitle"> 修改<?php echo channeldl?>信息</div>
<form action="dl_edit.php?action=modify" method="post" name="myform" id="myform" onSubmit="return CheckForm();">
  <table width="100%" border="0" cellpadding="3" cellspacing="0">
    <tr> 
      <td align="right" class="border"><?php echo channeldl?>产品</td>
      <td class="border"> <input name="cp" type="text" id="cp" value="<?php echo $row["title"]?>" size="45" maxlength="45">      </td>
    </tr>
    <tr> 
      <td align="right" class="border">产品类别</td>
      <td class="border"><?php
        $rs=get_class_list("zzcms_zhaoshangclass");
        $str="<select name='classid'>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==$row["classid"]) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?></td>
    </tr>
    <tr> 
      <td width="130" align="right" class="border"><?php echo channeldl?>区域</td>
      <td class="border">
<select name="province" id="province"></select>
<select name="city" id="city"></select>
<select name="xiancheng" id="xiancheng" onChange="addSrcToDestList()"></select>
<script src="/js/areas.js"></script>
<script src="/js/area.js"></script>
<script type="text/javascript">
new PCAS('province', 'city', 'xiancheng', '<?php echo $row['province']?>', '<?php echo $row["city"]?>', '<?php echo $row["xiancheng"]?>');
</script>            
<input name="oldprovince" type="hidden" id="oldprovince" value="<?php echo $row["province"]?>" /></td>
    </tr>
    <tr> 
      <td width="130" align="right" class="border">内容</td>
      <td class="border"> 
        <textarea name="content" cols="45" rows="6" id="content"><?php echo stripfxg($row["content"])?></textarea> 
        <input name="id" type="hidden" id="dlid" value="<?php echo $row["id"]?>">
        <input name="page" type="hidden" id="page" value="<?php echo $page?>">      </td>
    </tr>
    <tr> 
      <td align="right" class="border"><?php echo channeldl?>身份</td>
      <td class="border"><label>
	  <input name="dlsf" type="radio" value="公司" onClick="showsubmenu(1)" <?php if ($row["company"]=="公司") { echo "checked";}?>> 
        公司 </label> 
		<label>
		<input type="radio" name="dlsf" value="个人" onClick="hidesubmenu(1)" <?php if ($row["company"]=="个人"){ echo "checked";}?>> 
        个人</label></td>
    </tr>
    <tr <?php if ($row["company"]=="个人"){ echo " style='display:none'";}?> id='submenu1'> 
      <td align="right" class="border">公司名称</td>
      <td class="border"><input name="company" type="text" id="company" value="<?php echo $row["companyname"]?>" size="45" maxlength="255" /></td>
    </tr>
    <tr> 
      <td align="right" class="border">真实姓名</td>
      <td class="border"> 
        <input name="truename" type="text" id="truename" value="<?php echo $row["truename"]?>" size="45" maxlength="255" /></td>
    </tr>
    <tr> 
      <td align="right" class="border">电话</td>
      <td class="border"><input name="tel" type="text" id="tel" value="<?php echo $row["tel"]?>" size="45" maxlength="255" /></td>
    </tr>
    <tr> 
      <td align="right" class="border">地址</td>
      <td class="border"> 
        <input name="address" type="text" id="address" value="<?php echo $row["address"]?>" size="45" maxlength="255" /></td>
    </tr>
    <tr> 
      <td align="right" class="border">E-mail</td>
      <td class="border"><input name="email" type="text" id="email" value="<?php echo $row["email"]?>" size="45" maxlength="255" /></td>
    </tr>
    <tr>
      <td align="right" class="border">接收者</td>
      <td class="border"><input name="saver" type="text" id="saver" value="<?php echo $row["saver"]?>" size="45" maxlength="255" />
      （填用户名）</td>
    </tr>
    <tr>
      <td align="right" class="border">审核</td>
      <td class="border"><input name="passed" type="checkbox" id="passed" value="1"  <?php if ($row["passed"]==1) { echo "checked";}?>>
        （选中为通过审核） </td>
    </tr>
    <tr> 
      <td align="right" class="border">&nbsp;</td>
      <td class="border"> 
        <input name="Submit" type="submit" class="buttons" value="修 改"></td>
    </tr>
  </table>
</form>
<?php
}
?>
</body>
</html>