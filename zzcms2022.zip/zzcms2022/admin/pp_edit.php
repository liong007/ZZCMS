<?php
require("admin.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body> 
<?php
$page = isset($_POST['page'])?$_POST['page']:1;//只从修改页传来的值
checkid($page);
$cpid = isset($_POST['cpid'])?$_POST['cpid']:0;
checkid($cpid,1);
$passed = isset($_POST['passed'])?$_POST['passed']:0;
checkid($passed,1);
$classid = isset($_POST['classid'])?$_POST['classid']:0;
checkid($classid,1);
$newtable="zzcms_pinpai".$classid;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$newtable."'"))<>1) {
addtable("zzcms_pinpai",$classid);//加表
}

checkstr($img,"upload");//入库前查上传文件地址是否合格

if ($_REQUEST["action"]=="add"){
//checkadminisdo("pp_add");
$isok=query("insert into zzcms_pinpai(classid,title,content,img,editor,sendtime,passed) values('$classid','$cpname','$content','$img','$editor','".date('Y-m-d H:i:s')."','1')");  
$id=insert_id();

$isok=query("insert into `".$newtable."`(zid,title,content,img,editor,sendtime,passed) values('$id','$cpname','$content','$img','$editor','".date('Y-m-d H:i:s')."','1')");  

}elseif ($_REQUEST["action"]=="modify"){
checkadminisdo("pp_modify");
$isok=query("update zzcms_pinpai set classid='$classid',title='$cpname',content='$content',img='$img',sendtime='$sendtime',passed='$passed' where id='$id'");
//分表
$sql="select zid from `".$newtable."` where zid='$id' ";
$rs =query($sql); 
$row = num_rows($rs);
if ($row){//如果分表有此记录则更新
$isok=query("update `".$newtable."` set title='$cpname',content='$content',img='$img',sendtime='$sendtime',passed='$passed' where zid='$id'");
}else{//如果分表无有此记录则插入
$isok=query("insert into `".$newtable."`(zid,title,content,img,editor,sendtime,passed) values('$id','$cpname','$content','$img','$editor','".date('Y-m-d H:i:s')."','1')");
}

if ($editor<>$oldeditor) {
$rs=query("select comane,id from zzcms_user where username='".$editor."'");
$row = num_rows($rs);
	if ($row){
	$row = fetch_array($rs);
	$userid=$row["id"];
	$comane=$row["comane"];
	}else{
	$userid=0;
	$comane="";
	}
query("update zzcms_pinpai set editor='$editor',userid='$userid',comane='$comane',passed='$passed' where id='$id'");
query("update `".$newtable."` set editor='$editor',userid='$userid',comane='$comane',passed='$passed' where zid='$id'");
}
//echo "<script>location.href='pp_manage.php?page=".$page."'<//script>";
}

setcookie("pinpaiclassid",$classid,time()+3600*24,"/admin");
?>
<div class="boxsave"> 
    <div class="title"> 
	<?php 
	if ($_REQUEST["action"]=="add") {echo "添加 ";}else{echo"修改";}
	if ($isok) {echo "成功";}else{echo "失败";}?>
	</div>
	<div class="content_a">
	名称：<?php echo $cpname?><br>
	
	<div class="editor">
	<li><a href="pp.php?action=add">[继续添加]</a></li>
	<li><a href="pp.php?action=modify&id=<?php echo $id?>&page=<?php echo $page?>&kind=<?php echo $_POST["kind"]?>&keyword=<?php echo $_POST["keyword"]?>">[修改]</a></li>
	<li><a href="<?php echo "pp_list.php?keyword=".$_POST["keyword"]."&kind=".$_POST["kind"]."&page=".$_REQUEST["page"]?>">[返回]</a></li>
	<li><a href="<?php echo getpageurl("pinpai",$id)?>" target="_blank">[预览]</a></li>
	</div>
	</div>
	</div>
</body>
</html>