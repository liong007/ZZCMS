<?php
require("../inc/conn.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../3/PHPMailer/src/Exception.php';
require '../3/PHPMailer/src/PHPMailer.php';
require '../3/PHPMailer/src/SMTP.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<title></title>
<link href="../template/<?php echo siteskin?>/style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<div class="main" >
<?php
require("../inc/top2.php");
echo sitetop();
?>
<div class="pagebody" style="text-align:center;height:300px">
<?php
$username=trim($_POST["username"]);
$email=trim($_POST["newemail"]);
$emailsite="http://mail.".substr($email,strpos($email,"@")+1);

	$sql="select * from zzcms_usernoreg where username='".$username."'";
	$rs=query($sql);	
	$row=num_rows($rs);
	if ($row){
	$row=fetch_array($rs);	
	$checkcode=$row["checkcode"];
	$password=$row["password"];
	$somane=$row["somane"];
	}
	
//sendemail
$tomail = $email; //收件人
$subject="成功注册".sitename."会员通知";
$body= "<table width='100%'><tr><td style='font-size:14px;line-height:25px'>亲爱的".$somane . "：<br>&nbsp;&nbsp;&nbsp;&nbsp;您好！<br>欢迎您注册成为<a href='".siteurl."' target='_blank'>".sitename."</a>会员，你的用户名：".$username." 密码：".$password." 请妥善保管。";
$body=$body."<br><br>点击下面的这段链接激活您的注册帐号<br><a href=".siteurl."/reg/userregcheckemail.php?username=".$username."&checkcode=".$checkcode.">".siteurl."/reg/userregcheckemail.php?username=".$username."&checkcode=".$checkcode."</a>";
$body=$body."<br>如果点击后没有任何反应，请把这段链接复制到地址栏里直接打开。";
$body=$body."<br><br>感谢您对本站的支持！</td></tr></table>";

$fp="../template/".siteskin."/email.htm";
$f= fopen($fp,'r');
$strout = fread($f,filesize($fp));
fclose($f);
$strout=str_replace("{#body}",$body,$strout) ;
$strout=str_replace("{#siteurl}",siteurl,$strout) ;
$strout=str_replace("{#logourl}",logourl,$strout) ;
$mailbody=$strout;

$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
//try {
    //服务器配置
    $mail->CharSet ="UTF-8";                     //设定邮件编码
    $mail->SMTPDebug = 0;                        // 调试模式输出
    $mail->isSMTP();                             // 使用SMTP
    $mail->Host = smtpserver;                // SMTP服务器
    $mail->SMTPAuth = true;                      // 允许 SMTP 认证
    $mail->Username = sender;                // SMTP 用户名  即邮箱的用户名
    $mail->Password = smtppwd;             // SMTP 密码  部分邮箱是授权码(例如163邮箱)
    $mail->SMTPSecure = 'ssl';                    // 允许 TLS 或者ssl协议
    $mail->Port = 465;                            // 服务器端口 25 或者465 具体要看邮箱服务器支持

    $mail->setFrom(sender, 'Mailer');  //发件人
    //$mail->addAddress('ellen@example.com');  // 可添加多个收件人
    $mail->addReplyTo(sender, 'info'); //回复的时候回复给哪个邮箱 建议和发件人一致
    //$mail->addCC('cc@example.com');                    //抄送
    //$mail->addBCC('bcc@example.com');                    //密送
    //发送附件
    // $mail->addAttachment('../xy.zip');         // 添加附件
    // $mail->addAttachment('../thumb-1.jpg', 'new.jpg');    // 发送附件并且重命名
    //Content
    $mail->isHTML(true);                                  // 是否以HTML文档格式发送  发送后客户端可直接显示对应HTML内容
    $mail->Subject = $subject ;
    $mail->Body    = $mailbody ;
    $mail->AltBody = '如果邮件客户端不支持HTML则显示此内容';

	$mail->addAddress($tomail, 'Joe');  // 收件人
    $ok=$mail->send();
echo"<div class=box style='font-size:14px;margin:50px 0'><ul style=background-color:#FFFFFF;padding:10px>";
if($ok){
echo"<li><b>注册成功！</b></li>";
echo"<li>帐号需要激活后才能使用，激活邮件已发送到".$email."请登录到您的邮箱查收 </li>";
echo"<li style=padding:20px><input type=button class=button_big value=点击登录您的邮箱  onclick=\"window.open('".$emailsite."')\"/></li>";
}else{
echo"<li>邮件发送失败，请稍候直接登录网站！</li>";
}
echo"</ul></div>";
?>
</div>

</div>
</body>
</html>