<?php
if(@$step==5){
?>
<div class="body">
<div style="width:660px; height:500px; overflow: scroll;">
<?php
//@header("content-Type: text/html; charset=UTF-8");
//error_reporting(0);
//$dbcharset = 'utf8';
$admin=trim($_POST["admin"]);
$adminpwdtrue=trim($_POST["adminpwd"]);
$adminpwd=md5(trim($_POST["adminpwd"]));

$conn=connect($db_host,$db_user,$db_pass,$db_name,$db_port);
query("CREATE DATABASE $db_name");
query("SET NAMES 'utf8'"); 
select_db($db_name);

$get_sqls =file_get_contents("data.sql");
$sqls = explode(";",$get_sqls);
$cnt = count($sqls);
for($i=0;$i<$cnt;$i++){
   $sql = $sqls[$i];
   $result =query($sql);
   if($result){
   $a=$i+1;
       echo "成功执行第:".$a ."个查询<br>";
   }else{
       echo "导入失败:".mysqli_error();
   }
}
query("replace into `zzcms_admin` values('1','1','$admin','$adminpwd','0','','".date('Y-m-d h:i:s',time())."','','".date('Y-m-d h:i:s',time())."');");//写入管理员帐号
?>
</div>
<form action="index.php" method="post" id="myform">
<input type="hidden" name="admin" value="<?php echo $admin;?>"/>
<input type="hidden" name="adminpwdtrue" value="<?php echo $adminpwdtrue;?>"/>
<input type="hidden" name="step" value="6"/>
    <input type="button" value="上一步" class="btn" onclick="history.back(-1);" disabled/>
    <input type="submit" value="下一步" class="btn"/>
    &nbsp;&nbsp; 
  </form>
</div>
<?php
}
?>