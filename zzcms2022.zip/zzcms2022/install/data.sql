DROP TABLE IF EXISTS `zzcms_about`;
CREATE TABLE `zzcms_about` (
  `id` int(11) NOT NULL auto_increment,
  `title` char(50) default NULL COMMENT '标题',
  `content` longtext COMMENT '内容',
  `link` char(50) default NULL COMMENT '链接地址',
  `skin` char(20) default NULL COMMENT '模板',
  `passed` tinyint(4) default '1' COMMENT '是否审核',
  PRIMARY KEY  (`id`)
) COMMENT='网站介绍，网站底部连接表' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_admin`;
CREATE TABLE `zzcms_admin` (
  `id` int(11) NOT NULL auto_increment,
  `groupid` int(11) default NULL COMMENT '所属管理组ID',
  `admin` char(50) default NULL COMMENT '管理员',
  `pass` char(50) default NULL COMMENT '密码',
  `logins` int(11) default '0' COMMENT '登录次数',
  `loginip` char(50) default NULL COMMENT '登录IP',
  `lastlogintime` datetime default NULL COMMENT '记录下一下最后登陆时间',
  `showloginip` char(50) default NULL COMMENT '最后登录IP',
  `showlogintime` datetime default NULL COMMENT '最后登陆时间',
  PRIMARY KEY  (`id`)
) COMMENT='管理员表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_login_times`;
CREATE TABLE `zzcms_login_times` (
  `id` int(11) NOT NULL auto_increment,
  `ip` char(50) default NULL COMMENT '登录IP',
  `count` int(11) default '0' COMMENT '登录次数',
  `sendtime` datetime default NULL COMMENT '时间',
  PRIMARY KEY  (`id`)
) COMMENT='管理员登陆次数记录表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_admingroup`;
CREATE TABLE `zzcms_admingroup` (
  `id` int(11) NOT NULL auto_increment,
  `groupname` char(50) default NULL COMMENT '管理组名称',
  `config` varchar(1000) NOT NULL default '0' COMMENT '权限参数',
  PRIMARY KEY  (`id`)
) COMMENT='管理员权限组表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
replace into `zzcms_admingroup` values('1','超级管理员','zs#zs_modify#zs_del#zsclass#zskeyword#dl#dl_add#dl_modify#dl_del#guestbook#zh#zh_add#zh_modify#zh_del#zhclass#zx#zx_add#zx_modify#zx_del#zxclass#zxpinglun#zxtag#pp#pp_modify#pp_del#job#job_modify#job_del#jobclass#special#special_add#special_modify#special_del#specialclass#wangkan#wangkan_add#wangkan_modify#wangkan_del#wangkanclass#baojia#baojia_modify#baojia_del#ask#ask_add#ask_modify#ask_del#askclass#adv#adv_add#adv_modify#adv_del#advclass#adv_user#user#user_modify#user_del#usernoreg#userclass#usergroup#friendlink#friendlink_add#friendlink_modify#friendlink_del#about#about_add#about_modify#about_del#label#label_add#label_modify#label_del#licence#fankui#badusermessage#uploadfiles#sendmessage#sendmail#sendsms#announcement#helps#siteconfig#adminmanage#admingroup');
replace into `zzcms_admingroup` values('2','管理员(演示用)','zs#zs_modify#zskeyword#dl#dl_add#dl_modify#guestbook#zh#zh_add#zh_modify#zx#zx_add#zx_modify#zxpinglun#zxtag#pp#pp_modify#job#job_modify#special#special_add#special_modify#wangkan#wangkan_add#wangkan_modify#baojia#baojia_modify#ask#ask_add#ask_modify#adv#user#usernoreg#friendlink#about#label#licence#fankui#badusermessage#sendmessage#sendmail#sendsms');

DROP TABLE IF EXISTS `zzcms_bad`;
CREATE TABLE `zzcms_bad` (
  `id` int(11) NOT NULL auto_increment,
  `username` char(50) default NULL COMMENT '用户名',
  `ip` char(50) default NULL COMMENT '登陆IP',
  `dose` char(255) default NULL COMMENT '操作页面地址',
  `sendtime` datetime default NULL COMMENT '时间',
  `lockip` tinyint(4) default '0' COMMENT '锁定IP',
  PRIMARY KEY  (`id`)
) COMMENT='用户不良操作记录表' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_shuxing`;
CREATE TABLE `zzcms_shuxing` (
  `id` int(11) NOT NULL auto_increment,
  `classid` int(11) default 0 COMMENT '类别',
  `sxname` char(20) default NULL COMMENT '属性名',
  `sxz` char(20) default NULL COMMENT '属性值',
  `xuhao` int(11) NOT NULL default 0 COMMENT '排序序号',
  PRIMARY KEY  (`id`)
) COMMENT='类别属性表' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_zhaoshang`;
CREATE TABLE `zzcms_zhaoshang` (
  `id` int(4) NOT NULL auto_increment,
  `title` char(50) default NULL COMMENT '商品名',
  `link` char(255) default NULL COMMENT '链接地址',
  `szm` char(100) default NULL COMMENT '商品名首字母',
  `prouse` char(255) default NULL COMMENT '功能简介',
  `procompany` char(50) default NULL COMMENT '厂家',
  `sm` text COMMENT '说明',
  `xuhao` int(4) default NULL COMMENT '排列序号',
  `classid` int(4) default 0 COMMENT '类别ID',
  `img` char(255) default NULL COMMENT '商品图片地址',
  `flv` char(255) default NULL COMMENT '商品视频介绍地址',
  `province` char(50) default NULL COMMENT '招商省份',
  `city` char(50) default NULL COMMENT '城市',
  `xiancheng` char(50) default NULL COMMENT '县',
  `province_user` char(50) default NULL COMMENT '发布人所在省份',
  `city_user` char(50) default NULL COMMENT '城市',
  `xiancheng_user` char(50) default NULL COMMENT '县',
  `zc` char(255) default NULL COMMENT '政策支持',
  `yq` char(255) default NULL COMMENT '对代理商的要求',
  `other` char(255) default NULL COMMENT '其它',
  `shuxing_value`  char(255) default NULL COMMENT '自定义商品属性字段',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `timefororder` char(50) default NULL COMMENT '按刷新时间排序用字段',
  `editor` char(50) default NULL COMMENT '发布人',
  `eliteendtime` datetime default NULL COMMENT '推荐结束时间',
  `titles` char(255) default NULL COMMENT 'SEO标题',
  `keywords` char(255) default NULL COMMENT 'SEO关键词',
  `description` char(255) default NULL COMMENT 'SEO描述',
  `refresh` int(11) default '0' COMMENT '刷新次数',
  `hit` int(11) default '0' COMMENT '点击次数',
  `elite` tinyint(4) default '0' COMMENT '推荐',
  `passed` tinyint(4) default '0' COMMENT '审核',
  `userid` int(11) default '0' COMMENT '发布人用户ID',
  `comane` char(255) default NULL COMMENT '公司名',
  `qq` char(50) default NULL COMMENT 'QQ',
  `groupid` int(11) default '0' COMMENT '发布人所属用户组ID',
  `renzheng` tinyint(4) default '0' COMMENT '认证',
  `ppid` int(11) default '0' COMMENT '发布的商品所属品牌ID',
  `tag` char(255) default NULL COMMENT '关键字',
  `skin` char(25) default NULL COMMENT '商品展示页启用的模板文件名',
  `jifen` int(11) default '0' COMMENT '积分',
  `groupid_guest` int(11) default '0' COMMENT '浏览者用户组ID',
  PRIMARY KEY  (`id`)
) COMMENT='招商信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
ALTER TABLE  `zzcms_zhaoshang` ADD INDEX (  `province`,`city`,`xiancheng` ) ;
ALTER TABLE  `zzcms_zhaoshang` ADD INDEX (  `classid` ) ;
ALTER TABLE  `zzcms_zhaoshang` ADD INDEX (  `passed` ) ;

DROP TABLE IF EXISTS `zzcms_zhaoshangclass`;
CREATE TABLE `zzcms_zhaoshangclass` (
  `classid` int(11) NOT NULL auto_increment,
  `parentid` int(11) NOT NULL default 0 COMMENT '父类ID',
  `classname` char(50) NOT NULL COMMENT '类别名',
  `classzm` char(50) default NULL COMMENT '类别名首字母',
  `img` char(50) NOT NULL default '0' COMMENT '类别图片',
  `skin` char(50) default NULL COMMENT '启用的模板文件名',
  `xuhao` int(11) NOT NULL default '0' COMMENT '排序序号',
  `title` char(255) default NULL COMMENT 'SEO 标题',
  `keyword` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  `isshow` tinyint(4) NOT NULL default '1' COMMENT '是否在前台类别列表中显示该类',
  PRIMARY KEY  (`classid`)
) COMMENT='招商信息类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_pinpaiclass`;
CREATE TABLE `zzcms_pinpaiclass` (
  `classid` int(11) NOT NULL auto_increment,
  `parentid` int(11) NOT NULL default 0 COMMENT '父类ID',
  `classname` char(50) NOT NULL COMMENT '类别名',
  `classzm` char(50) default NULL COMMENT '类别名首字母',
  `img` char(50) NOT NULL default '0' COMMENT '类别图片',
  `skin` char(50) default NULL COMMENT '启用的模板文件名',
  `xuhao` int(11) NOT NULL default '0' COMMENT '排序序号',
  `title` char(255) default NULL COMMENT 'SEO 标题',
  `keyword` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  `isshow` tinyint(4) NOT NULL default '1' COMMENT '是否在前台类别列表中显示该类',
  PRIMARY KEY  (`classid`)
) COMMENT='招商信息类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_daili`;
CREATE TABLE `zzcms_daili` (
  `id` int(11) NOT NULL auto_increment,
  `classid` int(4) default 0 COMMENT '类别ID',
  `cpid` int(11) default '0' COMMENT '商品ID',
  `title` char(50) default NULL COMMENT '商品名',
  `province` char(50) default NULL COMMENT '招商省份',
  `city` char(50) default NULL COMMENT '城市',
  `xiancheng` char(50) default NULL COMMENT '县',
  `content` char(255) default NULL COMMENT '内容',
  `company` char(50) default NULL COMMENT '用户身份',
  `companyname` char(50) default NULL COMMENT '公司名',
  `truename` char(50) default NULL COMMENT '代理商名字',
  `address` char(255) default NULL COMMENT '地址',
  `tel` char(50) default NULL COMMENT '电话',
  `email` char(100) default NULL COMMENT 'Email',
  `editor` char(50) default NULL COMMENT '发布人',
  `saver` char(50) default NULL COMMENT '接收人',
  `savergroupid` int(11) default '0' COMMENT '接收人所属用户组ID',
  `ip` char(50) default NULL COMMENT '发布者IP',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `hit` int(11) default '0' COMMENT '点击次数',
  `looked` tinyint(4) default '0' COMMENT '是否被查看',
  `passed` tinyint(4) default '0' COMMENT '是否审核',
  `del` tinyint(4) default '0' COMMENT '是否删除',
  PRIMARY KEY  (`id`)
) COMMENT='代理信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
ALTER TABLE  `zzcms_daili` ADD INDEX (  `province`,`city`,`xiancheng` ) ;
ALTER TABLE  `zzcms_daili` ADD INDEX (  `classid` ) ;
ALTER TABLE  `zzcms_daili` ADD INDEX (  `passed` ) ;
ALTER TABLE  `zzcms_daili` ADD INDEX (  `saver` ) ;

DROP TABLE IF EXISTS `zzcms_looked_dls`;
CREATE TABLE `zzcms_looked_dls` (
  `id` int(11) NOT NULL auto_increment,
  `dlsid` int(11) default NULL COMMENT '在代理库中的ID',
  `username` char(50) default NULL COMMENT '用户名',
  PRIMARY KEY  (`id`)
) COMMENT='记录用户查看过的代理商信息表' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_looked_dls_oneday`;
CREATE TABLE `zzcms_looked_dls_number_oneday` (
  `id` int(11) NOT NULL auto_increment,
  `looked_dls_number_oneday` int(11) default NULL COMMENT '查看数',
  `username` char(50) default NULL COMMENT '用户名',
  `sendtime` datetime default NULL COMMENT '时间',
  PRIMARY KEY  (`id`)
) COMMENT='记录用户每天查看的代理商信息数' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_baojia`;
CREATE TABLE `zzcms_baojia` (
  `id` int(11) NOT NULL auto_increment,
  `classid` tinyint(4) default 0 COMMENT '类别ID',
  `title` char(50) default NULL COMMENT '商品名',
  `province` char(50) default NULL COMMENT '所在省份',
  `city` char(50) default NULL COMMENT '城市',
  `xiancheng` char(50) default NULL COMMENT '县',
  `price` char(50) default NULL COMMENT '价格',
  `danwei` char(50) default NULL COMMENT '单位',
  `companyname` char(50) default NULL COMMENT '公司名',
  `truename` char(50) default NULL COMMENT '姓名',
  `address` char(50) default NULL COMMENT '地址',
  `tel` char(50) default NULL COMMENT '电话',
  `email` char(100) default NULL COMMENT 'E-MAIL',
  `editor` char(50) default NULL COMMENT '发布人',
  `ip` char(50) default NULL COMMENT 'IP',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `hit` int(11) default '0' COMMENT '点击数',
  `passed` tinyint(4) default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='报价信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
ALTER TABLE  `zzcms_baojia` ADD INDEX (  `province` ,  `city` ,  `xiancheng` ) ;
ALTER TABLE  `zzcms_baojia` ADD INDEX (  `classid` ) ;

DROP TABLE IF EXISTS `zzcms_pinpai`;
CREATE TABLE `zzcms_pinpai` (
  `id` int(11) NOT NULL auto_increment,
  `title` char(255) default NULL COMMENT '名称',
  `classid` int(4) default 0 COMMENT '大类ID',
  `sm` longtext COMMENT '说明',
  `img` char(255) default NULL COMMENT '图片',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `editor` char(50) default NULL COMMENT '发布人',
  `comane` char(50) default NULL COMMENT '公司名',
  `userid` int(11) default '0' COMMENT '用户ID',
  `hit` int(11) default '0' COMMENT '点击数',
  `passed` tinyint(4) NOT NULL default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='品牌信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
ALTER TABLE  `zzcms_pinpai` ADD INDEX (  `classid` ) ;
ALTER TABLE  `zzcms_pinpai` ADD INDEX (  `passed` ) ;

DROP TABLE IF EXISTS `zzcms_jobclass`;
CREATE TABLE `zzcms_jobclass` (
  `classid` int(11) NOT NULL auto_increment,
  `classname` char(50) default NULL COMMENT '类别名',
  `parentid` int(11) default '0' COMMENT '父类ID',
  `classzm` char(50) default NULL COMMENT '类别首字母',
  `img` char(50) default NULL COMMENT '类别图片',
  `skin` char(50) default NULL COMMENT '启用的模板文件名',
  `title` char(255) default NULL COMMENT 'SEO标题',
  `keyword` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  `xuhao` int(11) default '0' COMMENT '序号',
  `isshow` tinyint(4) default '0' COMMENT '是否在前台列表中显示',
  PRIMARY KEY  (`classid`)
) COMMENT='招聘信息类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_job`;
CREATE TABLE `zzcms_job` (
  `id` int(11) NOT NULL auto_increment, 
  `classid` int(11) default '0' COMMENT '大类ID',
  `title` char(50) default NULL COMMENT '招聘职位名称',
  `province` char(50) default NULL COMMENT '所在省份',
  `city` char(50) default NULL COMMENT '城市',
  `xiancheng` char(50) default NULL COMMENT '县',
  `sm` varchar(1000) default NULL COMMENT '说明',
  `editor` char(50) default NULL COMMENT '发布人',
  `comane` char(50) default NULL COMMENT '公司名',
  `userid` int(11) default '0' COMMENT '用户ID',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `hit` int(11) default '0' COMMENT '点击数',
  `passed` tinyint(4) NOT NULL default '0' COMMENT '是否审核',
  PRIMARY KEY  (`id`)
) COMMENT='招聘信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_zhanhui`;
CREATE TABLE `zzcms_zhanhui` (
  `id` int(11) NOT NULL auto_increment,
  `classid` int(11) default NULL COMMENT '大类ID',
  `title` char(50) default NULL COMMENT '标题',
  `province` char(100) default NULL COMMENT '地址',
  `timestart` datetime default NULL COMMENT '展会开始时间',
  `timeend` datetime default NULL COMMENT '展会结束时间',
  `content` longtext COMMENT '详细内容',
  `editor` char(50) default NULL COMMENT '发布人',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `hit` int(11) default '0' COMMENT '点击数',
  `passed` tinyint(4) default '0' COMMENT '是否审核',
  `elite` tinyint(4) default '0' COMMENT '是否推荐',
  PRIMARY KEY  (`id`)
) COMMENT='展会信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_zhanhuiclass`;
CREATE TABLE `zzcms_zhanhuiclass` (
  `classid` int(11) NOT NULL auto_increment,
  `parentid` int(11) default '0' COMMENT '父类ID',
  `classname` char(50) default NULL COMMENT '类别名',
  `classzm` char(50) default NULL COMMENT '类别首字母',
  `img` char(50) default NULL COMMENT '图片',
  `skin` char(50) default NULL COMMENT '启用的模板名',
  `xuhao` int(11) default '0' COMMENT '序号',
  `isshow` tinyint(4) default '1' COMMENT '是否在前台类别列表中显示',
  `title` char(255) default NULL COMMENT 'SEO标题',
  `keyword` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  PRIMARY KEY  (`classid`)
) COMMENT='展会类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_wangkan`;
CREATE TABLE `zzcms_wangkan` (
  `id` int(11) NOT NULL auto_increment,
  `classid` int(11) default NULL COMMENT '大类ID',
  `title` char(50) default NULL COMMENT '标题',
  `content` longtext COMMENT '内容',
  `img` char(255) default NULL COMMENT '图片',
  `editor` char(50) default NULL COMMENT '发布人',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `hit` int(11) default '0' COMMENT '点击数',
  `passed` tinyint(4) default '0' COMMENT '是否审核',
  `elite` tinyint(4) default '0' COMMENT '是否推荐',
  PRIMARY KEY  (`id`)
) COMMENT='网刊信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_wangkanclass`;
CREATE TABLE `zzcms_wangkanclass` (
  `classid` int(11) NOT NULL auto_increment,
  `parentid` int(11) default '0' COMMENT '父类ID',
  `classname` char(50) default NULL COMMENT '类别名',
  `classzm` char(50) default NULL COMMENT '类别首字母',
  `img` char(50) default NULL COMMENT '图片',
  `skin` char(50) default NULL COMMENT '启用的模板名',
  `xuhao` int(11) default '0' COMMENT '序号',
  `isshow` tinyint(4) default '1' COMMENT '是否在前台类别列表中显示',
  `title` char(255) default NULL COMMENT 'SEO标题',
  `keyword` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  PRIMARY KEY  (`classid`)
) COMMENT='网刊类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_zixun`;
CREATE TABLE `zzcms_zixun` (
  `id` int(11) NOT NULL auto_increment,
  `classid` int(11) default NULL COMMENT '大类ID',
  `classname` char(50) default NULL COMMENT '大类名',
  `province` char(50) default NULL COMMENT '省份',
  `city` char(50) default NULL COMMENT '城市',
  `title` char(50) default NULL COMMENT '标题',
  `link` char(255) default NULL COMMENT '外链地睛',
  `laiyuan` char(50) default NULL COMMENT '来源',
  `keywords` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  `content` longtext COMMENT '内容',
  `img` char(255) default NULL COMMENT '图片',
  `editor` char(50) default NULL COMMENT '发布人',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `hit` int(11) default '0' COMMENT '点击数',
  `passed` tinyint(4) default '0' COMMENT '审核',
  `elite` tinyint(4) default '0' COMMENT '推荐',
  `groupid` int(11) default '1' COMMENT '查看者用户组',
  `jifen` int(11) default '0' COMMENT '所需积分',
  PRIMARY KEY  (`id`)
) COMMENT='资讯信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
ALTER TABLE  `zzcms_zixun` ADD INDEX (`classid`) ;

DROP TABLE IF EXISTS `zzcms_zixunclass`;
CREATE TABLE `zzcms_zixunclass` (
  `classid` int(11) NOT NULL auto_increment,
  `parentid` int(11) default '0' COMMENT '父类ID',
  `classname` char(50) default NULL COMMENT '类别名',
  `classzm` char(50) default NULL COMMENT '类别首字母',
  `img` char(50) default NULL COMMENT '图片',
  `skin` char(50) default NULL COMMENT '启用的模板名',
  `xuhao` int(11) default '0' COMMENT '序号',
  `isshow` tinyint(4) default '1' COMMENT '是否在前台类别列表中显示',
  `title` char(255) default NULL COMMENT 'SEO标题',
  `keyword` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  PRIMARY KEY  (`classid`)
) COMMENT='资讯类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_ask`;
CREATE TABLE `zzcms_ask` (
  `id` int(11) NOT NULL auto_increment,
  `classid` int(11) default NULL COMMENT '大类ID',
  `classname` char(50) default NULL COMMENT '大类名',
  `title` char(50) default NULL COMMENT '标题',
  `content` longtext  COMMENT '内容',
  `img` char(255) default NULL COMMENT '图片',
  `jifen` int(11) default '0' COMMENT '悬赏积分',
  `editor` char(50) default NULL COMMENT '发布人',
  `ip` char(20) default NULL COMMENT '发布人IP',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `hit` int(11) default '0' COMMENT '点击数',
  `elite` tinyint(4) default '0' COMMENT '推荐',
  `typeid` int(11) default '0' COMMENT '问题类别',
  `passed` tinyint(4) default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='问信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
ALTER TABLE  `zzcms_ask` ADD INDEX (  `classid` ) ;

DROP TABLE IF EXISTS `zzcms_askclass`;
CREATE TABLE `zzcms_askclass` (
  `classid` int(11) NOT NULL auto_increment,
  `parentid` int(11) default '0' COMMENT '大类ID',
  `classname` char(50) default NULL COMMENT '大类名',
  `classzm` char(50) default NULL COMMENT '大类首字母',
  `img` char(50) default NULL COMMENT '图片',
  `skin` char(50) default NULL COMMENT '启用的模板文件',
  `xuhao` int(11) default '0' COMMENT '序号',
  `isshow` tinyint(4) default '1' COMMENT '是否在前台首页列表中显示',
  `title` char(255) default NULL COMMENT 'SEO标题',
  `keyword` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  PRIMARY KEY  (`classid`)
) COMMENT='问答类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_answer`;
CREATE TABLE `zzcms_answer` (
  `id` int(11) NOT NULL auto_increment,
  `about` int(11) default '0' COMMENT '问题ID',
  `content` longtext  COMMENT '内容',
  `face` char(50) default NULL COMMENT '表情图片',
  `editor` char(50) default NULL COMMENT '发布人',
  `ip` char(20) default NULL COMMENT '发布人IP',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `caina` tinyint(4) default '0' COMMENT '是否被采纳',
  `passed` tinyint(4) default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='答信息表' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_special`;
CREATE TABLE `zzcms_special` (
  `id` int(11) NOT NULL auto_increment,
  `classid` int(11) default NULL COMMENT '大类ID',
  `classname` char(50) default NULL COMMENT '大类名',
  `title` char(50) default NULL COMMENT '标题',
  `link` char(255) default NULL COMMENT '链接地址',
  `laiyuan` char(50) default NULL COMMENT '来源',
  `keywords` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  `content` longtext  COMMENT '内容',
  `img` char(255) default NULL COMMENT '图片',
  `editor` char(50) default NULL COMMENT '发布人',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `hit` int(11) default '0' COMMENT '点击数',
  `passed` tinyint(4) default '0' COMMENT '审核',
  `elite` tinyint(4) default '0' COMMENT '推荐',
  `groupid` int(11) default '1'  COMMENT '用户组ID',
  `jifen` int(11) default '0' COMMENT '积分',
  PRIMARY KEY  (`id`)
) COMMENT='专题信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
ALTER TABLE  `zzcms_special` ADD INDEX (  `classid` ) ;

DROP TABLE IF EXISTS `zzcms_specialclass`;
CREATE TABLE `zzcms_specialclass` (
  `classid` int(11) NOT NULL auto_increment,
  `classname` char(50) default NULL COMMENT '类别名',
  `classzm` char(50) default NULL COMMENT '类别首字母',
  `img` char(50) default NULL COMMENT '图片',
  `skin` char(50) default NULL COMMENT '启用的模板文件',
  `parentid` int(11) default '0' COMMENT '父类ID',
  `xuhao` int(11) default '0' COMMENT '序号',
  `isshow` tinyint(4) default '1'  COMMENT '是否在前台类别列表中显示',
  `title` char(255) default NULL COMMENT 'SEO标题',
  `keyword` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  PRIMARY KEY  (`classid`)
) COMMENT='专题类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
replace into `zzcms_specialclass` values('1','2015广西药交会','','','','0','0','1','','','');
replace into `zzcms_specialclass` values('2','访谈','','','','1','1','1','','','');
replace into `zzcms_specialclass` values('3','名企直击','','','','1','1','1','','','');
replace into `zzcms_specialclass` values('4','展会现场','','','','1','1','1','','','');
replace into `zzcms_specialclass` values('5','展会简介','','','','1','1','1','','','');
replace into `zzcms_specialclass` values('6','大背景图','','','','1','1','1','','','');

DROP TABLE IF EXISTS `zzcms_help`;
CREATE TABLE `zzcms_help` (
  `id` int(11) NOT NULL auto_increment,
  `classid` int(11) default NULL COMMENT '类别ID',
  `title` char(50) default NULL COMMENT '标题',
  `content` longtext COMMENT '内容',
  `img` char(255) default NULL COMMENT '图片',
  `elite` tinyint(4) default '0' COMMENT '推荐',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `passed` tinyint(4) default '1' COMMENT '是否审核',
  PRIMARY KEY  (`id`)
) COMMENT='帮助信息' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_licence`;
CREATE TABLE `zzcms_licence` (
  `id` int(11) NOT NULL auto_increment,
  `title` char(50) default NULL COMMENT '标题',
  `img` char(255) default NULL COMMENT '图片',
  `editor` char(50) default NULL COMMENT '发布人',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `passed` tinyint(4) NOT NULL default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='用户资质信息表' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_link`;
CREATE TABLE `zzcms_link` (
  `id` int(11) NOT NULL auto_increment,
  `classid` int(11) default '0' COMMENT '大类ID',
  `sitename` char(50) default NULL COMMENT '网站名',
  `url` char(255) default NULL COMMENT '网址',
  `content` char(255) default NULL COMMENT '内容',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `logo` char(255) default NULL COMMENT '网站LOGO',
  `elite` tinyint(4) default '0' COMMENT '推荐',
  `passed` tinyint(4) default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='网站友情链接表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_linkclass`;
CREATE TABLE `zzcms_linkclass` (
  `classid` int(11) NOT NULL auto_increment,
  `parentid` int(11) default '0' COMMENT '父类ID',
  `classname` char(50) default NULL COMMENT '类别名',
  `classzm` char(50) default NULL COMMENT '类别首字母',
  `img` char(50) default NULL COMMENT '图片',
  `skin` char(50) default NULL COMMENT '启用的模板名',
  `xuhao` int(11) default '0' COMMENT '序号',
  `isshow` tinyint(4) default '1' COMMENT '是否在前台类别列表中显示',
  `title` char(255) default NULL COMMENT 'SEO标题',
  `keyword` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  PRIMARY KEY  (`classid`)
) COMMENT='友情链接类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_guestbook`;
CREATE TABLE `zzcms_guestbook` (
  `id` int(11) NOT NULL auto_increment,
  `title` char(50) default NULL COMMENT '标题',
  `content` longtext COMMENT '内容',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `truename` char(50) default NULL COMMENT '联系人',
  `tel` char(50) default NULL COMMENT '电话',
  `email` char(100) default NULL COMMENT 'EMAIL',
  `saver` char(50) default NULL COMMENT '接收人',
  `looked` tinyint(4) default '0' COMMENT '是否查看',
  `passed` tinyint(4) default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='网站留言本信息' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_message`;
CREATE TABLE `zzcms_message` (
  `id` int(11) NOT NULL auto_increment,
  `title` char(50) default NULL COMMENT '标题',
  `content` char(255) default NULL COMMENT '内容',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `sendto` char(50) NOT NULL COMMENT '发送给谁（这里填的是用户名）',
  `looked` tinyint(4) NOT NULL default '0' COMMENT '是否查看',
  PRIMARY KEY  (`id`)
) COMMENT='用户发送的网站内部短信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_ad`;
CREATE TABLE `zzcms_ad` (
  `id` int(11) NOT NULL auto_increment,
  `xuhao` int(11) NOT NULL default '0' COMMENT '序号',
  `title` char(50) default NULL COMMENT '标题',
  `titlecolor` char(255) default NULL COMMENT '标题颜色',
  `link` char(255) default NULL COMMENT '链接地址',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `bigclassname` char(50) default NULL COMMENT '所属大类',
  `smallclassname` char(50) default NULL COMMENT '所属小类',
  `province` char(50) default NULL COMMENT '省份',
  `city` char(50) default NULL COMMENT '城市',
  `username` char(50) default NULL COMMENT '用户名',
  `nextuser` char(50) default NULL COMMENT '后备用户名',
  `elite` tinyint(4) NOT NULL default '0' COMMENT '推荐',
  `img` char(255) default NULL COMMENT '图片',
  `starttime` datetime default NULL COMMENT '投放开始时间',
  `endtime` datetime default NULL COMMENT '投放结束时间',
  PRIMARY KEY  (`id`)
) COMMENT='网站广告信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_adclass`;
CREATE TABLE `zzcms_adclass` (
  `classid` int(11) NOT NULL auto_increment,
  `classname` char(50) NOT NULL COMMENT '类别名',
  `parentid` char(50) NOT NULL COMMENT '父类',
  `xuhao` int(11) NOT NULL default '0' COMMENT '序号',
  `classzm` char(50) default NULL COMMENT '类别名字母',
  PRIMARY KEY  (`classid`)
) COMMENT='网站广告类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
replace into `zzcms_adclass` values('1','对联广告右侧','首页','0','');
replace into `zzcms_adclass` values('2','对联广告左侧','首页','0','');
replace into `zzcms_adclass` values('3','漂浮广告','首页','0','');
replace into `zzcms_adclass` values('4','首页顶部','首页','0','');
replace into `zzcms_adclass` values('5','品牌招商','首页','0','');
replace into `zzcms_adclass` values('6','banner','首页','0','');
replace into `zzcms_adclass` values('7','轮显广告','展会页','0','');
replace into `zzcms_adclass` values('8','第二行','首页','0','');
replace into `zzcms_adclass` values('9','轮显广告','首页','0','');
replace into `zzcms_adclass` values('10','第一行','首页','0','');
replace into `zzcms_adclass` values('11','B','首页','0','');
replace into `zzcms_adclass` values('12','A','首页','0','');
replace into `zzcms_adclass` values('13','首页','A','0','');

DROP TABLE IF EXISTS `zzcms_textadv`;
CREATE TABLE `zzcms_textadv` (
  `id` int(11) NOT NULL auto_increment,
  `adv` char(50) default NULL COMMENT '标题',
  `company` char(50) NOT NULL COMMENT '公司名',
  `advlink` char(50) default NULL COMMENT '链接地址',
  `img` char(255) default NULL COMMENT '图片',
  `username` char(50) default NULL COMMENT '用户名',
  `gxsj` datetime default NULL COMMENT '广告内容更新时间',
  `newsid` int(11) NOT NULL default '0' COMMENT '所占的广告位ID',
  `passed` tinyint(4) NOT NULL default '0' COMMENT '审核',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `adv` (`adv`)
) COMMENT='用户审请的广告表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_pay`;
CREATE TABLE `zzcms_pay` (
  `id` int(11) NOT NULL auto_increment,
  `username` char(50) default NULL COMMENT '用户名',
  `dowhat` char(50) default NULL COMMENT '交易详情',
  `RMB` char(50) default '0' COMMENT '人民币',
  `mark` char(255) default NULL COMMENT '交易记录',
  `sendtime` datetime NOT NULL COMMENT '交易时间',
  PRIMARY KEY  (`id`)
) COMMENT='用户冲值消费记录表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_pinglun`;
CREATE TABLE `zzcms_pinglun` (
  `id` int(11) NOT NULL auto_increment,
  `about` int(11) default '0' COMMENT '被评资讯ID',
  `content` char(255) default NULL COMMENT '内容',
  `face` char(50) default NULL COMMENT '表情图片',
  `username` char(50) default NULL COMMENT '用户名',
  `ip` char(50) default NULL COMMENT 'IP',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `passed` tinyint(4) default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='资讯信息评论表' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_tagzx`;
CREATE TABLE `zzcms_tagzx` (
  `id` int(11) NOT NULL auto_increment,
  `xuhao` int(11) default '0' COMMENT '序号',
  `keyword` char(50) default NULL COMMENT '关键字',
  `url` char(50) default NULL COMMENT '链接地址',
  PRIMARY KEY  (`id`)
) COMMENT='资讯标签表' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_tagzs`;
CREATE TABLE `zzcms_tagzs` (
  `id` int(11) NOT NULL auto_increment,
  `xuhao` int(11) NOT NULL default '0' COMMENT '序号',
  `keyword` char(50) default NULL COMMENT '关键字',
  `url` char(50) default NULL COMMENT '链接地址',
  PRIMARY KEY  (`id`)
) COMMENT='招商标签表' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_user`;
CREATE TABLE `zzcms_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` char(50) NOT NULL COMMENT '用户名',
  `password` char(50) NOT NULL COMMENT '加密的密码串',
  `passwordtrue` char(50) default NULL COMMENT '密码',
  `qqid` char(50) default NULL COMMENT 'QQid',
  `email` char(100) default NULL COMMENT 'EMAIL',
  `sex` char(50) default NULL COMMENT '性别',
  `comane` char(50) default NULL COMMENT '公司名',
  `content` longtext COMMENT '内容',
  `classid` int(11) default '0' COMMENT '大类别ID',
  `province` char(50) default NULL COMMENT '所在省份',
  `city` char(50) default NULL COMMENT '城市',
  `xiancheng` char(50) default NULL COMMENT '县',
  `img` char(255) default NULL COMMENT '图片地址',
  `flv` char(255) default NULL COMMENT 'FLV视频地址',
  `address` char(100) default NULL COMMENT '地址',
  `somane` char(50) default NULL COMMENT '姓名',
  `phone` char(50) default NULL COMMENT '电话',
  `mobile` char(50) default NULL COMMENT '手机',
  `fox` char(50) default NULL COMMENT '传真',
  `qq` char(50) default NULL COMMENT 'QQ',
  `regdate` datetime default NULL COMMENT '注册时间',
  `loginip` char(50) default NULL COMMENT '登录IP',
  `logins` int(11) NOT NULL default '0' COMMENT '登录次数',
  `homepage` char(50) default NULL COMMENT '公司主页',
  `lastlogintime` datetime default NULL COMMENT '记录的最后登录时间',
  `lockuser` tinyint(4) NOT NULL default '0' COMMENT '是否被锁定',
  `groupid` int(11) NOT NULL default '1' COMMENT '用户组ID',
  `totleRMB` int(11) NOT NULL default '0' COMMENT '冲值人民币',
  `startdate` datetime default NULL COMMENT '开始时间',
  `enddate` datetime default NULL COMMENT '结束时间',
  `showloginip` char(50) default NULL COMMENT '最后登录IP',
  `showlogintime` datetime default NULL COMMENT '最后登录时间',
  `elite` tinyint(4) NOT NULL default '0' COMMENT '推荐',
  `renzheng` tinyint(4) NOT NULL default '0' COMMENT '认证',
  `usersf` char(20) default NULL COMMENT '用户身份',
  `passed` tinyint(4) NOT NULL default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='网站注册用户表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_usergroup`;
CREATE TABLE `zzcms_usergroup` (
  `id` int(11) NOT NULL auto_increment,
  `groupid` int(11) NOT NULL default '1' COMMENT '用户组ID',
  `groupname` char(50) NOT NULL COMMENT '用户组',
  `grouppic` char(50) NOT NULL  COMMENT '图片',
  `RMB` int(11) NOT NULL default '0' COMMENT '人民币',
  `config` varchar(1000) NOT NULL default '0' COMMENT '权限参数',
  `looked_dls_number_oneday` int(11) NOT NULL default '0' COMMENT '每天可查看的代理商信息数',
  `refresh_number` int(11) NOT NULL default '0' COMMENT '每天刷新数',
  `addinfo_number` int(11) NOT NULL default '0' COMMENT '每天发布信息数',
  `addinfototle_number` int(11) NOT NULL default '0' COMMENT '发布信息总数',
  PRIMARY KEY  (`id`)
) COMMENT='用户权限组表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
replace into `zzcms_usergroup` values('1','1','普通会员','/image/level1.gif','0','dls_print#dls_download#set_text_adv#set_elite#set_zt#passed#seo#showad_inzt#zsshow_template','10','1','50','100');
replace into `zzcms_usergroup` values('2','2','vip会员','/image/level2.gif','1999','look_dls_data#look_dls_liuyan#passed#seo','100','3','100','500');
replace into `zzcms_usergroup` values('3','3','高级会员','/image/level3.gif','2999','look_dls_data#look_dls_liuyan#passed#seo','999','999','999','999');

DROP TABLE IF EXISTS `zzcms_userclass`;
CREATE TABLE `zzcms_userclass` (
  `classid` int(11) NOT NULL auto_increment,
  `parentid` int(11) default '0' COMMENT '父类ID',
  `classname` char(50) NOT NULL  COMMENT '类别名',
  `classzm` char(50) default NULL COMMENT '类别首字母',
  `img` char(50) default NULL COMMENT '图片',
  `skin` char(50) default NULL COMMENT '启用模板文件',
  `title` char(255) default NULL COMMENT 'SEO标题',
  `keyword` char(255) default NULL COMMENT 'SEO关键字',
  `description` char(255) default NULL COMMENT 'SEO描述',
  `isshow` tinyint(4) default '0' COMMENT '是否在前台显示',
  `xuhao` int(11) NOT NULL default '0' COMMENT '序号',
  PRIMARY KEY  (`classid`)
) COMMENT='注册用户类别表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
replace into `zzcms_userclass` values('1','0','生产单位','','','','','','','1','0');
replace into `zzcms_userclass` values('2','0','经销单位','','','','','','','1','0');
replace into `zzcms_userclass` values('4','0','展会承办单位','','','','','','','1','0');
replace into `zzcms_userclass` values('5','0','其它相关行业','','','','','','','1','0');

DROP TABLE IF EXISTS `zzcms_usermessage`;
CREATE TABLE `zzcms_usermessage` (
  `id` int(11) NOT NULL auto_increment,
  `title` char(50) default NULL COMMENT '标题',
  `content` varchar(255) default NULL COMMENT '内容',
  `sendtime` datetime default NULL COMMENT '发布时间',
  `editor` char(50) default NULL COMMENT '发布人',
  `reply` varchar(255) default NULL COMMENT '回复内容',
  `replytime` datetime default NULL COMMENT '回复时间',
  PRIMARY KEY  (`id`)
) COMMENT='用户向网站管理员发送的信息表' ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_usernoreg`;
CREATE TABLE `zzcms_usernoreg` (
  `id` int(11) NOT NULL auto_increment,
  `usersf` char(50) default NULL COMMENT '注册用户身份',
  `username` char(50) NOT NULL  COMMENT '用户名',
  `password` char(50) default NULL COMMENT '密码',
  `comane` char(50) default NULL COMMENT '公司名',
  `kind` int(11) NOT NULL default '0' COMMENT '类别',
  `somane` char(50) default NULL COMMENT '姓名',
  `phone` char(50) default NULL COMMENT '电话',
  `email` char(100) default NULL COMMENT 'E-MAIL',
  `checkcode` char(50) default NULL COMMENT '验证码',
  `regdate` datetime NOT NULL  COMMENT '注册时间',
  PRIMARY KEY  (`id`)
) COMMENT='未通过验证的注册用户表，大多是群发机注册的垃圾信息' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_usersetting`;
CREATE TABLE `zzcms_usersetting` (
  `id` int(11) NOT NULL auto_increment,
  `username` char(50) default NULL COMMENT '用户名',
  `skin` char(50) default '1'  COMMENT '展厅模板',
  `skin_mobile` char(50) default 'mobile1'  COMMENT '移动端展厅模板',
  `tongji` char(255) default NULL COMMENT '第三方统计代码',
  `baidu_map` char(50) default NULL COMMENT '百度地图',
  `mobile` char(50) default NULL COMMENT '手机',
  `daohang` char(50) default NULL COMMENT '导航条',
  `bannerbg` char(50) default NULL COMMENT 'banner背景',
  `bannerheight` int(11) NOT NULL default '160' COMMENT 'banner高度',
  `comanestyle` char(50) default NULL COMMENT '公司名样式',
  `comanecolor` char(50) default NULL COMMENT '公司名颜色',
  PRIMARY KEY  (`id`)
) COMMENT='用户配置信息表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_msg`;
CREATE TABLE `zzcms_msg` (
  `id` int(11) NOT NULL auto_increment,
  `content` varchar(1000) NOT NULL COMMENT '内容',
  `elite` tinyint(4) default '0' COMMENT '默认模板',
  `username` char(50) default NULL COMMENT '用户名',
  `passed` tinyint(4) default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='在线发短信模板表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_userdomain`;
CREATE TABLE `zzcms_userdomain` (
  `id` int(11) NOT NULL auto_increment,
  `username` char(50) default NULL COMMENT '用户名',
  `domain` char(50) default NULL COMMENT '域名',
  `passed` tinyint(4) default '0' COMMENT '审核',
  `del` tinyint(4) default '0' COMMENT '是否删除',
  PRIMARY KEY  (`id`)
) COMMENT='用户审请绑定的域名' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_ztad`;
CREATE TABLE `zzcms_ztad` (
  `id` int(11) NOT NULL auto_increment,
  `classname` char(50) default NULL COMMENT '类别名',
  `title` char(50) default NULL COMMENT '标题',
  `link` char(255) default NULL COMMENT '链接地址',
  `img` char(255) default NULL COMMENT '图片',
  `editor` char(50) default NULL COMMENT '发布人',
  `passed` tinyint(4) default '0' COMMENT '审核',
  PRIMARY KEY  (`id`)
) COMMENT='用户展厅广告表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `zzcms_adminlog`;
CREATE TABLE `zzcms_adminlog` (
  `id` int(11) NOT NULL auto_increment,
  `admin` char(20) default NULL COMMENT '管理员',
  `ip` char(50) default NULL COMMENT 'IP',
  `url` char(100) default NULL COMMENT '操作页面地址',
  `sendtime` datetime default NULL COMMENT '时间',
  PRIMARY KEY  (`id`)
) COMMENT='管理员操作日志表' ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8