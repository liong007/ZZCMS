<?php
$lang=array();
$lang=Array(
	'fail'=>'失败！',
	'nomsg'=>'暂无信息'
	
);
?>