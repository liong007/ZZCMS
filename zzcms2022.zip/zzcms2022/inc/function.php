<?php
define('zzcmsroot2', str_replace("\\", '/', substr(dirname(__FILE__), 0, -3)));//-3截除当前目录inc
function tsmsg($msg,$url=''){
	$str="<!DOCTYPE html><html>";//有些文件不能设文件头
	$str.="<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
	if ($url<>''){
	$str.="<meta http-equiv=\"refresh\" content=\"3;url=$url\">" ;
	}
	$str.="<body>";
	$str.= "<div style='text-align:center;font-size:14px;line-height:25px;padding:10px'>" ;
	$str.= "<div style='border:solid 1px #dddddd;margin:0 auto;background-color:#FFFFFF;width:600px'>";
	$str.= "<div style='background-color:#f1f1f1;border-bottom:solid 1px #ddd;font-weight:bold;height:40px;line-height:40px'>提示</div>";
	$str.= "<div style='padding:20px;font-size:1.2em'>" .$msg."</div>";
	$str.= "<div style='text-align:center'><iframe frameborder='0' scrolling='no'  src='/js/daojishi.html' style='height:20px;width:200px;margin:0 auto;'></iframe></div>";
	$str.="<div style='height:40px;line-height:40px'><a href='javascript:history.go(-1)' style='padding:0 10px'>返回上页</a><a href='###' onClick='window.opener=null;window.close()' style='padding:0 10px'>关闭窗口</a></div>";
	$str.= "</div>"; 
	$str.="</div>" ;
	$str.= "</body>" ;
	$str.= "</html>" ;
	echo $str;
}
//显示信息
function showmsg($msg,$zc_url = 'back',$exit='exit'){
	$str="<!DOCTYPE html>";//有些文件不能设文件头
	$str.="<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>";
	if($zc_url && $zc_url!='back' && $zc_url!='null'){
	$str.=("<script>alert('$msg');parent.location=\"$zc_url\";</script>");
	}elseif( $zc_url=='null'){
	$str.=("<script>alert(\"$msg\")</script>");
	}else{
	$str.=("<script>alert(\"$msg\");history.back();</script>");
	}
	echo $str;
	if ($exit=='exit'){
	exit;
	}
}

//$_SERVER['HTTP_REFERER'];//上页来源
function markit(){
		  $userip=$_SERVER["REMOTE_ADDR"]; 
		  //$userip=getip(); 
          $url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		  query("insert into zzcms_bad (username,ip,dose,sendtime)values('".$_COOKIE["UserName"]."','$userip','$url','".date('Y-m-d H:i:s')."')") ;     
}

function admindo(){
global $admin;
$ip=getip();
$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
query("insert into zzcms_adminlog (admin,ip,url,sendtime)values('$admin','$ip','$url','".date('Y-m-d H:i:s')."')") ;  
}

function getpageurl($channel,$id){
	if (whtml=="Yes") {return "/". $channel . "/show_" . $id . ".html" ;}else {return "/" . $channel . "/show.php?id=" . $id;}
}
function getpageurl_zt($channel,$id){
	if (whtml=="Yes") {return "/". $channel . "/" . $id . ".html" ;}else {return "/" . $channel . "/show.php?id=" . $id;}
}
function getpageurlzt($editor,$id){
	if(sdomain=="Yes" ){return "http://".$editor.".".substr(siteurl,strpos(siteurl,".")+1);}else{return siteurl.getpageurl_zt("zhanting",$id);}
}

function getpageurl2($channel,$c){
if (whtml=="Yes"){
	$str="/" . $channel."/" . $c ;
	//$str=$str.".html";
}else{
	$str="/" .$channel."/list.php?c=".$c ;
	//$str="?c=".$c ;
}
return $str;
}

function getpageurl3($pagename){
	if (whtml=="Yes"){return $pagename . ".html" ;}else {return $pagename . ".php";}
}

function getpageurl_class($channel,$c){
if (whtml=="Yes"){
	$str="/" . $channel;
	if ($channel=='zixun'|| $channel=='ask' || $channel=='special'){$str=$str."/class";}
	if ($c<>"") {$str=$str."/" . $c ."";}
	//$str=$str.".html";
}else{
	$str="/" .$channel."/class.php";
	if ($c<>""){$str=$str."?c=" . $c ."";}
}
return $str;
}

function getchannelname($channel){
switch ($channel){
case "zhaoshang";return channelzs;break;
case "zhaoshangclass";return channelzs;break;
case "pinpai";return "品牌";break;
case "job";return "招聘";break;
case "daili";return channeldl;break;
case "zhanhui";return "展会";break;
case "zixun";return "资讯";break;
case "wangkan";return "网刊";break;
case "baojia";return '报价';break;
case "ask";return '问答';break;
case "special";return "专题";break;
case "company";return "企业";break;
case "user";return "用户";break;
}
}

function showannounce($cs){
$cs=explode(",",$cs); //传入的$cs是一个整体字符串,转成数组
$numbers=isset($cs[0])?$cs[0]:2;checkid($numbers,0,'{#showannounce}标签的第1个参数须为大于0的整数');
$titlelong=isset($cs[1])?$cs[1]:20;checkid($titlelong,0,'{#showannounce}标签的第2个参数须为大于0的整数');
if (isset($_COOKIE['closegg'])){
$str='';
}else{
	$n=1;$str='';
	$sql="select title,id,content,sendtime from zzcms_help where classid=2 and elite=1 order by id desc limit 0,$numbers";
	$rs=query($sql);
	//echo $sql;
	$row=mysqli_num_rows($rs);
	if ($row){
	$str=$str ."<div id='gonggao'><span onclick=\"gonggao.style.display='none'\"><a href=javascript:delCookie('closegg')>×</a></span>";
		while ($row=mysqli_fetch_array($rs)){
		$str=$str ."<li>公告【". $n ."】<a href=javascript:openwindow('/one/announce_show.php?id=".$row["id"]."',700,300)>".cutstr(strip_tags($row["title"]),$titlelong)." [".date("Y-m-d",strtotime($row['sendtime']))."] </a></li>";
		$n++;
		}
	$str=$str ."</div>";
	}
	}
return $str;
}

function getsmallimg($img){
if (substr($img,0,4) == "http"){
return $img;//复制的网上的图片，不生成小图片，直接显示大图
}elseif(strpos($img,'_small') !== false){
return $img;//已是小图的不再重加后缀_small
}else{
return siteurl.str_replace(".jpeg","_small.jpeg",str_replace(".png","_small.png",str_replace(".gif","_small.gif",str_replace(".jpg","_small.jpg",$img))));
}
}

function makesmallimg($img){
$img=substr($img,0);
$imgbig=zzcmsroot2.$img;
if(!file_exists($imgbig)){
echo "<script>alert('封面图片不存在，没有生成缩略图')</script>";
}else{
	$imgsmall=str_replace(siteurl,"",getsmallimg($imgbig));
	$sImgName =$imgsmall;
	$sImgSize=120;
	$data=GetImageSize($imgbig);//取得GIF、JPEG、PNG或SWF图片属性，返回数组，图形的宽度[0],图形的高度[1]，文件类型[2]
	if($data[2]!=4){//文件类型不为4，4为swf格式
    	switch ($data[2]) {
     	case 1 :$sImg = imagecreatefromgif($imgbig);break;
     	case 2 :$sImg = imagecreatefromjpeg($imgbig);break;
     	case 3 :$sImg = imagecreatefrompng($imgbig);break;
     	case 6 :$sImg = imagecreatefromwbmp($imgbig);break;
     	//default :echo "不支持的文件类型，无法生成缩略图";
    	}
		//生成小图
		if ($data[1]!=0 && $data[0]!=0){
		if ($data[1]>$data[0]){
		$newwidth=$sImgSize*($data[0]/$data[1]) ;
		$newheight= $sImgSize;
		}else{
		$newwidth=$sImgSize;
		$newheight=$sImgSize*($data[1]/$data[0]) ;
		}  
		$sImgDate = imagecreatetruecolor($newwidth,$newheight);   
		imagecopyresampled($sImgDate,$sImg, 0, 0, 0, 0, $newwidth, $newheight, $data[0],$data[1]);
    	switch ($data[2]) {
     	case 1 :imagegif($sImgDate, $sImgName);break;
     	case 2 :imagejpeg($sImgDate, $sImgName);break;
     	case 3 :imagepng($sImgDate, $sImgName);break;
     	case 6 :imagewbmp($sImgDate, $sImgName);break;
    	}
    	imagedestroy($sImgDate);
       	$isok=imagedestroy($sImg);
		//if ($isok){echo "生成小图片成功:".$sImgName;}	
		}
   	}
}
}

function grabimg($url,$filename="") {
   if($url==""):return false;endif;
   if($filename=="") {
     $ext=strrchr($url,".");
     if($ext!=".gif" && $ext!=".jpg" && $ext!=".png"&& $ext!=".bmp"):return false;endif;
	 $filename_dir=zzcmsroot2.'uploadfiles/'.date("Y-m"); //上传文件地址 采用绝对地址方便upload.php文件放在站内的任何位置 
	 if (!file_exists($filename_dir)) {
	 @mkdir($filename_dir,0777,true);
	 }
	 $filename=$filename_dir."/".date("YmdHis").rand(100,999).$ext;
   }
   ob_start();
   readfile($url);
   $img = ob_get_contents();
   ob_end_clean();
   $size = strlen($img);

   $fp2=@fopen($filename, "a");
   fwrite($fp2,$img);
   fclose($fp2);
   return $filename;
}

function showkeyword($cs){
global $keyword,$siteskin;
$cs=explode(",",$cs); //传入的$cs是一个整体字符串,转成数组
$channel=isset($cs[0])?$cs[0]:'zhaoshang';
$numbers=isset($cs[1])?$cs[1]:10;checkid($numbers);
$column=isset($cs[2])?$cs[2]:5;checkid($column);
	
if ($channel=='zhaoshang' || $channel=='daili'){
$fpath=zzcmsroot2."cache/zskeyword.txt";
}elseif ($channel=='zixun'){
$fpath=zzcmsroot2."cache/zxkeyword.txt";
}

if (cache_update_time!=0 && file_exists($fpath)!==false && time()-filemtime($fpath)<3600*24*cache_update_time){
	return file_get_contents($fpath);
}else{
	if ($channel=='zhaoshang'||$channel=='daili'){
	$sql= "select keyword,url from zzcms_tagzs order by xuhao asc limit 0,$numbers";
	}elseif($channel=='zixun'){
	$sql= "select keyword,url from zzcms_tagzx order by xuhao asc limit 0,$numbers";
	}else{
	$sql= "select keyword,url from zzcms_tagzx order by xuhao asc limit 0,$numbers";
	}
	$rs=query($sql);
	$row=mysqli_num_rows($rs);
	//echo $sql;
	if ($row){
	$str="";
	$liwidth=100/$column-3;
		while ($row=mysqli_fetch_array($rs)){
		if ($row["keyword"]==$keyword) {
		$str=$str . "<li style='font-weight:bold;min-width:".$liwidth."%;display:inline-block'>";
		}else{
		$str=$str . "<li style='min-width:".$liwidth."%;display:inline-block'>";
		}
		$str=$str . "<a href='/".$channel."/search.php?keyword=".$row["keyword"]."'>".$row["keyword"]."</a></li>\r\n";			
		}
	}else{
	$str= "暂无信息";
	}

	return $str;
		
	if ($channel=='zhaoshang'||$channel=='daili'){
	$fpath=zzcmsroot2."cache/zskeyword.txt";
	}elseif ($channel=='zixun'){
	$fpath=zzcmsroot2."cache/zxkeyword.txt";
	}
	if (!file_exists("../cache")) {mkdir("../cache",0777,true);}
	$fp=fopen($fpath,"w+");//fopen()的其它开关请参看相关函数
	fputs($fp,$str);//写入文件
	fclose($fp);
}	
}

function showad($cs){
global $siteskin;
$cs=explode(",",$cs); //传入的$cs是一个整体字符串,转成数组
$b=isset($cs[0])?$cs[0]:'';
$s=isset($cs[1])?$cs[1]:'';
$num=isset($cs[2])?$cs[2]:'';
$titlelong=isset($cs[3])?$cs[3]:0;
$bianhao=isset($cs[4])?$cs[4]:'';
$province=isset($cs[5])?$cs[5]:'';//只有area/show页在用，这里传入的参数是汉字，不管传入的参数为拼音或汉字，这里统一转为汉字
$province_hz=province_zm2hz($province);
$city=isset($cs[6])?$cs[6]:'';
$fp=zzcmsroot2."cache/".$siteskin."/adv_".pinyin($b)."_".pinyin($s)."_".$province.".htm";//广告中文类别名转换成拼音字母来给缓存文件命名
if (cache_update_time!=0 && file_exists($fp) && filesize($fp)>10 && time()-filemtime($fp)<3600*24*cache_update_time ) {
//按管理员设定的时间更新,//utf-8有文件头，空文件大小为3字节
	$fso = fopen($fp,'r');
	$fcontent = fread($fso,filesize($fp));
	fclose($fso);
	return $fcontent;
}else{
$n=1;$str='';
//sql= "select * from zzcms_ad where endtime>= '"&date()&"' "
if ($city<>''){
$sql= "select * from zzcms_ad where bigclassname='".$b."' and smallclassname='".$s."' and city='".$city."' order by xuhao asc,id asc ";//只用一个参数，直接显示城市广告
}elseif ($province<>''){
$sql= "select * from zzcms_ad where bigclassname='".$b."' and smallclassname='".$s."' and province='".$province_hz."' order by xuhao asc,id asc ";
}else{
$sql= "select * from zzcms_ad where bigclassname='".$b."' and smallclassname='".$s."' order by xuhao asc,id asc ";
}

if ($num<>0){$sql= $sql. " limit 0,$num";}
$rs=query($sql);
//echo $sql."<br>";
$row=mysqli_num_rows($rs);
if ($row){ 
$str="<div><ul>";
while ($row=mysqli_fetch_array($rs)){
$str=$str."<li> ";
if (isshowad_when_timeend=="No" && $row["endtime"]<=date('Y-m-d H:i:s')){ //到期的
$str=$str. showadtext;
}else{		
$str=$str. "<a href='".addhttp($row["link"])."' target='_blank' style='color:".$row["titlecolor"]."'>";
	if ($row["img"]<>"" ) {//有图片的
	$str=$str. "<div class='ad'>";
	$str=$str. "<img data-original='".isaddsiteurl($row["img"])."'  alt='".$row["title"]."' />";
	$str=$str. "<span>广告</span>";//span放图片后面，避免各种情况的遮挡
	$str=$str. "</div>";
	//$str=$str. "<img src='".isaddsiteurl($row["img"])."'  alt='".$row["title"]."' />";
		if ($titlelong!=0){
		$str=$str."<div style='position:relative;'><div style='position:absolute;width:100%;height:100%;display:block'>";
			if ($bianhao=='yes'){$str=$str.addzero($n,2)."-";}
		$str=$str.cutstr($row["title"],$titlelong);
		$str=$str."</div>";//只能关闭一个DIV
		}
		
	}else{//无图的
		if ($bianhao=='yes'){$str=$str.addzero($n,2)."-";}
		if ($titlelong!=0){$str=$str.cutstr($row["title"],$titlelong);}else{$str=$str.$row["title"];}
	}		
$str=$str."</a>";
}
$str=$str."</li>\n";
$n=$n+1;
}
$str=$str."</ul></div>";
}
	if (cache_update_time!=0){
	$fp=zzcmsroot2."cache/".$siteskin."/adv_".pinyin($b)."_".pinyin($s)."_".$province.".htm";
	if (!file_exists(zzcmsroot2."cache/".$siteskin)) {mkdir(zzcmsroot2."cache/".$siteskin,0777,true);}
	$f=fopen($fp,"w+");//fopen()的其它开关请参看相关函数
	fputs($f,$str);
	fclose($f);
	}
return $str;
}
}

function myip2long($ip){ //在PHP 4.x，PHP 5.x中 ip2long 有前导零的ip转换的结果都不正确。这里自义定了此函数
   $ip_arr = explode('.',$ip); 
   $iplong = (16777216 * intval($ip_arr[0])) + (65536 * intval($ip_arr[1])) + (256 * intval($ip_arr[2])) + intval($ip_arr[3]); 
   return $iplong; 
}

function stopip(){
if (stopip<>''){
$isok=false;
$stopip=myip2long(getip()); 
$ip=explode(PHP_EOL,trim(stopip));//循环出内容项内的项目//去除首尾的换行符
	for ($i=0,$size=count($ip);$i<$size;$i++){
	$ips=explode("|",$ip[$i]); //$ips[0]为起始IP $ips[1]为结束IP
	if ($stopip==myip2long($ip[$i]) || ($stopip>=myip2long($ips[0]) && $stopip<=myip2long($ips[1]))){$isok=true;break;}
	}
if ($isok==true){tsmsg("此IP被拒绝访问");exit();}
} 
}

function passed($table,$classid=0){
global $username;
	if(check_user_power('passed')=='yes'){
	query("update `$table` set passed=1 where editor='".$username."'");
	}
}

function show2url($editor){
if (strpos(siteurl,"www.")!==false){
return "http://".$editor.".".substr(siteurl,strpos(siteurl,".")+1);
}else{
	$n=count(explode(".",siteurl));
	if ($n==2){//http://zzcms.net的情况
	return "http://".$editor.".".str_replace("http://",'',siteurl);
	}
	if ($n==3){//分两种情况：1 http://demo.zzcms.net的情况2 http://zzcms.net.cn
		if (strpos(siteurl,".com.cn")!==false or strpos(siteurl,".net.cn")!==false or strpos(siteurl,".org.cn")!==false){
		return "http://".$editor.".".str_replace("http://",'',siteurl);
		}else{
		return "http://".$editor.".".substr(siteurl,strpos(siteurl,".")+1);
		}
	}
}
}

function sitecount($channel){
$table='zzcms_'.$channel;
$sql="select count(*) as total from `".$table."`";
$rs=query($sql);
$row = mysqli_fetch_array($rs);
$totlenum = $row['total'];
$totlenum=$totlenum + info_num;
return "<li>".getchannelname($channel)."<span>".formatnumber($totlenum)."</span></li>";
}

function showsitecount($cs){ 
global $siteskin;
$fpath=zzcmsroot2."cache/".$siteskin."/sitecount.txt";
if (cache_update_time!=0 && file_exists($fpath)!==false && time()-filemtime($fpath)<3600*24*cache_update_time){
	return file_get_contents($fpath);
}else{	
$str='';
if (strpos($cs,'users')!==false){$str=$str.sitecount('user');}
if (strpos($cs,'zhaoshang')!==false){$str=$str.sitecount('zhaoshang');}
if (strpos($cs,'daili')!==false){$str=$str.sitecount('daili');}
if (strpos($cs,'pinpai')!==false){$str=$str.sitecount('pinpai');}
if (strpos($cs,'zhanhui')!==false){$str=$str.sitecount('zhanhui');}
if (strpos($cs,'job')!==false){$str=$str.sitecount('job');}
if (strpos($cs,'zixun')!==false){$str=$str.sitecount('zixun');}
if (strpos($cs,'special')!==false){$str=$str.sitecount('special');}
if (strpos($cs,'wangkan')!==false){$str=$str.sitecount('wangkan');}
if (strpos($cs,'baojia')!==false){$str=$str.sitecount('baojia');}
if (cache_update_time!=0){
	$fpath=zzcmsroot2."cache/".$siteskin."/sitecount.txt";
	$fp=fopen($fpath,"w+");//fopen()的其它开关请参看相关函数
	fputs($fp,stripfxg($str));//写入文件
	fclose($fp);
}	
return $str;
}
}

//显示联系方式在job/show.php,zhaoshang/show.php,pinpai/show.php
function showcontact($channel,$cpid,$startdate,$comane,$kind,$editor,$userid,$groupid,$somane,$sex,$phone,$qq,$email,$mobile,$fox){
checkid($groupid,1);
checkid($kind,1);//类别有为0的情况，所以第二个参数要设一下，设为1
if ($groupid==''){
$contact= "无用户信息";
}else{
$contact="<div id='zscontact'>" ;
$contact=$contact . "<ul>";
$contact=$contact . "<li>";
//$sqln="select groupname,grouppic,groupid,config from zzcms_usergroup where groupid=(select groupid from zzcms_user where username=(Select editor From zzcms_zhaoshang where id='$cpid'))";
$sqln="select groupname,grouppic,groupid,config from zzcms_usergroup where groupid=$groupid";
$rsn=query($sqln);
$rown=mysqli_fetch_array($rsn);
	if ($rown["groupid"]>1) {
	$contact=$contact . "<img src='/image/cxqy.png'/>";
	$contact=$contact . "<img src='/image/viptime/".(date('Y')-date('Y',strtotime($startdate))+1).".png'/>";
	}else{
	$contact=$contact . "<img src='".$rown["grouppic"]."'/>";
	$contact=$contact . "&nbsp;".$rown["groupname"];
	}
$showcontact=str_is_inarr($rown["config"],'showcontact');
$contact=$contact . "</li>";
$contact=$contact . "<li style='font-weight:bold'>".$comane."</li>";
$contact=$contact . "<li>";
	if ($kind<>"" && $kind<>0 ) {
	$rsn=query("select classname from zzcms_userclass where classid=".$kind."");
	$rown=mysqli_fetch_array($rsn);
	$contact=$contact ."经营模式：".$rown["classname"];
	}else{
	$contact=$contact ."经营模式：未选择";
	}
$contact=$contact ."</li>";
$contact=$contact ."<li style=height:36px>";
	if (sdomain=="Yes") {
	$contact=$contact . "<a href='".show2url($editor)."'>";
	}else{
	$contact=$contact . "<a href='".getpageurl_zt("zhanting",$userid)."'>";
	}
$contact=$contact . "<img src='/image/button_site.gif'  border='0' /></a></li>";
if ($showcontact=='yes'  || @$_COOKIE["dlliuyan"]==$editor) {
//if ($showcontact=='yes' ) {
	$contact=$contact . "<li>联系人：<b>".$somane."</b>&nbsp;";
	if ($sex==1){ 
	$contact=$contact . "先生";
	}elseif($sex==0){
	$contact=$contact . "女士";
	}
	$contact=$contact . "</li>";
	$contact=$contact . "<li>电　话：".$phone."</li>";
	$contact=$contact . "<li>传　真：".$fox."</li>";
	$contact=$contact . "<li>手　机：".$mobile."</li>";
	$contact=$contact . "<li>E-mail：".$email."</li>";
	if ($qq<>"") {
	//$contact=$contact . "<li><a target=blank href=http://wpa.qq.com/msgrd?v=1.uin=".$qq.".Site=".sitename.".Menu=yes><img border=0 src=http://wpa.qq.com/pa?p=1:".$qq.":10 alt='QQ交流'></a></li>";
	//造成显示页打开很慢
	}	
}else{
	if ($channel=="job"){
	$contact=$contact . "<li style='height:50px'>普通会员联系方式不显示，应聘者请直接投简历到该公司EMAIL</li>";
	}else{
	$contact=$contact . "<li>联系方式<a href='#dl_liuyan'><b>留言</b></a>后在此显示。</li>";
	}
}
$contact=$contact . "</ul>";
$contact=$contact . " </div>";
}
return $contact;
}

function del_dirandfile( $dir,$deldir=true){
if (file_exists($dir)){
if ( $handle = opendir( "$dir" ) ) {
	while ( false !== ( $item = readdir( $handle ) ) ) {
	if ( $item != "." && $item != ".." ) {
		if ( is_dir( "$dir/$item" ) ) {
		del_dirandfile( "$dir/$item" );
		} else {
		if( unlink( "$dir/$item" ) )echo "成功删除文件：".$dir."/".$item."<br /> ";
		}
	}
	}
   closedir( $handle );
	if ($deldir==true){//是否删除空目录
	if( rmdir( $dir ) )echo "成功删除目录：". $dir."<br /> ";
	}
}
}else{
echo "目录已不存在，已完成清理<br />"; 
}
//echo "缓存已被清理<br />";
}

function checkver($str){
if(strpos($str,base64_decode('aHR0cDovL3d3dy56emNtcy5uZXQ='))===false){
tsmsg(base64_decode('PGRpdiBzdHlsZT0nZm9udC1zaXplOjIwcHgnPuWFjei0ueeJiCzli7/liKDmlLlaWkNNU+agh+ivhu+8gei/mOWOn+WQjizliJnkuI3lho3mj5DnpLo8L2Rpdj4='));
}
}

function checkadminisdo($str){
global $admin;
$rs=query("select config from zzcms_admingroup where id=(select groupid from zzcms_admin where pass='".@$_SESSION["pass"]."' and admin='".@$admin."')");//只验证密码会出现，两个管理员密码相同的情况，导致出错,前加@防止SESSION失效后出错提示
	$row=mysqli_fetch_array($rs);
	$config=$row["config"];
	if(str_is_inarr($config,$str)=='no'){showmsg('没有操作权限!');}
}

function checkadminisdo2($str){
global $admin;
$rs=query("select config from zzcms_admingroup where id=(select groupid from zzcms_admin where pass='".@$_SESSION["pass"]."' and admin='".@$admin."')");
	$row=mysqli_fetch_array($rs);
	$config=$row["config"];
	if(str_is_inarr($config,$str)=='no'){
	return 'no';
	}elseif(str_is_inarr($config,$str)=='yes'){
	return 'yes';
	}
}

function check_user_power($str){
global $username;
if (!isset($username)){
$username=$_COOKIE["UserName"];
}
$rs=query("select config from zzcms_usergroup where groupid=(select groupid from zzcms_user where username='".$username."')");
	$row=mysqli_fetch_array($rs);
	$config=$row["config"];
	if (str_is_inarr($config,$str)=='yes'){return 'yes';}else{return 'no';}
}


function get_zhuyuming($str){
$houzhui_array = array(".com",".net",".org",".gov",".edu","com.cn",".cn",".tv",".cc",".top",".xyz");
for($i=0; $i<count($houzhui_array);$i++){
	$str=trim(str_replace($houzhui_array[$i],'',$str));
    }	
 return $str;
}

function pay_jifen($channel,$id){
global $username;
if (jifen=="Yes" && jf_addinfo<>0){
	$rsuser=query("select totleRMB from zzcms_user where username='".$username."'");
	$rowuser=mysqli_fetch_array($rsuser);
		if ($rowuser["totleRMB"]>=jf_addinfo) {
		query("update zzcms_user set totleRMB=totleRMB-".jf_addinfo." where username='".$username."'");//发布时扣积分
		//写入冲值记录 
		query("insert into zzcms_pay (username,dowhat,RMB,mark,sendtime) values('".@$username."','发布信息','-".jf_addinfo."','<a href=../$channel/show.php?id=$id target=_blank>$id</a>','".date('Y-m-d H:i:s')."')");		
		echo "<script>alert('发布成功：已扣".jf_addinfo."积分')</script>";
		}else{
		tsmsg("<li>您的帐户中已不足".jf_addinfo."金币，暂不能发布！<a href='../3/alipay'>充值</a></li>");
		exit;
		}
}
}

function get_groupname($groupid){
$groupname='';
if ($groupid<>0){
$rs=query("select groupname from zzcms_usergroup where groupid='".$groupid."'");
$row=mysqli_fetch_array($rs);
$groupname=$row["groupname"];
}else{
$groupname='未知';
}
return $groupname;
}
//递归父类下的所有子类
function get_class_list($table,$parentid=0,&$result=array(),$spac=0){
$spac=$spac+4;
$sql="select * from `".$table."` where parentid={$parentid} order by xuhao";
$rs=query($sql);
while($row=mysqli_fetch_array($rs)) {
$row['classname']=str_repeat('&nbsp;&nbsp;',$spac).$row['classname'];
$result[]=$row;
get_class_list($table,$row['classid'],$result,$spac);            
}
return $result;
}
//递归显示当前类别下的所有小类
function displaylist($table,$parentid){
$rs=get_class_list($table,$parentid);
$str='';
foreach ($rs as $key => $val) {
$str.="{$val['classid']},";
}
return $str.$parentid;//返回值中加上父类id
}

//递归子类上的所有父类
function get_class_link($table,$classid,&$result=array()){
$sql="select * from `$table` where classid='{$classid}'";
//echo $sql;
$rs=query($sql);
if($row=mysqli_fetch_array($rs)){
$result[]=$row;
get_class_link($table,$row['parentid'],$result);
}
return array_reverse($result);
}
//递归显示导航条
function displaylink($table,$classid){
$rs=get_class_link($table,$classid);
$str='';
foreach ($rs as $val) {
	if (whtml=="Yes") {
	$str.="<a href='{$val['classzm']}'>{$val['classname']}</a>>";
	}else{
	$str.="<a href='list.php?c={$val['classzm']}'>{$val['classname']}</a>>";
	}
}
return $str;
}

function getstation($table,$cid,$title,$keyword,$channel){
	$str="<a href='".siteurl."'>首页</a>>";
	if (whtml=="Yes") {
		$str.= "<a href='/".$channel."'>".getchannelname($channel)."</a>>" ;
		$str.= displaylink($table,$cid);
		//if ($title<>"") {$str.= $title;}
		if ($keyword<>"") {$str.="关键字中含有“".$keyword."”";}
	}else{
		$str.="<a href='list.php'>".getchannelname($channel)."</a>>" ;
		$str.=displaylink($table,$cid);
		//if ($title<>"") {$str.= $title;}
		if ($keyword<>"") {$str.="关键字中含有“".$keyword."”";}
	}
return $str;	
}

function addtable($table,$classid){ //增加分类时增加分表
	$newtable=$table.$classid;
	//echo $newtable;
	query("CREATE TABLE `".$newtable."` SELECT * FROM `".$table."` WHERE 1=2") or die (tsmsg("失败，创建表"));//新建表
	query("INSERT INTO `".$newtable."` SELECT * FROM  `".$table."` WHERE classid='".$classid."'");//复制信息到新表
	query("ALTER TABLE  `".$newtable."` ADD `zid` int(4) default 1 COMMENT '主表ID' AFTER `id`");//加zid字段
	query("UPDATE `".$newtable."` SET `zid`=`id`");//复制zid字段值
	query("alter table `".$newtable."` modify id int auto_increment primary key") ;//主键索引//query("ALTER TABLE  `".$newtable."` ADD  PRIMARY  KEY (`id`)") ;//主键索引
	query("ALTER TABLE  `".$newtable."` DROP `classid`");//删除clssid
	query("ALTER TABLE  `".$newtable."` ADD INDEX  (`passed`)") or die (tsmsg("失败，添加索引"));
}

function c($table,$b){//大类列表，管理后台在调用
$str='';
$sql="select classid,classname from `".$table."` where parentid=0 order by xuhao";
$rs = query($sql); 
$row = num_rows($rs);
	if (!$row){
	$str= '暂无分类';
	}else{
		while($row = fetch_array($rs)){
		$str=$str."<a href=?b=".$row['classid'].">";  
		if ($row["classid"]==$b) {
		$str=$str. "<b>".$row["classname"]."</b>";
		}else{
		$str=$str. $row["classname"];
		}
		$str=$str. "</a>";  
		} 
	}
	return $str;
}

function showclass($table,$channel,$pid=0,$cid=0,$num=999,$cs=0){//大类列表，前台在调用
$str="";$n=1;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$table."'"))==1) {
$sql="select classname,classid,classzm from `".$table."` where parentid='{$pid}' and isshow=1 order by xuhao limit 0,$num";
$rs=query($sql);
//echo $sql."<br>";
$row=mysqli_num_rows($rs);
if (!$row){
$str="暂无分类";
}else{

while ($row=mysqli_fetch_array($rs)){
if($row['classid']==$cid){
$str.="<li class='current'>";}else{$str.="<li>";}	
if ($cs==0){
	//$str.="<a href='".getpageurl2($channel,$row["classzm"])."'>".$row["classname"]."</a>";
	$str.="<a href='".getpageurl_class($channel,$row["classzm"])."'>".$row["classname"]."</a>";
	}else{
	$str.="<a href='?c=".$row["classzm"]."'>".$row["classname"]."</a>";
	}
	$str.="</li>";
$n=$n+1;		
}
}
}
return $str;
}

function getclassname($table,$cid,$item='classname'){
$sql="select classname,classzm from `".$table."` where classid='{$cid}' ";
$rs = query($sql); 
$row = fetch_array($rs);
if($item=='classname'){
return $row["classname"];	
}elseif($item=='classzm'){
return $row["classzm"];	
}
}

function read_tpl($tpl){
global $siteskin;
$fp=zzcmsroot."template/".$siteskin."/".$tpl;
if (file_exists($fp)==false){die(tsmsg($fp.'模板文件不存在'));}
return file_get_contents($fp);
}

function showzhsj($column,$zhsj){
$str="<table width='100%' border='0' cellpadding='5' cellspacing='1' class='bgcolor3'>";
$str=$str."<tr>";
for($i=1;$i<=12;$i++){
if ($zhsj==$i  || date('m')==$i){
$str=$str."<td align='center' class='bgcolor3' >";
}else{
$str=$str."<td align='center' class='bgcolor1' >";
}
$str=$str."<a href='search.php?zhsj=".$i."'>".addzero($i,2)."月</a>";
$str=$str."</td>";
if ($i % $column==0) { 
$str=$str."</tr>";
}
}
$str=$str."</table>";
return $str;
}

function showlist($cs){
$str="";
$cs=explode(",",$cs); //传入的$cs是一个整体字符串,转成数组
$channel=isset($cs[0])?$cs[0]:'';
$table='zzcms_'.$channel;
$classid=isset($cs[1])?$cs[1]:0;checkid($classid,1);
$editor=isset($cs[2])?$cs[2]:'';
$num=isset($cs[3])?$cs[3]:10;checkid($num);
$strnum=isset($cs[4])?$cs[4]:10;checkid($strnum);

$sql="select * from `$table` where passed=1 ";
if ($classid<>''&& $classid<>0){
$sql=$sql."and classid ='".$classid."' ";
}
if ($editor<>''){
$sql=$sql."and editor ='".$editor."' ";
}
$sql=$sql."order by id desc ";
$sql=$sql." limit 0,$num";
//echo $sql;
$rs=query($sql);
$row=num_rows($rs);
if ($row){
while ($row=fetch_array($rs)){
$str=$str ." <li><a href='".getpageurl($channel,$row["id"])."' target='_blank'>".cutstr($row["title"],$strnum)."</a></li>";
}
}else{
$str="暂无信息";
}
return $str;
}
?>