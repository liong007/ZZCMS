<?php
//error_reporting(0);
ob_start();//打开缓冲区，这样输出内容后还可以setcookie
define('zzcmsroot', str_replace("\\", '/', substr(dirname(__FILE__), 0, -3)));//-3截除当前目录inc
ini_set("date.timezone","Asia/Chongqing");//设时区。php.ini里date.timezone选项，默认情况下是关闭的

/*switch ($siteskin){
case '9':$config_date='_jiu'; break;
case 'ali':$config_date='_ali'; break;
default:$config_date='';
}
require(zzcmsroot."/inc/config_date".$config_date.".php");
*/
require(zzcmsroot."/inc/config.php");
require(zzcmsroot."/inc/wjt.php");
require(zzcmsroot."/inc/zh_cn.lang.php");
require(zzcmsroot."/inc/function.php");
require(zzcmsroot."/inc/function.global.php");
require(zzcmsroot."/inc/zsclass.php");//分类招商在里面
require(zzcmsroot."/zixun/sub.php");
require(zzcmsroot."/zhaoshang/sub.php");
require(zzcmsroot."/inc/global.php");
require(zzcmsroot."/inc/area.php");
if (opensite=='No') {
	if (@checkadminlogin<>1) {
	tsmsg(showwordwhenclose);
	exit();
	}
}
$file=zzcmsroot."/install/install.lock";//是否存在安装标识文件
$installdir=zzcmsroot."install";
if (file_exists($file)==false && is_dir($installdir) ){//同时检测安装目录install，如果删除安装目录后，则不再提示
tsmsg("未检测到安装标识文件，<a href='http://".$_SERVER['HTTP_HOST']."/install/index.php'>点击运行安装向导</a>");
exit();
}

$conn=@mysqli_connect(sqlhost,sqluser,sqlpwd,sqldb,sqlport) or showmsg ("数据库链接失败",'null');
mysqli_real_query($conn,"SET NAMES 'utf8'"); //必不可少，用来设置客户端送给MySQL服务器的数据的字符集
mysqli_select_db($conn,sqldb) or showmsg ("没有".sqldb."这个数据库,或是被管理员断开了链接,请稍后再试");
stopip();
//if ($admin<>''){
//admindo();//如果管理员登录，记录管理员操作记录
//}


//执行语句   
function query($sql){  //执行针对数据库的查询 
//echo $sql;
global $conn;
return mysqli_query($conn,$sql);     
}  

function fetch_array($result){   //从结果集中取得一行作为数字数组或关联数组
return mysqli_fetch_array($result);     
} 

function num_rows($result){    //返回结果集中行的数量 
return mysqli_num_rows($result);     
} 

function insert_id() {//函数返回最后一个查询中自动生成的 ID（通过 AUTO_INCREMENT 生成）
global $conn;
return mysqli_insert_id($conn);
}

function free_result() {// 释放结果集
global $result;
return mysqli_free_result($result);
}

function close() {// 关闭数据库链接
global $conn;
return mysqli_close($conn);
}
?>