<?php
function showlabel($str){
global $cid;//zhaoshang需要从zhaoshang/class.php获取$cid；zixun从zixun/class.php获取$cid；
//固定标签=========================
$channels=array('ad','zhaoshang','daili','zixun','pinpai','job','zhanhui','announce','cookiezs','zsclass','keyword','province','sitecount');
foreach ($channels as $value) {
if (strpos($str,"{#show".$value.":")!==false){
$n=count(explode("{#show".$value.":",$str));//循环之前取值
	for ($i=1;$i<$n;$i++){ 
	$cs=strbetween($str,"{#show".$value.":","}");
	if ($cs<>''){$str=str_replace("{#show".$value.":".$cs."}",fixed($cs,$value),$str);}	//$cs直接做为一个整体字符串参数传入，调用时再转成数组遍历每项值
	}	
}
}
//固定标签之万能标签=========================
if (strpos($str,"{#showlist:")!==false){
$n=count(explode("{#showlist:",$str));//循环之前取值
	for ($i=1;$i<$n;$i++){ 
	$cs=strbetween($str,"{#showlist:","}");
	if ($cs<>''){$str=str_replace("{#showlist:".$cs."}",showlist($cs),$str);}	//$cs直接做为一个整体字符串参数传入，调用时再转成数组遍历每项值
	}	
}
//自定义标签=========================
$channels=array('zhaoshang','daili','zixun','pinpai','job','wangkan','zhanhui','company','special','baojia','ask','link','ad','about','guestbook','help');
foreach ($channels as $value) {
//类别标签
if (strpos($str,"{@".$value."class.")!==false) {
	$n=count(explode("{@".$value."class.",$str));//循环之前取值
	for ($i=1;$i<$n;$i++){ 
	$mylabel=strbetween($str,"{@".$value."class.","}");
	$str=str_replace("{@".$value."class.".$mylabel."}",labelclass($mylabel,$value),$str);
	}
}
//内容标签
if (strpos($str,"{@".$value."show.")!==false) {
	$n=count(explode("{@".$value."show.",$str));//循环之前取值
	for ($i=1;$i<$n;$i++){ 
	$mylabel=strbetween($str,"{@".$value."show.","}");
	$str=str_replace("{@".$value."show.".$mylabel."}",labelshow($value,$mylabel,$cid),$str);
	}
}
}
return $str;
}

function writecache($channel,$classzm,$labelname,$str){//$classid,$labelname 这两个参数在外部函数的参数里，没有在函数内部无法通过global获取到。
global $siteskin,$province;
	if ($classzm!=''){
	$fpath=zzcmsroot."cache/".$siteskin."/".$channel."/".$classzm."-".$labelname.".txt";
	}elseif($province<>''){//area.php中调用zs,dl,company三个频道中用到这个条件。
	$fpath=zzcmsroot."cache/".$siteskin."/".$channel."/".$province."-".$labelname.".txt";
	}else{
	$fpath=zzcmsroot."cache/".$siteskin."/".$channel."/".$labelname.".txt";
	}
	if (!file_exists(zzcmsroot."cache/".$siteskin."/".$channel)) {mkdir(zzcmsroot."cache/".$siteskin."/".$channel,0777,true);}
	//echo zzcmsroot."cache/".$siteskin."/".$channel;
	$fp=fopen($fpath,"w+");//fopen()的其它开关请参看相关函数
	fputs($fp,stripfxg($str));//写入文件
	fclose($fp);	
}

function fixed($cs,$channel){
switch ($channel){
case 'ad':return showad($cs); break;
case 'zhaoshang':return showzhaoshang($cs); break;
case 'daili':return showdaili($cs); break;
case 'pinpai':return showpinpai($cs); break;
case 'job':return showjob($cs); break;
case 'zixun':return showzixun($cs); break;
case 'zhanhui':return showzhanhui($cs); break;
case 'announce':return showannounce($cs); break;
case 'cookiezs':return showcookiezs($cs); break;
case 'zsclass':return showzsclass($cs); break;
case 'keyword':return showkeyword($cs); break;
case 'province':return showprovince($cs); break;
case 'sitecount':return showsitecount($cs); break;
}
}

function labelclass($labelname,$channel){
global $siteskin,$cid;//取外部值，供演示模板用
if (!isset($siteskin)){$siteskin=siteskin;}
$fpath=zzcmsroot."/template/".$siteskin."/label/".$channel."class/".$labelname.".txt";
if (file_exists($fpath)==true){
if (filesize($fpath)<10){ showmsg(zzcmsroot."template/".$siteskin."/label/".$channel."class/".$labelname.".txt 内容为空");}//utf-8有文件头，空文件大小为3字节
$fcontent=file_get_contents($fpath);
$f=explode("|||",$fcontent) ;
$startnumber = $f[1];$numbers = $f[2];$column = $f[3];$start = $f[4];$mids = $f[5];$ends = $f[6];
if($channel=="zixun" || $channel=="special" || $channel=="ask"){
	$mids = str_replace("list.php?c={#c}","/".$channel."/list.php?c={#c}",$mids);//后有小类的同样会被转换前面加/
	}
if ( whtml == "Yes"){
$mids = str_replace("list.php?c={#c}", "{#c}",$mids);
	if($channel=="zhaoshang"){
	$mids = str_replace("class.php?c={#c}", "{#c}.html",$mids);
	}
	if($channel=="zixun" || $channel=="special" || $channel=="ask"){
	//$mids = str_replace("/".$channel."/list.php?b={#bigclassid}&s={#smallclassid}","/".$channel."/{#bigclassid}/{#smallclassid}",$mids);
	$mids = str_replace("/".$channel."/list.php?c={#c}","/".$channel."/{#c}",$mids);
	}
	if($channel=="special"){
	$mids = str_replace("class.php?c={#c}","/".$channel."/class/{#c}",$mids);
	}
}
if ($channel=='zhaoshang' || $channel=='pinpai'|| $channel=='daili'|| $channel=='baojia'){
$sql ="select classid,classname,classzm from zzcms_zhaoshangclass  where isshow=1 and parentid=0 order by xuhao limit $startnumber,$numbers ";
}elseif($channel=='job'){
$sql ="select * from zzcms_jobclass where isshow=1 and parentid=0 order by xuhao limit $startnumber,$numbers ";
}elseif($channel=="zhanhui" || $channel=="link"|| $channel=="wangkan"){
$sql ="select * from zzcms_".$channel."class order by xuhao limit $startnumber,$numbers ";
}elseif($channel=="company"){
$sql ="select * from zzcms_userclass where  isshow=1 and parentid=0 order by xuhao limit $startnumber,$numbers ";
}elseif($channel=="zixun" || $channel=="special" || $channel=="ask"){
	if ($cid<>0 && strpos($labelname,'_s') !== false ){//如果调用资讯大类作为导航时不能调用外部b参数，如果调用大类下的小类则启用B参数,这里用判断标签名的方式传参
	$sql ="select * from zzcms_".$channel."class where isshow=1 and parentid='".$cid."' order by xuhao limit $startnumber,$numbers ";
	}else{
	$sql ="select * from zzcms_".$channel."class where isshow=1 and parentid=0 order by xuhao limit $startnumber,$numbers ";
	}
}
//echo $sql."<br/>";
$rs=query($sql);
$str="";$i = 1;$mids2='';
$mylabels=get_label($mids);//用正则可获取一个或多个标签,返回值是数组
while($r=mysqli_fetch_array($rs)){
$mids2=$mids2.$mids;
$mids2=str_replace("{#classname}",$r["classname"],str_replace("{#classid}",$r["classid"],str_replace("{#c}",$r["classzm"],$mids2)));

$c_num=strbetween($mids,"{#zssmallclass:","}");//zhaoshang在用
if ($c_num==''){$c_num=0;}//zhaoshang在用
$mids2=str_replace("{#zssmallclass:".$c_num."}",showclass('zzcms_zhaoshangclass','zhaoshang',$r["classid"],$r["classid"],$c_num),$mids2);//zhaoshang在用

foreach($mylabels as $mylabel){//嵌套单个或多个
$mylabel=str_replace($channel."show.","",$mylabel);//正则中通一从{@开始截取的，这里要替换
$mids2=str_replace("{@".$channel."show.".$mylabel ."}",labelshow($channel,$mylabel,$r["classid"]),$mids2);
}

if ($i==1){//zhaoshang在用
$mids2=str_replace("{#title_style}","class=current1",$mids2);
$mids2=str_replace("{#content_style}","style=display:block",$mids2);
}else{
$mids2=str_replace("{#title_style}","",$mids2);
$mids2=str_replace("{#content_style}","style=display:none",$mids2);
}

$mids2=str_replace("{#i}", $i,$mids2);//类别标签中序号用i，内容标签中用n,以区别开，这样在内容标签中可以调用i
	if ($column <> "" && $column >0){
		if ($i % $column == 0) {$mids2 = $mids2 . "</tr>";}
	}
$i = $i + 1;
}
$str = $start.$mids2 . $ends;
$str=showlabel($str);//分类标签中有对广告固定标签的调用;如果开启判断版式权标识时，会出提示
if ($mids2==''){$str='暂无信息';}
return $str;
}
}

function labelshow($channel,$labelname,$classid){
if ($channel=='ad'){
return ad($labelname,$classid,0);
}else{
if ($labelname!=''){//如果通过管理后台创建空名文档，打开时会出错，所以这里加判断
global $siteskin,$province,$city,$c;//取外部值，供演示模板，手机模板用
//setcookie("province","xxx",1);setcookie("city","xxx",1);setcookie("p_id","xxx",1);setcookie("c_id","xxx",1);//搜索页的cookie值会影响到province的值,清空后，search.php返回时不再有值
$province_hz=province_zm2hz($province);$city_hz=city_zm2hz($city);
if (!$siteskin){$siteskin=siteskin;}
if ($classid!=0){$fpath=zzcmsroot."cache/".$siteskin."/".$channel."/".$classid."-".$labelname.".txt";
}elseif($province<>''){$fpath=zzcmsroot."cache/".$siteskin."/".$channel."/".$province."-".$labelname.".txt";
}else{$fpath=zzcmsroot."cache/".$siteskin."/".$channel."/".$labelname.".txt";}
if (cache_update_time!=0 && file_exists($fpath)!==false && time()-filemtime($fpath)<3600*24*cache_update_time){
	return file_get_contents($fpath);
}else{
$fpath=zzcmsroot."template/".$siteskin."/label/".$channel."/".$labelname.".txt";
if (file_exists($fpath)==true){
if (filesize($fpath)<10){ showmsg(zzcmsroot."template/".$siteskin."/label/".$channel."/".$labelname.".txt 内容为空");}//utf-8有文件头，空文件大小为3字节
$fcontent=file_get_contents($fpath);
$f=explode("|||",$fcontent) ;
if ($channel=='zhaoshang'){
$title=$f[0];$cid =$f[1];$groupid =$f[2];$pic =$f[3];$flv =$f[4];$elite = $f[5];$numbers = $f[6];$orderby =$f[7];$column = $f[8];$start =$f[9];$mids = $f[10];$ends = $f[11];
}elseif($channel=='pinpai'){
$title=$f[0];$cid=$f[1];$pic =$f[2];$numbers = $f[3];$orderby =$f[4];$column = $f[5];$start =$f[6];$mids = $f[7];$ends = $f[8];
}elseif($channel=='job'|| $channel=='baojia'){
$title=$f[0];$cid=$f[1];$numbers = $f[2];$orderby =$f[3];$column = $f[4];$start =$f[5];$mids = $f[6];$ends = $f[7];
}elseif($channel=='daili'){
$title=$f[0];$cid=$f[1];$saver = $f[2];$numbers = $f[3];$orderby =$f[4];$column = $f[5];$start =$f[6];$mids = $f[7];$ends = $f[8];
}elseif($channel=='guestbook'){
$title=$f[0];$numbers = $f[1];$column = $f[2];$start =$f[3];$mids = $f[4];$ends = $f[5];
}elseif($channel=='zhanhui'||$channel=='wangkan'){
$title=$f[0];$cid=$f[1];$elite = $f[2];$numbers = $f[3];$orderby =$f[4];$column = $f[5];$start =$f[6];$mids = $f[7];$ends = $f[8];
}elseif($channel=='company'){
$title=$f[0];$cid=$f[1];$groupid=$f[2];$pic=$f[3];$flv=$f[4];$elite=$f[5];$numbers=$f[6];$orderby=$f[7];$column=$f[8];$start=$f[9];$mids=$f[10];$ends=$f[11];
}elseif($channel=='zixun' || $channel=='special'){
$title=$f[0];$cid=$f[1];$pic =$f[2];$elite = $f[3];$numbers = $f[4];$orderby =$f[5];$column = $f[6];$start =$f[7];$mids = $f[8];$ends = $f[9];
}elseif($channel=='about'){
$title=$f[0];$id=$f[1];$column = $f[2];$start =$f[3];$mids = $f[4];$ends = $f[5];
}elseif($channel=='link'){
$title=$f[0];$cid=$f[1];$pic =$f[2];$elite = $f[3];$numbers = $f[4];$column = $f[5];$start=$f[6];$mids = $f[7];$ends = $f[8];
}elseif($channel=='ask'){
$title=$f[0];$cid = $f[1];$pic =$f[2];$elite = $f[3];$typeid = $f[4];$numbers = $f[5];$orderby =$f[6];$column = $f[7];$start =$f[8];$mids = $f[9];$ends = $f[10];
}elseif($channel=='help'){
$title=$f[0];$elite = $f[1];$numbers = $f[2];$orderby =$f[3];$column = $f[4];$start =$f[5];$mids = $f[6];$ends = $f[7];
}

if($channel=='company'){
$mids = str_replace("show.php?id={#id}", "/zhanting/show.php?id={#id}",$mids);
}else{
$mids = str_replace("show.php?id={#id}", "/".$channel."/show.php?id={#id}",$mids);
}
$mids = str_replace("list.php?c={#c}", "/".$channel."/list.php?c={#c}",$mids);//zixun用
$mids = str_replace("class.php?c={#c}","/".$channel."/class.php?c={#c}",$mids);
$mids = str_replace($channel.".php#{#id}", "/one/".$channel.".php#{#id}",$mids);//help用
if (whtml == "Yes") {
if($channel=='company'){
$mids = str_replace("/zhanting/show.php?id={#id}", "/zhanting/{#id}.html",$mids);
}else{
$mids = str_replace("/".$channel."/show.php?id={#id}", "/".$channel."/show_{#id}.html",$mids);
}
$mids = str_replace("/".$channel."/list.php?c={#c}","/".$channel."/{#c}",$mids);//zixun用
$mids = str_replace("/".$channel."/class.php?c={#c}","/".$channel."/class/{#c}",$mids);	
$mids = str_replace("/one/".$channel.".php#{#id}", "/".$channel.".html#{#id}",$mids);//help用
}

if($channel=='company'){$table='zzcms_user';}else{$table='zzcms_'.$channel;}

$table_class='zzcms_'.$channel.'class';
if($channel=='zhaoshang'|| $channel=='daili'|| $channel=='pinpai'|| $channel=='baojia'|| $channel==''|| $channel=='area'|| $channel=='zhaoshangclass'){
$table_class='zzcms_zhaoshangclass';
}elseif($channel=='company'){
$table_class='zzcms_userclass';
}

$classid_waibu='';
if ($channel!='about'&& $channel!='guestbook'&& $channel!='help'){
if ($c<>''){//外部大类优先,可以做到只显示当前类别下的信息，如hot,new等标签的调用
$sql="select * from `$table_class` where classzm='".$c."' and isshow=1 ";
$rs=query($sql);
$row=mysqli_fetch_array($rs);
$classid_waibu=$row["classid"];
}
}

if (@$cid<>''&& @$cid<>0 && @$cid<>'empty'){//第1优先级，标签内指定的
$tables=$table.$cid;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$tables."'"))<>1) {addtable($table,$cid);}//加表
}elseif($classid<>''&& $classid<>0 && $classid<>'empty'){//第2优先级，嵌套在class标签内的
$tables=$table.$classid;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$tables."'"))<>1) {addtable($table,$classid);}//加表
}elseif($classid_waibu<>''){//第3优先级，外部指定的
$tables=$table.$classid_waibu;
if(mysqli_num_rows(query("SHOW TABLES LIKE '".$tables."'"))<>1) {addtable($table,$classid_waibu);}//加表
}else{
$tables=$table;//如果都没有调用主表
}

$sql = "select * from `$tables` where passed=1 ";
if ($channel=='company'){
$sql =$sql ." and usersf='公司' and comane<>'' and lockuser=0 ";
}

if ($channel=='about'){	
	if ($id <> 0 ){$sql = $sql ." and id='$id'";}//about在用
}

if ($channel=='zhaoshang'){	
	if ( $groupid <> 0) {$sql = $sql . " and groupid>=$groupid ";}    
	if ( $flv == 1) {$sql = $sql . " and flv is not null and flv<>'' ";} 	
}

if ($channel=='company'|| $channel=='zixun'|| $channel=='zhaoshang'){	
	if ( $pic == 1) {$sql = $sql . " and img is not null and img <>'' and img<>'/image/nopic.gif'";}    
	if ( $elite == 1) {$sql = $sql . " and elite>0";}
}
	
if ($channel=='daili'){		
	if ($saver==1){$sql = $sql . " and saver is not null ";}//daili,guestbook在用
}
if ($channel=='zhaoshang'|| $channel=='company'|| $channel=='ad'|| $channel=='job'|| $channel=='zixun'|| $channel=='daili'|| $channel=='baojia'){	
	if ($city <>''){$sql = $sql . " and city='$city_hz' ";}elseif($province <>''){$sql = $sql . " and province='$province_hz' ";}
}

if ($channel<>'ad' && $channel<>'link' && $channel<>'about'&& $channel<>'guestbook'){	
	if ( $orderby == "hit") {$sql = $sql . " order by hit desc limit 0,$numbers ";
	}elseif ($orderby == "id") {$sql = $sql . " order by id desc limit 0,$numbers ";
	}elseif ($orderby == "sendtime") {$sql = $sql . " order by sendtime desc limit 0,$numbers ";
	}elseif ($orderby == "rand") {
	$sqln="select count(*) as total from `$tables` where passed<>0 ";
	$rsn=query($sqln);
	$rown = mysqli_fetch_array($rsn);
	$totlenum = $rown['total'];
		if (!$totlenum){
		$shuijishu=0;
		}else{
		$shuijishu=rand(1,$totlenum-$numbers);
		if ($shuijishu<0){$shuijishu=0;}
		}
	$sql = $sql . " limit $shuijishu,$numbers";
	}
}	
//echo $sql."<br>";
$rs=query($sql);
$str="";$n = 1;$mids2='';

while($r=mysqli_fetch_array($rs)){
$mids2 = $mids2 .$mids;	

$tnum=strbetween($mids,"{#title:","}");

if ($channel=='zhaoshang'){
$content=$r["sm"];//zhaoshang
$cnum=strbetween($mids,"{#prouse:","}");//zhaoshang
}else{
$content=stripfxg(@$r["content"],true);
$cnum=strbetween($mids,"{#content:","}");
}
if ($channel=='company'){
$title=@$r["comane"];
}else{
$title=@$r["title"];
}

	if (@$r["link"]<>''){//当为外链时
		if (whtml=="Yes"){
		$mids2=str_replace("/".$channel."/show_{#id}.html", addhttp(@$r["link"]),$mids2);
		}else{
		$mids2=str_replace("/".$channel."/show.php?id={#id}",addhttp(@$r["link"]),$mids2);
		}
	}
	if (@$r["shuxing_value"]==''){
	for ($a=0; $a< 6;$a++){
	$mids2=str_replace("{#shuxing".$a."}",'',$mids2);
	}
	}else{
	$shuxing_value = explode("|||",@$r["shuxing_value"]);
	for ($a=0; $a< count($shuxing_value);$a++){
	$mids2=str_replace("{#shuxing".$a."}",$shuxing_value[$a],$mids2);
	}
	}
	$mids2 =str_replace("{#classid}", $classid,$mids2);//如排行页用来区分不同类别
	if ($n==1){$mids2=str_replace("display:none","",$mids2);}//招商排行榜中有用
	
//daili,guestbook	
if ($channel=='daili'||$channel=='guestbook'){
	$mobile=$r['tel'];
	if (strpos($mids2,'{#companyname}')!==false || strpos($mids2,'{#companyimg}')!==false || strpos($mids2,'{#companyimgbig}')!==false){
		$rsn=query("select id,username,img,comane from zzcms_user where username='".$r['saver']."' ");
		if ($rsn){
		$rown=mysqli_fetch_array($rsn);
		if (sdomain=="Yes"){$mids2= str_replace("{#zturl}","http://".$rown['username'].".".substr(siteurl,strpos(siteurl,".")+1),$mids2);}
		if (whtml == "Yes") {$mids2 = str_replace("{#zturl}","/zhanting/".$rown['id'].".html",$mids2);}//需要从company目录转到zt}
		$mids2 = str_replace("{#zturl}","/zhanting/show.php?id=".$rown['id'],$mids2);//需要从company目录转到zt
		$companyname_long=strbetween($mids2,"{#companyname:","}");
		$mids2 =str_replace("{#companyname:".$companyname_long."}",cutstr($rown['comane'],$companyname_long),$mids2) ;
		$mids2=str_replace("{#companyname}",$rown['comane'],$mids2);
		$mids2=str_replace("{#companyimg}", getsmallimg($rown['img']),$mids2);
		$mids2=str_replace("{#companyimgbig}", $rown['img'],$mids2);
		}else{
		$mids2=str_replace("{#companyname}",'意向公司用户已不存在',$mids2);//不存在时加提示
		}
	}
}	
//zhanhui
if ($channel=='zhanhui'){
	$address_long=strbetween($mids2,"{#address:","}");
	$mids2 = str_replace("{#address}",$r["province"],$mids2);//这样命名是按省份搜索时的需要	
	$mids2 = str_replace("{#address:".$address_long."}",cutstr($r['province'],$address_long),$mids2) ;
	$mids2 = str_replace("{#timestart}", date("Y-m-d",strtotime($r["timestart"])),$mids2);
	$mids2 = str_replace("{#timeend}",date("Y-m-d",strtotime($r["timeend"])),$mids2);
}	
//company
if ($channel=='company'){
$mids2 = str_replace("{#sendtime}", $r["regdate"],$mids2);
}	
//zixun,special

//link
if ($channel=='link'){
$mids2 = str_replace("{#url}",addhttp($r["url"]),$mids2);
$mids2 = str_replace("{#logo}", $r["img"],$mids2);
$mids2 = str_replace("{#sitename}",$r["sitename"],$mids2);
}
//ask
if ($channel=='ask'){
$rs_answer_num = query("select count(*) as total from zzcms_answer where about='".$r["id"]."' "); 
	$row_answer_num = mysqli_fetch_array($rs_answer_num);
	$answer_num = $row_answer_num['total'];
	$mids2=str_replace("{#answer_num}", $answer_num,$mids2);
	
	$zhuangtai_biaozhi='';
	if ($r["typeid"]==1){
	$zhuangtai_biaozhi="<img src='/image/dui2.png' title='已解决'>";
	}elseif ($r["typeid"]==0){
	$zhuangtai_biaozhi="<img src='/image/wenhao.png' title='待解决'>";
	}
	$mids2=str_replace("{#zhuangtai}", $zhuangtai_biaozhi,$mids2);	
}	
	require(zzcmsroot.'inc/mid2.php');
$n = $n + 1;
}
$str = $start.$mids2.$ends;
if ($mids2==''){$str='暂无信息';}
if (cache_update_time!=0){writecache($channel,$classid,$labelname,$str);}
return $str;
}//end if file_exists($fpath)==true
}//end if (cache_update_time!=0 && file_exists($fpath)!==false && time()-filemtime($fpath)<3600*24*cache_update_time)
}
}
}

function adclass($labelname){
global $siteskin;
if (!$siteskin){$siteskin=siteskin;}
$fpath=zzcmsroot."/template/".$siteskin."/label/adclass/".$labelname.".txt";
if (file_exists($fpath)==true){
if (filesize($fpath)<10){ showmsg(zzcmsroot."template/".$siteskin."/label/adclass/".$labelname.".txt 内容为空");}//utf-8有文件头，空文件大小为3字节
$fcontent=file_get_contents($fpath);
$f=explode("|||",$fcontent) ;
$b = $f[1];$numbers = $f[2];$column = $f[3];$start = $f[4];$mids = $f[5];$ends = $f[6];
$sql ="select * from zzcms_adclass where  parentid='".$b."' order by xuhao limit 0,$numbers ";
$rs=query($sql);
$str="";$i = 1;$mids2='';
$mylabels=get_label($mids);//用正则可获取一个或多个标签,返回值是数组
while($r=mysqli_fetch_array($rs)){
if ($cid<>""){//父类不为空，调出的classid为小类
$mids2=$mids2.str_replace("{#classname}",$r["classname"],$mids);
foreach($mylabels as $mylabel){//嵌套单个或多个
$mylabel=str_replace("adshow.","",$mylabel);//正则中通一从{@开始截取的，这里要替换
$mids2=str_replace("{@adshow.".$mylabel ."}",ad($mylabel,$r["classid"]),$mids2);
}
}
	if ($column <> "" && $column > 0){
		if ($i % $column == 0) {$mids2 = $mids2 . "</tr>";}
	}
$i = $i + 1;
}
$str = $start .$mids2. $ends;
if ($mids2==''){$str='暂无信息';}
return $str;
}
}

function ad($labelname,$bid,$sid){
global $siteskin,$cid,$province,$city;//取外部值，供演示模板用,$province参数为拼音;仅在aera/show页中调用外部值
$province=province_zm2hz($province);
$city=city_zm2hz($city);
if (!$siteskin){$siteskin=siteskin;}
$fpath=zzcmsroot."/template/".$siteskin."/label/ad/".$labelname.".txt";
if (file_exists($fpath)==true){
if (filesize($fpath)<10){ showmsg(zzcmsroot."template/".$siteskin."/label/ad/".$labelname.".txt 内容为空");}//utf-8有文件头，空文件大小为3字节
$fcontent=file_get_contents($fpath);
$f=explode("|||",$fcontent) ;
$title=$f[0];$bigclassid=$f[1];$smallclassid=$f[2];$numbers = $f[3];$column = $f[4];$start =$f[5];$mids = $f[6];$ends = $f[7];
if ($cid){//自动获取外部大类值的情况
	$sql="select classname from zzcms_zhaoshangclass where classid='".$cid."'";
	$rs=query($sql);
	$row=mysqli_fetch_array($rs);
	$classname='';	
	if ($row){$classname=$row["classname"];}
	if ($bigclassid=='首页'){
	$bid = '首页';//当大类为首页时在所有内页中都显示
	}else{
	$bid = $classname;//大类用外部的值，把类别字母转换为类别名称
	}
	$sid = $smallclassid;//小类用指定的类别名，用户招商分类页，自动根据大类参数调用相应大类下的小类，小类名要相同
}elseif ($bid <> "" && $sid<>""){//套在adclass里面使用时
	$bid = $bid;$sid = $sid;
}else{
	$bid = $bigclassid;$sid = $smallclassid;
}
if ($city<>''){
$sql= "select * from zzcms_ad where bigclassname='".$bid."' and smallclassname='".$sid."' and city='".$city."' ";//只用一个参数，直接显示城市广告
}elseif ($province<>''){
$sql= "select * from zzcms_ad where bigclassname='".$bid."' and smallclassname='".$sid."' and province='".$province."' ";
}else{
$sql= "select * from zzcms_ad where bigclassname='".$bid."' and smallclassname='".$sid."' ";
}

if (isshowad_when_timeend=="No"){
$sql=$sql. "and endtime>= '".date('Y-m-d H:i:s')."' ";
}
$sql=$sql. "order by xuhao asc,id asc";
//echo $sql;
$rs=query($sql);
$str="";$mids2='';$n = 1;
while($r=mysqli_fetch_array($rs)){
$mids2 =$mids2 .$mids;
$mids2 =str_replace("{#link}", addhttp($r["link"]),str_replace("{#n}", addzero($n,2),str_replace("{#title}",$r["title"],$mids2)));
	$mids2 =str_replace("{#titlecolor}",$r["titlecolor"],$mids2);
	if (($n + 4) % 8 == 0 || ($n + 5) % 8 == 0 ||  ($n + 6) % 8 == 0 ||  ($n + 7) % 8 == 0){
	$mids2 =str_replace("{#style}","textad1",$mids2);
	}else{
	$mids2 =str_replace("{#style}","textad2",$mids2);
	}
	if (strpos(strtolower($labelname),"flash")!==false){//没有加新参数，命名时焦点广告名里要有flash
	//焦点flash不支持远程，只能用相对路经，这样才能同时在www.或是没有www.两种域名下显示
	$mids2 = str_replace("{#img}",$r["img"],$mids2);
	}else{
	$mids2 = str_replace("{#img}",siteurl.$r["img"],$mids2);//当展厅开二级域名的情况下，前面必须得加网址
	}
	if ( $column <> "" && $column >0) {
		if ( $n % $column == 0) {$mids2 = $mids2 . "</tr>";}
	}
	$mids2 = $mids2 . "\r\n";
$n = $n + 1;
}
$str = $start.$mids2.$ends;
if ($mids2==''){$str='暂无信息';}
return $str;
}
}
?>