<?php
if ($action=="pass"){
if(!empty($_POST['id'])){
    for($i=0; $i<count($_POST['id']);$i++){
    $id=$_POST['id'][$i];
	checkid($id);
	$sql="select classid,passed from  `".$table."` where id ='$id'";
	$rs = query($sql); 
	$row = fetch_array($rs);
	$newtable=$table.$row['classid'];
	if ($row['passed']=='0'){
	query("update `".$table."` set passed=1 where id ='$id'");
	query("update `".$newtable."` set passed=1 where zid ='$id'") or die(tsmsg($lang['fail']));
    }else{
	query("update `".$table."` set passed=0 where id ='$id'");
	query("update `".$newtable."` set passed=0 where zid ='$id'") or die(tsmsg($lang['fail']));
	}
	}	
}else{
echo "<script lanage='javascript'>alert('操作失败！至少要选中一条信息。');history.back()</script>";
}
echo "<script>location.href='?shenhe=no&b=".$b."&keyword=".$keyword."&page=".$page."'</script>";
}
?>