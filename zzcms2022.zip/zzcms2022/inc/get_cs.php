<?php
$page_size=pagesize_qt;
$c=isset($_GET["c"])?$_GET["c"]:'';
if( isset($_GET["page"]) && $_GET["page"]!="") {$page=$_GET['page'];}else{$page=1;}
checkid($page);

$classname='';$cid=0;$classtitle='';$classkeyword='';$classdescription='';
if ($c<>''){
$sql="select * from `$table_class` where classzm='".$c."'";
$rs=query($sql);
$row=fetch_array($rs);
$classname=$row["classname"];
$cid=$row["classid"];

$classtitle=$row["title"];
$classkeyword=$row["keyword"];
$classdescription=$row["description"];
$skin=explode("|",$row["skin"]);
$skin=@$skin[1];//列表页是第二个参数
}
?>