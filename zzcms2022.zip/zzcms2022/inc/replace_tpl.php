<?php
//$strout=str_replace("{#sj}",showsj(4,""),$strout) ;
$strout=str_replace("{#siteskin}",$siteskin,$strout) ;
$strout=str_replace("{#siteurl}",siteurl,$strout) ;
$strout=str_replace("{#sitename}",sitename,$strout) ;
$strout=str_replace("{#station}",getstation($table_class,$cid,@$title,"",$channel),$strout) ;
$strout=str_replace("{#class}",showclass($table_class,$channel,$cid,$cid,999,0),$strout) ;
$strout=str_replace("{#class_search}",showclass($table_class,$channel,$cid,$cid,999,1),$strout) ;
$strout=str_replace("{#pagetitle}",$pagetitle,$strout);
$strout=str_replace("{#pagekeywords}",$pagekeywords,$strout);
$strout=str_replace("{#pagedescription}",$pagedescription,$strout);
$strout=str_replace("{#sitebottom}",sitebottom(),$strout);
$strout=str_replace("{#sitetop}",sitetop(),$strout);
if (strpos($strout,"{@")!==false || strpos($strout,"{#")!==false) $strout=showlabel($strout);//先查一下，如是要没有的就不用再调用showlabel;
echo  $strout;
?>