<?php
//主要针对在任何文件后加?%3Cscript%3E，即使文件中没有参数
if (strpos(strtolower($_SERVER['REQUEST_URI']),'script')!==false || strpos($_SERVER['REQUEST_URI'],'%26%2399%26%')!==false|| strpos(strtolower($_SERVER['REQUEST_URI']),'%2F%3Cobject')!==false){
die ("无效参数");//注意这里不能用js提示
}
//no_refresh();//防刷新
if($_COOKIE){
	$_COOKIE =addfxg($_COOKIE);	
}

if($_REQUEST){
	$_POST =addfxg($_POST);
	$_GET =addfxg($_GET);
	@extract($_POST);//直接转成同名变量
	@extract($_GET);//直接转成同名变量	
}
	
if (checksqlin=="Yes") {
$r_url=strtolower($_SERVER["REQUEST_URI"]);
if (strpos($r_url,"siteconfig.php")==0 && strpos($r_url,"label")==0 && strpos($r_url,"template.php")==0) {
foreach ($_GET as $get_key=>$get_var){ stopsqlin($get_var);} /* 过滤所有GET过来的变量 */      
foreach ($_POST as $post_key=>$post_var){ stopsqlin($post_var);	}/* 过滤所有POST过来的变量 */
foreach ($_COOKIE as $cookie_key=>$cookie_var){ stopsqlin($cookie_var);	}/* 过滤所有COOKIE过来的变量 */
foreach ($_REQUEST as $request_key=>$request_var){ stopsqlin($request_var);	}/* 过滤所有request过来的变量 */
}
}
?>