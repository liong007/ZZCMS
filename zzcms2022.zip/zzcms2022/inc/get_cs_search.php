<?php
$page_size=pagesize_qt;
$c=isset($_GET["c"])?$_GET["c"]:'';
if( isset($_GET["page"]) && $_GET["page"]!="") {$page=$_GET['page'];}else{$page=1;}
checkid($page);

$yiju=isset($_GET['yiju'])?$_GET['yiju']:'Pname';
if (isset($_GET['keyword'])){
$keywordNew=$_GET['keyword'];
setcookie("keyword",$keywordNew,time()+3600*24);
setcookie("c","xxx",1);
setcookie("province","xxx",1);
setcookie("city","xxx",1);
setcookie("xiancheng","xxx",1);
setcookie("p_id","xxx",1);
setcookie("c_id","xxx",1);
setcookie("sj","xxx",1);
//echo "<script>location.href='search.php'<//script>";
$keyword=$keywordNew;
}else{
$keyword=isset($_COOKIE['keyword'])?$_COOKIE['keyword']:'';
}

if (isset($_GET['c'])){
$cNew=$_GET['c'];
setcookie("c",$cNew,time()+3600*24,$channel);
echo "<script>location.href='search.php'</script>";
$c=$cNew;
}else{
$c=isset($_COOKIE['c'])?$_COOKIE['c']:'';
}

if (@$province<>"" && @$province<>'请选择省份'){
$provinceNew=$province;
setcookie("province",$provinceNew,time()+3600*24);
$province=$provinceNew;
}else{
$province=isset($_COOKIE['province'])?$_COOKIE['province']:'';
}

if (isset($_GET['p_id'])){
$p_idNew=$_GET['p_id'];
setcookie("p_id",$p_idNew,time()+3600*24);
$p_id=$p_idNew;
}else{
$p_id=isset($_COOKIE['p_id'])?$_COOKIE['p_id']:'';
}

if (@$city<>"" && @$city<>'请选择城区'){
$cityNew=$city;
setcookie("city",$cityNew,time()+3600*24);
$city=$cityNew;
}else{
$city=isset($_COOKIE['city'])?$_COOKIE['city']:'';
}

if (isset($_GET['c_id'])){
$c_idNew=$_GET['c_id'];
setcookie("c_id",$c_idNew,time()+3600*24);
$c_id=$c_idNew;
}else{
$c_id=isset($_COOKIE['c_id'])?$_COOKIE['c_id']:'';
}

if (@$xiancheng<>"" && @$xiancheng<>'请选择县城'){
$xianchengNew=$xiancheng;
setcookie("xiancheng",$xianchengNew,time()+3600*24);
$xiancheng=$xianchengNew;
}else{
$xiancheng=isset($_COOKIE['xiancheng'])?$_COOKIE['xiancheng']:'';
}

if (isset($_GET['sj'])){
$sjNew=$_GET['sj'];
checkid($sjNew,1);
setcookie("sj",$sjNew,time()+3600*24);
$sj=$sjNew;
}else{
$sj=isset($_COOKIE['sj'])?$_COOKIE['sj']:0;
}

if (isset($_GET['delc'])){
setcookie("c","xxx",1);
echo "<script>location.href='search.php'</script>";
}

if (isset($_GET['delprovince'])){
setcookie("province","xxx",1);
setcookie("city","xxx",1);
setcookie("xiancheng","xxx",1);
setcookie("p_id","xxx",1);
setcookie("c_id","xxx",1);
echo "<script>location.href='search.php'</script>";
}
if (isset($_GET['delcity'])){
setcookie("city","xxx",1);
setcookie("c_id","xxx",1);
setcookie("xiancheng","xxx",1);
echo "<script>location.href='search.php'</script>";
}
if (isset($_GET['delxiancheng'])){
setcookie("xiancheng","xxx",1);
echo "<script>location.href='search.php'</script>";
}
if (isset($_GET['delsj'])){
setcookie("sj","xxx",1);
echo "<script>location.href='search.php'</script>";
}

$classname='';$cid=0;$classtitle='';$classkeyword='';$classdescription='';
if ($c<>''){
$sql="select * from `$table_class` where classzm='".$c."'";
$rs=query($sql);
$row=fetch_array($rs);
$classname=$row["classname"];
$cid=$row["classid"];

$classtitle=$row["title"];
$classkeyword=$row["keyword"];
$classdescription=$row["description"];
$skin=explode("|",$row["skin"]);
$skin=@$skin[1];//列表页是第二个参数
}

if ($c<>'' || $province<>"" || $city<>"" || $xiancheng<>"" || $sj<>0) {
		$selected="<tr>";
		$selected=$selected."<td align='right'>已选条件：</td>";
		$selected=$selected."<td class='a_selected'>";
			if ($c<>'') {
			$selected=$selected."<a href='?delc=Yes' >".$classname."×</a>&nbsp;";
			}
			if ($province<>""){
			$selected=$selected."<a href='?delprovince=Yes'  >".$province."×</a>&nbsp;";
			}
			if ($city<>""){
			$selected=$selected."<a href='?delcity=Yes'>".$city."×</a>&nbsp;";
			}
			if ($xiancheng<>""){
			$selected=$selected."<a href='?delxiancheng=Yes' title='删除已选'>".$xiancheng."×</a>&nbsp;";
			}
			if ($sj<>0) {
			$selected=$selected."<a href='?delsj=Yes' >".$sj."天内的×</a>&nbsp;";
			}
		$selected=$selected."</td>";
		$selected=$selected."</tr>";
}else{
		$selected="";
}
?>