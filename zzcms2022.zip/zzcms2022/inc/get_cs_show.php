<?php
if (isset($_GET["id"])){
$cpid=trim($_GET["id"]);
checkid($id);
}else{
$id=0;
}
?>