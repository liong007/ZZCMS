<?php
$list=strbetween($strout,"{loop}","{/loop}");
$t_num=strbetween($list,"{#title:","}");
$c_num=strbetween($list,"{#content:","}");

if ($c<>""){
$tables=$table.$cid;//这里有命名不要与showclass中的重名
	if(mysqli_num_rows(query("SHOW TABLES LIKE '".$tables."'"))<>1) {
	addtable($table,$cid);//加表
	}
}else{
$tables=$table;
}

$sql="select count(*) as total from `$tables` where passed<>0 ";
$sql2='';
//if ($c<>''){$sql2=$sql2. "and classid='".$cid."' ";}

$rs =query($sql.$sql2); 
$row = mysqli_fetch_array($rs);
$totlenum = $row['total'];
$offset=($page-1)*$page_size;
$totlepage=ceil($totlenum/$page_size);

$sql="select * from `$tables` where passed<>0 ";	
$sql=$sql.$sql2;
$sql=$sql." order by id desc limit $offset,$page_size";
$rs = query($sql); 
if(!$totlenum){
$strout=str_replace("{#fenyei}","",$strout) ;
$strout=str_replace("{loop}".$list."{/loop}","暂无信息",$strout) ;
}else{

$list2='';$i=0;
while($row= mysqli_fetch_array($rs)){
$sx="";
if (@$row["elite"]>0) {$sx=$sx."<font color=red>[置顶]</font>&nbsp;";}
if (time()-strtotime($row["sendtime"])<3600*24){$sx=$sx."[最新]&nbsp;" ;}
if ($row["hit"]>=1000) {$sx=$sx."[热门]&nbsp;";	}
if (@$row["img"]<>'') {$sx=$sx."[图]&nbsp;";	}
$list2 = $list2.$list ;
$list2 =str_replace("{#title:".$t_num."}",cutstr(@$row["title"],$t_num),$list2) ;
$list2 =str_replace("{#title}" ,$row["title"],$list2) ;

if ($c<>""){
$list2 =str_replace("{#url}",getpageurl($channel,@$row['zid']),$list2) ;
}else{
$list2 =str_replace("{#url}",getpageurl($channel,$row['id']),$list2) ;
}
//zh
$list2 =str_replace("{#shuxing}" ,$sx,$list2) ;
$list2 =str_replace("{#timestart}" ,date("Y-m-d",strtotime(@$row["timestart"])),$list2) ;
$list2 =str_replace("{#timeend}" ,date("Y-m-d",strtotime(@$row["timeend"])),$list2) ;
$list2 =str_replace("{#address}" ,@$row["province"],$list2) ;
//job
$list2 =str_replace("{#province}",@$row['province'],$list2) ;
$list2 =str_replace("{#city}",cutstr(@$row["city"],8),$list2) ;
$list2 =str_replace("{#comane}",@$row["comane"],$list2) ;
$list2 =str_replace("{#companyurl}",getpageurlzt(@$row['editor'],@$row['userid']),$list2) ;
$list2 =str_replace("{#sendtime}",date("Y-m-d",strtotime(@$row["sendtime"])),$list2) ;
//baojia
if ($i % 2==0) {
$list2=str_replace("{changebgcolor}" ,"class=bgcolor1",$list2) ;
}else{
$list2=str_replace("{changebgcolor}" ,"class=bgcolor2",$list2) ;
}

$list2 = str_replace("{#name}" ,@$row["truename"],$list2) ;
$list2 = str_replace("{#xiancheng}" ,@$row["xiancheng"],$list2) ;
$list2 = str_replace("{#tel}" ,@$row["tel"],$list2) ;
$list2 = str_replace("{#price}" ,@$row["price"],$list2) ;
$list2 = str_replace("{#danwei}" ,@$row["danwei"],$list2) ;

//ask 
$list2 =str_replace("{#id}",$row["id"],$list2) ;
$list2 =str_replace("{#imgbig}",@$row["img"],$list2) ;
$list2 =str_replace("{#img}",getsmallimg(@$row["img"]),$list2) ;
$list2 =str_replace("{#content}",@$row["content"],$list2) ;
$list2 =str_replace("{#jifen}" ,@$row["jifen"],$list2) ;

$rs_answer_num = query("select count(*) as total from zzcms_answer where about='".$row["id"]."' "); 
$row_answer_num = mysqli_fetch_array($rs_answer_num);
$answer_num = @$row_answer_num['total'];
$list2=str_replace("{#answer_num}", $answer_num,$list2);

if (@$row["typeid"]==1){
$zhuangtai_biaozhi="<img src='/image/dui2.png' title='已解决'>";
}elseif (@$row["typeid"]==0){
$zhuangtai_biaozhi="<img src='/image/wenhao.png' title='待解决'>";
}
$list2=str_replace("{#zhuangtai}", $zhuangtai_biaozhi,$list2);
//special 以上可以做到全部替换
//zx
$list2 =str_replace("{#content}",stripfxg(@$row["content"],true),$list2) ;
$list2 =str_replace("{#content:".$c_num."}",cutstr(nohtml(stripfxg(@$row["content"],true)),$c_num),$list2) ;
$list2 =str_replace("{#hit}",$row["hit"],$list2) ;
//pp 以上可以做到全部替换

$i=$i+1;
}
$strout=str_replace("{loop}".$list."{/loop}",$list2,$strout) ;
$strout=str_replace("{#fenyei}",showpage2($channel),$strout) ;
}
?>