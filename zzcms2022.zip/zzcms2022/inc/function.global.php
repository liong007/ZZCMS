<?php
function cutfgx($str,$tag){
	for($i=0; $i<substr_count($str,$tag);$i++){
		if (substr($str,-1,1)==$tag){//去最后一个|
		$str=substr($str,0,strlen($str)-1);
		}
		if (substr($str,0,1)==$tag){//去第一个|
		$str=substr($str,1);
		}
	}
return $str;
}
		
function checkid($id,$classid=0,$msg='无'){
if ($id<>''){
	if (is_numeric($id)==false){showmsg('参数 '.$id.' 有误！');}
	if ($classid==0){//查大小类ID时这里设为1
		if ($id<1){showmsg('参数 '.$id.'有误！\r\r提示：'.$msg);}//翻页中有用,这个提示msg在其它地方有用
	}
}
}

function checkstr($str,$kind,$msg='',$back_url='back'){
if ($str<>''){
switch ($kind){
case "num";
	if (is_numeric($str)==false){showmsg($msg.'必须为数字');}
break;
case "tel";
	if(!preg_match("/1[34578]{1}\d{9}$/",$str) && !preg_match('/^400(\d{3,4}){2}$/',$str) && !preg_match('/^400(-\d{3,4}){2}$/',$str) && !preg_match('/^(010|02\d{1}|0[3-9]\d{2})-\d{7,9}(-\d+)?$/',$str)){
	//分别是手机，400电话(加-和不加两种情况都可以)，和普通电话
	showmsg('电话号码不正确！',$back_url);
	}
break;
case "email";
	if(! preg_match("/^[a-zA-Z0-9_.]+@([a-zA-Z0-9_]+.)+[a-zA-Z]{2,3}$/",$str)) {
	showmsg("Email格式不正确",$back_url);
	}
break;
case "hanzi";
	if (!preg_match("/([\x81-\xfe][\x40-\xfe])/",$str)) {//是否含有汉字
	showmsg($msg."必须有汉字",$back_url);
	}
break;
case "datetime";
	if (date('Y-m-d',strtotime($str))!=$str){
	showmsg($msg."必须为时间格式",$back_url);
	}
break;
case "quanhanzi";
	if(!preg_match("/^[\x7f-\xff]+$/",$str)){
	showmsg($msg."只能用中文",$back_url);
	}
break;	
case "ip";
	if(!preg_match("/^[\d]{2,3}\.[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}$/", $str)){
	showmsg($msg."ip格式不对",$back_url);
	}
break;
case "username";
	if(! preg_match("/^[a-zA-Z0-9_]{4,15}$/",$str)){//ereg()PHP5.3以后的版本不再支持
	showmsg($msg."用户名格式不对",$back_url);
	}
break;
case "upload";//用于引用网络图片地址和视频地址的上传页
	if (strpos("gif|jpg|peg|png|bmp|flv|swf",strtolower(substr($str,-3)))===false){
	showmsg($msg.$str."不支持的上传文件格式。支持的文件格式为（gif|jpg|png|bmp|flv|swf）",$back_url);
	}
	if (substr($str,0,4)<>"http" && $str<>"/image/nopic.gif"){
		if (strpos($str,'/uploadfiles')===false){
		showmsg($msg.$str."不支持的上传文件地址",$back_url);
		}
	}
break;	
}
}
}

function nohtml($str){
$str=trim($str);//清除字符串两边的空格
$str=strip_tags($str,"");//利用php自带的函数清除html格式
$str=str_replace("&nbsp;","",$str);//空白符
$str=str_replace("　","",$str);//table 所产生的空格
$str=preg_replace("/\t/","",$str);//使用正则表达式匹配需要替换的内容，如空格和换行，并将替换为空
$str=preg_replace("/\r\n/","",$str);
$str=preg_replace("/\r/","",$str);
$str=preg_replace("/\n/","",$str);
$str=preg_replace("/ /","",$str);//匹配html中的空格
return trim($str);//返回字符串
}

function getip(){ 
if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown")) {
$ip = getenv("HTTP_CLIENT_IP");
}else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown")) {
$ip = getenv("HTTP_X_FORWARDED_FOR"); 
}else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown")) {
$ip = getenv("REMOTE_ADDR"); 
}else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown")){ 
$ip = $_SERVER['REMOTE_ADDR']; 
}else{
$ip = "unknown";
}
if (check_isip($ip)==false){
$ip = "unknown";
}
return($ip); 
} 

function addzero($str,$longs=2){
if (strlen($str)<$longs){
	$result=0;
	for ($i=1;$i<$longs-strlen($str);$i++){
	$result=$result."0";
	}
	$str= $result.$str;
}else{
$str= $str;
}
return $str;
}

function addhttp($url){
if ($url<>"" && substr($url,0,4)<>"http" && substr($url,0,3)=="www"){return "http://".$url;}else{return $url;}
}

function checkyzm($yzm){
if($yzm!=$_SESSION["yzm_math"]){showmsg('验证问题答案错误！','back');}
}

function getimgincontent($content,$num=1){
preg_match_all("/<[img].*?src=[\'|\"](.*?(?:[\.gif|\.jpg|\.png|\.bmp]))[\'|\"].*?[\/]?>/i",$content,$match);
switch ($num){
case 1;return @$match[1][0];break;//只取第一个
case 2;return @$match[1];break;//取出所有，返回的是一个数组
}
}

function getimg2($img) { //从getimgincontent正则后，做二次提取
if ($img<>''){
//$img=strtolower($img);//转小写后，导致与内容中的不对应，无法替换为本地路径的图片
if (strpos($img,'jpg')!==false){
$format='jpg';
}elseif (strpos($img,'gif')!==false){
$format='gif';
}elseif (strpos($img,'png')!==false){
$format='png';
}elseif (strpos($img,'bmp')!==false){
$format='bmp';
}
$end=strpos($img,$format)+3;
return substr($img,0,$end);
}
}

function cutstr($tempstr,$tempwid){
if ($tempwid==''){$tempwid=9;}
if (is_numeric($tempwid)==false){$tempwid=9;}
if (strlen($tempstr)/3>$tempwid){
return mb_substr($tempstr,0,$tempwid,'utf8').".";
}else{
return $tempstr;
}
}

function isaddsiteurl($str){
if (strpos($str,'http')!==false) {//有http时用的是网络图片前面就不加siteurl了
return $str;
}else{
return siteurl.$str;
}
}

function strbetween($str,$start,$end,$startadd=0) { 
$a= strpos($str,$start)+strlen($start)+$startadd;//在起始标识$start所在位后追加数字，如取src="后的字符时，双引号无法直接表示，所以加这个startadd可以解决这种问题
if (strpos($str,$start)!==false){ 
$b= strpos($str,$end,$a);//必须定起始位置
return substr($str,$a,$b-$a); 
}
}

function get_label($str) {
preg_match_all('/(?<={@).*(?=})/',$str,$match);
return $match[0];//返回数组，方便外部调用时灵活处理
}

function getfirstchar($s0){ //获取单个汉字拼音首字母。注意:此处不要纠结。汉字拼音是没有以U和V开头的
    $fchar = ord($s0[0]);
    if($fchar >= ord("A") and $fchar <= ord("z") )return strtoupper($s0[0]);
    $s1 = @iconv("UTF-8","gb2312", $s0);
    $s2 = iconv("gb2312","UTF-8", $s1);
    if($s2 == $s0){$s = $s1;}else{$s = $s0;}
    $asc = ord($s[0]) * 256 + ord($s[1]) - 65536;
    if($asc >= -20319 and $asc <= -20284) return "a";
    if($asc >= -20283 and $asc <= -19776) return "b";
    if($asc >= -19775 and $asc <= -19219) return "c";
    if($asc >= -19218 and $asc <= -18711) return "d";
    if($asc >= -18710 and $asc <= -18527) return "e";
    if($asc >= -18526 and $asc <= -18240) return "f";
    if($asc >= -18239 and $asc <= -17923) return "g";
    if($asc >= -17922 and $asc <= -17418) return "h";
    if($asc >= -17922 and $asc <= -17418) return "i";
    if($asc >= -17417 and $asc <= -16475) return "j";
    if($asc >= -16474 and $asc <= -16213) return "k";
    if($asc >= -16212 and $asc <= -15641) return "l";
    if($asc >= -15640 and $asc <= -15166) return "m";
    if($asc >= -15165 and $asc <= -14923) return "n";
    if($asc >= -14922 and $asc <= -14915) return "o";
    if($asc >= -14914 and $asc <= -14631) return "p";
    if($asc >= -14630 and $asc <= -14150) return "q";
    if($asc >= -14149 and $asc <= -14091) return "r";
    if($asc >= -14090 and $asc <= -13319) return "s";
    if($asc >= -13318 and $asc <= -12839) return "t";
    if($asc >= -12838 and $asc <= -12557) return "w";
    if($asc >= -12556 and $asc <= -11848) return "x";
    if($asc >= -11847 and $asc <= -11056) return "y";
    if($asc >= -11055 and $asc <= -10247) return "z";
    return NULL;
    //return $s0;
}	
	
function getfirstchar_all($str){  //获取整条字符串所有汉字拼音首字母
$str=str_replace("—","",$str);
$str=str_replace("·","",$str);
    $ret = "";
    @$s1 = iconv("UTF-8","gb2312", $str);//有出错的比如 囍
    $s2 = iconv("gb2312","UTF-8", $s1);
    if($s2 == $str){$str = $s1;}
    for($i = 0; $i < strlen($str); $i++){
        $s1 = substr($str,$i,1);
        $p = ord($s1);
        if($p > 160){
            $s2 = substr($str,$i++);
            $ret .= getfirstchar($s2);
        }else{
            $ret .= $s1;
        }
    }
    return $ret;
}	
//取得拼音
function pinyin($_String, $_Code='UTF8'){ //GBK页面可改为gb2312，其他随意填写为UTF8
        $_DataKey = "a|ai|an|ang|ao|ba|bai|ban|bang|bao|bei|ben|beng|bi|bian|biao|bie|bin|bing|bo|bu|ca|cai|can|cang|cao|ce|ceng|cha". 
                        "|chai|chan|chang|chao|che|chen|cheng|chi|chong|chou|chu|chuai|chuan|chuang|chui|chun|chuo|ci|cong|cou|cu|". 
                        "cuan|cui|cun|cuo|da|dai|dan|dang|dao|de|deng|di|dian|diao|die|ding|diu|dong|dou|du|duan|dui|dun|duo|e|en|er". 
                        "|fa|fan|fang|fei|fen|feng|fo|fou|fu|ga|gai|gan|gang|gao|ge|gei|gen|geng|gong|gou|gu|gua|guai|guan|guang|gui". 
                        "|gun|guo|ha|hai|han|hang|hao|he|hei|hen|heng|hong|hou|hu|hua|huai|huan|huang|hui|hun|huo|ji|jia|jian|jiang". 
                        "|jiao|jie|jin|jing|jiong|jiu|ju|juan|jue|jun|ka|kai|kan|kang|kao|ke|ken|keng|kong|kou|ku|kua|kuai|kuan|kuang". 
                        "|kui|kun|kuo|la|lai|lan|lang|lao|le|lei|leng|li|lia|lian|liang|liao|lie|lin|ling|liu|long|lou|lu|lv|luan|lue". 
                        "|lun|luo|ma|mai|man|mang|mao|me|mei|men|meng|mi|mian|miao|mie|min|ming|miu|mo|mou|mu|na|nai|nan|nang|nao|ne". 
                        "|nei|nen|neng|ni|nian|niang|niao|nie|nin|ning|niu|nong|nu|nv|nuan|nue|nuo|o|ou|pa|pai|pan|pang|pao|pei|pen". 
                        "|peng|pi|pian|piao|pie|pin|ping|po|pu|qi|qia|qian|qiang|qiao|qie|qin|qing|qiong|qiu|qu|quan|que|qun|ran|rang". 
                        "|rao|re|ren|reng|ri|rong|rou|ru|ruan|rui|run|ruo|sa|sai|san|sang|sao|se|sen|seng|sha|shai|shan|shang|shao|". 
                        "she|shen|sheng|shi|shou|shu|shua|shuai|shuan|shuang|shui|shun|shuo|si|song|sou|su|suan|sui|sun|suo|ta|tai|". 
                        "tan|tang|tao|te|teng|ti|tian|tiao|tie|ting|tong|tou|tu|tuan|tui|tun|tuo|wa|wai|wan|wang|wei|wen|weng|wo|wu". 
                        "|xi|xia|xian|xiang|xiao|xie|xin|xing|xiong|xiu|xu|xuan|xue|xun|ya|yan|yang|yao|ye|yi|yin|ying|yo|yong|you". 
                        "|yu|yuan|yue|yun|za|zai|zan|zang|zao|ze|zei|zen|zeng|zha|zhai|zhan|zhang|zhao|zhe|zhen|zheng|zhi|zhong|". 
                        "zhou|zhu|zhua|zhuai|zhuan|zhuang|zhui|zhun|zhuo|zi|zong|zou|zu|zuan|zui|zun|zuo"; 
        $_DataValue = "-20319|-20317|-20304|-20295|-20292|-20283|-20265|-20257|-20242|-20230|-20051|-20036|-20032|-20026|-20002|-19990". 
                        "|-19986|-19982|-19976|-19805|-19784|-19775|-19774|-19763|-19756|-19751|-19746|-19741|-19739|-19728|-19725". 
                        "|-19715|-19540|-19531|-19525|-19515|-19500|-19484|-19479|-19467|-19289|-19288|-19281|-19275|-19270|-19263". 
                        "|-19261|-19249|-19243|-19242|-19238|-19235|-19227|-19224|-19218|-19212|-19038|-19023|-19018|-19006|-19003". 
                        "|-18996|-18977|-18961|-18952|-18783|-18774|-18773|-18763|-18756|-18741|-18735|-18731|-18722|-18710|-18697". 
                        "|-18696|-18526|-18518|-18501|-18490|-18478|-18463|-18448|-18447|-18446|-18239|-18237|-18231|-18220|-18211". 
                        "|-18201|-18184|-18183|-18181|-18012|-17997|-17988|-17970|-17964|-17961|-17950|-17947|-17931|-17928|-17922". 
                        "|-17759|-17752|-17733|-17730|-17721|-17703|-17701|-17697|-17692|-17683|-17676|-17496|-17487|-17482|-17468". 
                        "|-17454|-17433|-17427|-17417|-17202|-17185|-16983|-16970|-16942|-16915|-16733|-16708|-16706|-16689|-16664". 
                        "|-16657|-16647|-16474|-16470|-16465|-16459|-16452|-16448|-16433|-16429|-16427|-16423|-16419|-16412|-16407". 
                        "|-16403|-16401|-16393|-16220|-16216|-16212|-16205|-16202|-16187|-16180|-16171|-16169|-16158|-16155|-15959". 
                        "|-15958|-15944|-15933|-15920|-15915|-15903|-15889|-15878|-15707|-15701|-15681|-15667|-15661|-15659|-15652". 
                        "|-15640|-15631|-15625|-15454|-15448|-15436|-15435|-15419|-15416|-15408|-15394|-15385|-15377|-15375|-15369". 
                        "|-15363|-15362|-15183|-15180|-15165|-15158|-15153|-15150|-15149|-15144|-15143|-15141|-15140|-15139|-15128". 
                        "|-15121|-15119|-15117|-15110|-15109|-14941|-14937|-14933|-14930|-14929|-14928|-14926|-14922|-14921|-14914". 
                        "|-14908|-14902|-14894|-14889|-14882|-14873|-14871|-14857|-14678|-14674|-14670|-14668|-14663|-14654|-14645". 
                        "|-14630|-14594|-14429|-14407|-14399|-14384|-14379|-14368|-14355|-14353|-14345|-14170|-14159|-14151|-14149". 
                        "|-14145|-14140|-14137|-14135|-14125|-14123|-14122|-14112|-14109|-14099|-14097|-14094|-14092|-14090|-14087". 
                        "|-14083|-13917|-13914|-13910|-13907|-13906|-13905|-13896|-13894|-13878|-13870|-13859|-13847|-13831|-13658". 
                        "|-13611|-13601|-13406|-13404|-13400|-13398|-13395|-13391|-13387|-13383|-13367|-13359|-13356|-13343|-13340". 
                        "|-13329|-13326|-13318|-13147|-13138|-13120|-13107|-13096|-13095|-13091|-13076|-13068|-13063|-13060|-12888". 
                        "|-12875|-12871|-12860|-12858|-12852|-12849|-12838|-12831|-12829|-12812|-12802|-12607|-12597|-12594|-12585". 
                        "|-12556|-12359|-12346|-12320|-12300|-12120|-12099|-12089|-12074|-12067|-12058|-12039|-11867|-11861|-11847". 
                        "|-11831|-11798|-11781|-11604|-11589|-11536|-11358|-11340|-11339|-11324|-11303|-11097|-11077|-11067|-11055". 
                        "|-11052|-11045|-11041|-11038|-11024|-11020|-11019|-11018|-11014|-10838|-10832|-10815|-10800|-10790|-10780". 
                        "|-10764|-10587|-10544|-10533|-10519|-10331|-10329|-10328|-10322|-10315|-10309|-10307|-10296|-10281|-10274". 
                        "|-10270|-10262|-10260|-10256|-10254"; 
        $_TDataKey   = explode('|', $_DataKey); 
        $_TDataValue = explode('|', $_DataValue);
        $_Data = array_combine($_TDataKey, $_TDataValue);
        arsort($_Data); 
        reset($_Data);
        if($_Code!= 'gb2312') $_String = _U2_Utf8_Gb($_String); 
        $_Res = ''; 
        for($i=0; $i<strlen($_String); $i++) { 
                $_P = ord(substr($_String, $i, 1)); 
                if($_P>160) { 
                        $_Q = ord(substr($_String, ++$i, 1)); $_P = $_P*256 + $_Q - 65536;
                } 
                $_Res .= _pinyin($_P, $_Data); 
        } 
        return preg_replace("/[^a-z0-9A-Z]*/", '', $_Res); 
} 
function _pinyin($_Num, $_Data){ 
        if($_Num>0 && $_Num<160 ){
                return chr($_Num);
        }elseif($_Num<-20319 || $_Num>-10247){
                return '';
        }else{ 
                foreach($_Data as $k=>$v){ if($v<=$_Num) break; } 
                return $k; 
        } 
}
function _U2_Utf8_Gb($_C){ 
        $_String = ''; 
        if($_C < 0x80){
                $_String .= $_C;
        }elseif($_C < 0x800) { 
                $_String .= chr(0xC0 | $_C>>6); 
                $_String .= chr(0x80 | $_C & 0x3F); 
        }elseif($_C < 0x10000){ 
                $_String .= chr(0xE0 | $_C>>12); 
                $_String .= chr(0x80 | $_C>>6 & 0x3F); 
                $_String .= chr(0x80 | $_C & 0x3F); 
        }elseif($_C < 0x200000) { 
                $_String .= chr(0xF0 | $_C>>18); 
                $_String .= chr(0x80 | $_C>>12 & 0x3F); 
                $_String .= chr(0x80 | $_C>>6 & 0x3F); 
                $_String .= chr(0x80 | $_C & 0x3F); 
        } 
        return iconv('UTF-8', 'GB2312', $_String); 
}

function removeBOM($str = ''){
if (substr($str,0,3) == pack("CCC",0xef,0xbb,0xbf)) {
$str = substr($str, 3);
}
return $str;
}

function formatnumber($number){
if($number >= 10000){return sprintf("%.2f", $number/10000)."万";}else{return $number;}
}

function formattime($time,$item=1){
if ($item==1){
return date("Y-m-d",strtotime($time));
}elseif ($item==2){
return $time;
}
}

function str_is_inarr($arrs,$str){
if(strpos($arrs,'#')!==false){//多个,循环值后对比,内容较多，要转换成数组，如果只用strpos字符判断，有重复的字符
$arr=explode("#",$arrs); //转换成数组
	if(in_array($str,$arr)){return 'yes';}else{return 'no';}
}else{//单个,直接对比
	if($arrs==$str){ return 'yes';}else{return 'no';}
}	
}

function check_isip($str){
  if(preg_match("/^[\d]{2,3}\.[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}$/", $str))
  return true;
  return false;
}

function stripfxg($string,$htmlspecialchars_decode=false,$nl2br=false) {//去反斜杠 
$string=stripslashes($string);//去反斜杠,不开get_magic_quotes_gpc 的情况下，在stopsqlin中都加上了，这里要去了
if ($htmlspecialchars_decode==true){
$string=htmlspecialchars_decode($string,ENT_QUOTES);//转html实体符号
}
if ($nl2br==true){
$string=nl2br($string);
}
return $string; 
}

function addfxg($string){
	if(!is_array($string)){
		if(@get_magic_quotes_gpc()){
	 	return htmlspecialchars(trim($string),ENT_QUOTES);
		}else{
		return addslashes(htmlspecialchars(trim($string),ENT_QUOTES));
		}
	 }
	foreach($string as $k => $v) $string[$k] = addfxg($v);
	return $string;
}
	
//过滤指定字符,
function stopsqlin($str){
remove_xss($str);
if(!is_array($str)) {//有数组数据会传过来比如代理留言中的省份$_POST['province'][$i]
	$str=strtolower($str);//否则过过滤不全
	$sql_injdata = "";
	$sql_injdata= $sql_injdata."|".stopwords;
	$sql_injdata=cutfgx($sql_injdata,"|");
	
    $sql_inj = explode("|",$sql_injdata);
	for ($i=0; $i< count($sql_inj);$i++){
		if (@strpos($str,$sql_inj[$i])!==false) {showmsg ("参数中含有非法字符 [".$sql_inj[$i]."] 系统不与处理");}
	}
}	
}

function no_refresh(){
$allow_sep = "1";
$url=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; 
if (isset($_COOKIE["post_sep"])){
	if(time() - $_COOKIE["post_sep"] < $allow_sep && $url==$_COOKIE["post_url"] ){
	die (tsmsg('请勿频繁刷新'));
	}else{
	setcookie("post_sep",time(),time()+60,"/");
	setcookie("post_url",$url,time()+60,"/");
	}
}else{
setcookie("post_sep",time(),time()+60,"/");
setcookie("post_url",$url,time()+60,"/");
}
}

function get_channel(){
$channel=strtolower($_SERVER['REQUEST_URI']);
$channel=substr($channel,1,strpos($channel,'/',1)-1);
if(strpos($channel,'index') !== false || strpos($channel,'?') !== false){ 
$channel='';//网站首页时设为空
}
return $channel;
}

function get_table(){
global $channel;
$table='zzcms_'.$channel;
$table_class='zzcms_'.$channel.'class';
if($channel=='zhaoshang'|| $channel=='daili'|| $channel=='pinpai'|| $channel=='baojia'|| $channel==''|| $channel=='area'|| $channel=='zhaoshangclass'){
$table_class='zzcms_zhaoshangclass';
}elseif($channel=='company'){
$table_class='zzcms_userclass';
$table='zzcms_user';
}
$arr_tab = array($table_class,$table);
return $arr_tab;
}

/**
 * xss过滤函数
 *
 * @param $string
 * @return string
 */
function remove_xss($string) { 
    $string = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]+/S', '', $string);

    $parm1 = array('javascript', 'vbscript', 'expression', 'applet', 'meta', 'xml', 'blink', 'link', 'script', 'embed', 'object', 'iframe', 'frame', 'frameset', 'ilayer', 'layer', 'bgsound', 'title', 'base');

    $parm2 = array('onabort', 'onactivate', 'onafterprint', 'onafterupdate', 'onbeforeactivate', 'onbeforecopy', 'onbeforecut', 'onbeforedeactivate', 'onbeforeeditfocus', 'onbeforepaste', 'onbeforeprint', 'onbeforeunload', 'onbeforeupdate', 'onblur', 'onbounce', 'oncellchange', 'onchange', 'onclick', 'oncontextmenu', 'oncontrolselect', 'oncopy', 'oncut', 'ondataavailable', 'ondatasetchanged', 'ondatasetcomplete', 'ondblclick', 'ondeactivate', 'ondrag', 'ondragend', 'ondragenter', 'ondragleave', 'ondragover', 'ondragstart', 'ondrop', 'onerror', 'onerrorupdate', 'onfilterchange', 'onfinish', 'onfocus', 'onfocusin', 'onfocusout', 'onhelp', 'onkeydown', 'onkeypress', 'onkeyup', 'onlayoutcomplete', 'onload', 'onlosecapture', 'onmousedown', 'onmouseenter', 'onmouseleave', 'onmousemove', 'onmouseout', 'onmouseover', 'onmouseup', 'onmousewheel', 'onmove', 'onmoveend', 'onmovestart', 'onpaste', 'onpropertychange', 'onreadystatechange', 'onreset', 'onresize', 'onresizeend', 'onresizestart', 'onrowenter', 'onrowexit', 'onrowsdelete', 'onrowsinserted', 'onscroll', 'onselect', 'onselectionchange', 'onselectstart', 'onstart', 'onstop', 'onsubmit', 'onunload', 'onpointerout');

    $parm = array_merge($parm1, $parm2); 

	for ($i = 0; $i < sizeof($parm); $i++) { 
		$pattern = '/'; 
		for ($j = 0; $j < strlen($parm[$i]); $j++) { 
			if ($j > 0) { 
				$pattern .= '('; 
				$pattern .= '(&#[x|X]0([9][a][b]);?)?'; 
				$pattern .= '|(&#0([9][10][13]);?)?'; 
				$pattern .= ')?'; 
			}
			$pattern .= $parm[$i][$j]; 
		}
		$pattern .= '/i';
		$string = preg_replace($pattern, ' ', $string); 
	}
	return $string;
}	


/**
 * 安全过滤函数
 *
 * @param $string
 * @return string
 */
function safe_replace($string) {
	$string = trim($string);
	$string = str_replace('%20','',$string);
	$string = str_replace('%27','',$string);
	$string = str_replace('%2527','',$string);
	$string = str_replace('*','',$string);
	$string = str_replace('"','',$string);
	$string = str_replace("'",'',$string);
	$string = str_replace(';','',$string);
	$string = str_replace('<','&lt;',$string);
	$string = str_replace('>','&gt;',$string);
	$string = str_replace("{",'',$string);
	$string = str_replace('}','',$string);
	$string = str_replace('\\','',$string);
	return $string;
}	
?>