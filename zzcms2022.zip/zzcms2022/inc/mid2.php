<?php
	if ($n==1){
	$mids2=str_replace("{#xuhao}", "<font class='xuhao1'>".addzero($n,2)."</font>",$mids2);
	}elseif($n==2){
	$mids2=str_replace("{#xuhao}", "<font class='xuhao2'>".addzero($n,2)."</font>",$mids2);
	}elseif($n==3){
	$mids2=str_replace("{#xuhao}", "<font class='xuhao3'>".addzero($n,2)."</font>",$mids2);
	}else{
	$mids2=str_replace("{#xuhao}", "<font class='xuhao'>".addzero($n,2)."</font>",$mids2);
	}
	if ( $column <> "" && $column > 0) {//所有模板中以<ul>为布局的默认值都设为了1,最好还是设为0 ,即默认0时不分列，这里改为>0,布局table时1就能生效了。
		if ( $n % $column == 0) {$mids2 = $mids2 . "</tr>";}
	}
	
	$mids2 =str_replace("{#hit}", @$r["hit"],$mids2);
	$mids2 =str_replace("{#n}", $n,$mids2);
	if ($classid<>''&& $classid<>0 && $classid <>'empty') {//展示页调用主表，分表只提供列表展示
	$mids2 =str_replace("{#id}", $r["zid"],$mids2);
	}else{
	$mids2 =str_replace("{#id}", $r["id"],$mids2);
	}
	$mids2 =str_replace("{#sendtime}",date("Y-m-d",strtotime(@$r['sendtime'])),$mids2);
	$mids2 =str_replace("{#imgbig}", @$r["img"],$mids2);
	$mids2 =str_replace("{#img}",getsmallimg(@$r["img"]),$mids2);
	
	//$mids2=str_replace("{#title}", $r["title"],$mids2);
	//$mids2=str_replace("{#title:".$tnum."}", cutstr($r["title"],$tnum),$mids2);
	$mids2=str_replace("{#title}", $title,$mids2);
	$mids2=str_replace("{#content}", $content,$mids2);
	$mids2=str_replace("{#title:".$tnum."}", cutstr($title,$tnum),$mids2);
	$mids2=str_replace("{#content:".$cnum."}", cutstr(nohtml($content),$cnum),$mids2);
	
	$mids2 =str_replace("{#prouse}", @$r["prouse"],$mids2);
	$mids2 =str_replace("{#prouse:".$cnum."}", cutstr(@$r["prouse"],$cnum),$mids2);
	$mids2 =str_replace("{#flv}", @$r["flv"],$mids2);
	$mids2 =str_replace("{#city}", @$r["city"],$mids2);
	$mids2 =str_replace("{#province}", @$r["province"],$mids2);
	$mids2 =str_replace("{#comane}", @$r["comane"],$mids2);
	$mids2=str_replace("{#price}",@$r['price'],$mids2);
	$mids2=str_replace("{#danwei}",@$r['danwei'],$mids2);
	$mids2=str_replace("{#mobile}",str_replace(substr(@$mobile,3,4),"****",@$mobile),$mids2);
	$mids2=str_replace("{#username}",@$r["username"],$mids2);
	$mids2=str_replace("{#name}",@$r["truename"],$mids2);
	if ($classid<>0 && $classid <>''&& $classid <>'empty'){
	$classids=$classid;//这里命名不要与上面的相同
	}else{
	$classids=@$r['classid'];//这里命名不要与上面的相同
	}
	if ($channel=='zhaoshang'|| $channel=='daili'|| $channel=='pinpai'|| $channel=='baojia'|| $channel=='ask'|| $channel=='job'|| $channel=='zixun'||$channel=='special'||$channel=='zhanhui'||$channel=='company'){
	//排除如help,guestbook等
	$mids2=str_replace("{#c}",getclassname($table_class,$classids,'classzm'),$mids2);
	$mids2=str_replace("{#classname}",getclassname($table_class,$classids,'classname'),$mids2);
	}
	$mids2 = $mids2 . "\r\n";
?>