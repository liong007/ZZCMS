﻿<?php
require_once '../inc/conn.php';  
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
</head>
<body>
<?php  
$id=$_GET['id'];
if ($id<>"" && $id<>0){
$pid_array=get_class_link('zzcms_zhaoshangclass',$id);//递归子类上的所有父类
$pid=$pid_array[0][0];//根父类
	$sql="select * from zzcms_shuxing where classid='". $pid ."'";
	$rs=query($sql);
	?>
	<table cellpadding="5" cellspacing="1" bgcolor="#dddddd">
	<?php
	while ($row=fetch_array($rs)){
	?>
	<tr>
      <td align="right" bgcolor="#FFFFFF"> <?php echo $row["sxname"]?></td>
      <td bgcolor="#FFFFFF">
	  <?php
	   if ($row["sxz"]<>''){
	   ?>
	   <select name='sx[]'>
	    <?php
	   $shuxing_value = explode("|",$row["sxz"]);
	for ($i=0; $i< count($shuxing_value);$i++){
	  ?>
	  <option value="<?php echo $shuxing_value[$i]?>"><?php echo $shuxing_value[$i]?></option>
	  <?php
	  }
	   ?>
	  </select>
	   <?php
	  }else{
	   ?>
	  <input name="sx[]" type="text" value="" size="45">
	   <?php
	 }
	   ?>
	  </td>
    </tr>
	<?php
	}
	}
?> 
</table>	
</body>
</html>