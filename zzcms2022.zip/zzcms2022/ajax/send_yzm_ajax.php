<?php
if(!isset($_SESSION)){session_start();} 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
</head>
<body>
<?php
require("../inc/config.php");
include '../3/mobile_msg/inc.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../3/PHPMailer/src/Exception.php';
require '../3/PHPMailer/src/PHPMailer.php';
require '../3/PHPMailer/src/SMTP.php';

if (strpos($_SESSION['getpass_method'],'@')!==false){
$getpass_methed='email';
$email=$_SESSION['getpass_method'];
}else{
$getpass_methed='mobile';
$mobile=$_SESSION['getpass_method'];
}

$yzm=rand(100000,999999);
$_SESSION['yzm_mobile']=$yzm;
$_SESSION['yzm_sendtime'] = time();
$msg="您在".sitename."请求的验证码是：".$yzm;
if ($getpass_methed=='mobile'){
$msg = iconv("UTF-8","GBK",$msg);
	$result= sendSMS(smsusername,smsuserpass,$mobile,$msg,apikey_mobile_msg);//发手机短信
	//echo $result;
	if (strpos($result,'success')!==false){
	echo "验证码已发送，请查收";
	}else{
	echo "验证码发送失败，请联系客服进行查找，客服QQ：".kfqq." 电话：".kftel."";
	}
}else{

	$tomail = $email; //收件人
	$subject = $msg;//后加网站名称后发送不成功，或延迟，应是被屏蔽了。
	$mailbody= $msg;

	$fp="../template/".siteskin."/email.htm";
		if (file_exists($fp)==false){
		tsmsg($fp.'模板文件不存在');
		exit;
		}
	$f= fopen($fp,'r');
	$strout_mail = fread($f,filesize($fp));
	fclose($f);
	$strout_mail=str_replace("{#body}",$mailbody,$strout_mail) ;
	$strout_mail=str_replace("{#siteurl}",siteurl,$strout_mail) ;
	$strout_mail=str_replace("{#logourl}",logourl,$strout_mail) ;
	$mailbody=$strout_mail;
	
	$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
//try {
    //服务器配置
    $mail->CharSet ="UTF-8";                     //设定邮件编码
    $mail->SMTPDebug = 0;                        // 调试模式输出
    $mail->isSMTP();                             // 使用SMTP
    $mail->Host = smtpserver;                // SMTP服务器
    $mail->SMTPAuth = true;                      // 允许 SMTP 认证
    $mail->Username = sender;                // SMTP 用户名  即邮箱的用户名
    $mail->Password = smtppwd;             // SMTP 密码  部分邮箱是授权码(例如163邮箱)
    $mail->SMTPSecure = 'ssl';                    // 允许 TLS 或者ssl协议
    $mail->Port = 465;                            // 服务器端口 25 或者465 具体要看邮箱服务器支持

    $mail->setFrom(sender, 'Mailer');  //发件人
    //$mail->addAddress('ellen@example.com');  // 可添加多个收件人
    $mail->addReplyTo(sender, 'info'); //回复的时候回复给哪个邮箱 建议和发件人一致
    //$mail->addCC('cc@example.com');                    //抄送
    //$mail->addBCC('bcc@example.com');                    //密送
    //发送附件
    // $mail->addAttachment('../xy.zip');         // 添加附件
    // $mail->addAttachment('../thumb-1.jpg', 'new.jpg');    // 发送附件并且重命名
    //Content
    $mail->isHTML(true);                                  // 是否以HTML文档格式发送  发送后客户端可直接显示对应HTML内容
    $mail->Subject = $subject ;
    $mail->Body    = $mailbody ;
    $mail->AltBody = '如果邮件客户端不支持HTML则显示此内容';

	$mail->addAddress($tomail, 'Joe');  // 收件人
    $ok=$mail->send();

	if($ok){
	echo "验证码已发送，请查收！<a href='http://mail.".substr($email,strpos($email,"@")+1)."' target='_blank'><b>登录邮箱</b></a>";
	}else{
	echo "验证码发送失败，请联系客服进行查找，客服QQ：".kfqq." 电话：".kftel."";
	}			
}
?>
</body>
</html>