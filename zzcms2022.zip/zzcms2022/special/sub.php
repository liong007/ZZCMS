<?php
function showzt($b,$s,$editor,$show){
$str="";
$sql="select content,id,title,img from zzcms_special where bigclassid=$b ";
if ($s!=0){
$sql=$sql." and smallclassid=$s ";
}
$sql=$sql." and editor ='".$editor."' and passed=1 order by id desc";
$rs=query($sql);
$row=num_rows($rs);
if ($row){
while ($row=fetch_array($rs)){
	if ($show==1){
	$str=$str ." <li><a href='".getpageurl("special",$row["id"])."' target='_blank'><table border='0' cellpadding='5' cellspacing='1' class='bgcolor2' height='140' width='140'><tr><td bgcolor='#ffffff' align='center'><img src='".getsmallimg($row["img"])."'></td></tr></table>".cutstr($row["title"],9)."</a></li>";
	}elseif($show==2){
	$str=$str . $row["content"];
	}elseif($show==3){
	$str=$str ." <li><a href='".getpageurl("special",$row["id"])."' target='_blank'>".$row["title"]."</a></li>";
	}
}
}else{
$str="暂无信息";
}
return $str;
}
?>