﻿<?php
require("../inc/conn.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("sub.php");
require("../inc/label.php");
$c=isset($_GET["c"])?$_GET["c"]:'';
$classname="";
if ($c<>"") {
$sql="select classname,classid,title,keyword,description from zzcms_specialclass where classzm='".$c."'";
$rs=query($sql);
$row=num_rows($rs);
	if ($row){
	$row=fetch_array($rs);
	$classname=$row["classname"];
	$cid=$row["classid"];
	$classtitle=$row["title"];
	$classkeyword=$row["keyword"];
	$classdescription=$row["description"];
	}
}

$strout=read_tpl('special_class.htm');//读取模板文件
$pagetitle=$classtitle.ztshowtitle;
$pagekeywords=$classkeyword.ztshowkeyword;
$pagedescription=$classdescription.ztshowdescription;
require("../inc/replace_tpl.php");//替换模板中的变量标签
?>