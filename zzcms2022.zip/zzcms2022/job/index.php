<?php
require("../inc/conn.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("sub.php");
require("../inc/label.php");
$strout=read_tpl('job_index.htm');//读取模板文件
$strout=str_replace("{#siteskin}",$siteskin,$strout) ;
$strout=str_replace("{#sitename}",sitename,$strout) ;
$strout=str_replace("{#pagetitle}",joblisttitle,$strout);
$strout=str_replace("{#pagekeywords}",joblistkeyword,$strout);
$strout=str_replace("{#pagedescription}",joblistdescription,$strout);
$strout=str_replace("{#sitebottom}",sitebottom(),$strout);
$strout=str_replace("{#sitetop}",sitetop(),$strout);
$strout=str_replace("{#class}",showclass('zzcms_jobclass','job',0,$cid,999),$strout) ;
$strout=showlabel($strout);
echo  $strout;
?>