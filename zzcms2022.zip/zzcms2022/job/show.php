<?php
require("../inc/conn.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("../inc/label.php");
require("sub.php");

require("../inc/get_cs_show.php");//获取参数
$sql="select * from zzcms_job where id='$id'";
$rs=query($sql);
$row=mysqli_fetch_array($rs);
if (!$row){
echo showmsg("不存在相关信息！");
}else{
query("update zzcms_job set hit=hit+1 where id='$id'");
$editor=$row["editor"];
$title=$row["title"];
$cid=$row["classid"];
$sendtime=$row["sendtime"];
$hit=$row["hit"];
$sm=$row["sm"];
$province=$row["province"];
$city=$row["city"];

$sql="select * from zzcms_user where username='".$editor."'";
$rs=query($sql);
$row=mysqli_fetch_array($rs);
$startdate=$row["startdate"];
$comane=$row["comane"];
$classid=$row["classid"];
$somane=$row["somane"];
$userid=$row["id"];
$groupid=$row["groupid"];
$sex=$row["sex"];
$phone=$row["phone"];
$fox=$row["fox"];
$mobile=$row["mobile"];
$qq=$row["qq"];
$email=$row["email"];
$contact=showcontact("job",$id,$startdate,$comane,$classid,$editor,$userid,$groupid,$somane,$sex,$phone,$qq,$email,$mobile,$fox);
$strout=read_tpl('job_show.htm');//读取模板文件
$strout=str_replace("{#title}",$title,$strout);
$strout=str_replace("{#comane}",$comane,$strout);
$strout=str_replace("{#sendtime}",$sendtime,$strout);
$strout=str_replace("{#hit}",$hit,$strout);
$strout=str_replace("{#province}",$province,$strout);
$strout=str_replace("{#city}",$city,$strout);
$strout=str_replace("{#email}",$email,$strout);
$strout=str_replace("{#sm}",nl2br($sm),$strout);
$strout=str_replace("{#contact}",$contact,$strout);
$strout=str_replace("{#editor}",$editor,$strout);

$pagetitle=$title.jobshowtitle;
$pagekeywords=$title.jobshowkeyword;
$pagedescription=$title.jobshowdescription;
require("../inc/replace_tpl.php");//替换模板中的变量标签
}
?>