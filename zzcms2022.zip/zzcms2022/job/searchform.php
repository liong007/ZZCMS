<?php
require("../inc/conn.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="/template/<?php echo siteskin?>/style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
body {
	margin: 0px;
	padding: 0px;
	font-size: 12px;
	background:transparent
}
-->
</style>
</head>
<body>
<form action="/job/search.php" method="get" name="myform" id="myform" target="_parent">
<table border="0" cellpadding="5" cellspacing="0">
  <tr>
    <td>
      <?php
        $rs=get_class_list("zzcms_jobclass");
        $str="<select name='c' class='biaodan' style='width:230px'>";
        foreach ($rs as $key => $val) {
			if ($val['classzm']==@$_COOKIE['c']) { 
            $str.="<option selected value={$val['classzm']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classzm']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?>
   </td>
  </tr>
  <tr>
    <td>
<select name="province" id="province" style="width:230px" class="biaodan"></select></td>
  </tr>
  <tr>
    <td>
	<select name="city" id="city" style="width:230px" class="biaodan"></select>	  </td>
  </tr>
  <tr>
    <td><select name="xiancheng" id="xiancheng" style="width:230px" class="biaodan"></select>
	<script src="/js/areas.js"></script>
	<script src="/js/area.js"></script>
<script type="text/javascript">
new PCAS('province', 'city', 'xiancheng', '', '', '');
</script>	</td>
  </tr>
  <tr>
    <td><label><input type="radio" name="yiju" value="Pname" />职位</label>
      <label><input name="yiju" type="radio" value="Pcompany" />企业</label>
	  <input name="keyword" type="text"  id="keyword" value="" size="25" maxlength="255" class="biaodan" style="width:100px"/>
      <input name="Submit3" type="submit"  value="搜索"/></td>
  </tr>
</table>
</form>
</body>
</html>