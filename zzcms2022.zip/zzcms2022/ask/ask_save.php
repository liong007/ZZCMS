<?php
if(!isset($_SESSION)){session_start();} 
require("../inc/conn.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="../template/<?php echo siteskin?>/style.css" rel="stylesheet" type="text/css">
<body>
<div class="main" >
<?php
if($yzm!=$_SESSION["yzm_math"]){showmsg('验证问题答案错误！','back');}
session_write_close();
$about=$_POST["about"];
$content=safe_replace($_POST["content"]);
$face=@$_POST["face"];
$user=$_POST["user"];
if ($user==''){$user='youke';}
checkstr($user,'username');
$ip=trim($_POST["ip"]);
checkstr($ip,'ip');
$FoundErr=0;
$ErrMsg="";
	if ($content==''){
	$FoundErr=1;
	$ErrMsg=$ErrMsg."<li>内容不能为空</li>";
	}
	
	$rs=query("select * from zzcms_answer where about='$about' and editor='$user' and ip='$ip' and content='$content'");
	$row=num_rows($rs);
	if ($row){
	$FoundErr=1;
	$ErrMsg=$ErrMsg."<li>您已回答过了！</li>";
	}

	if ($FoundErr==1){
	tsmsg($ErrMsg);
	}else{
	$isok=query("insert into zzcms_answer (about,content,face,editor,ip,passed,sendtime)values('$about','$content','$face','$user','$ip',1,'".date('Y-m-d H:i:s')."')");
	
	if ($isok){
	echo "<script>alert('提交成功，感谢参与');history.back(-1)</script>";
	}else{
	echo "<script>alert('失败提交');history.back(-1)</script>";
	}
	}	
?>
</div>
</body>
</html>