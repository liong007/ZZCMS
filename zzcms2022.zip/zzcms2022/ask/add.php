<?php
session_start();//用到验证码这里必须得打开，否则无效 
require("../inc/conn.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>提问-<?php echo sitetitle?></title>
<link href="/template/<?php echo siteskin?>/style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/js/jquery.js"></script>
<script>
function CheckForm(){
if (document.myform2.title.value==""){
    alert("请填写标题！");
	document.myform2.title.focus();
	return false;
  }
}

$(function(){
$("#getcode_math").click(function(){
		$(this).attr("src",'/one/code_math.php?' + Math.random());
	});
});
</script>
</head>
<body>
<?php
if (isset($_POST["action"])){
if($yzm!=$_SESSION["yzm_math"]){showmsg('验证问题答案错误！','add.php');}
session_write_close();
$ip=getip();
$img=getimgincontent(stripfxg($content,true));
checkstr($img,"upload");//入库前查上传文件地址是否合格

$FoundErr=0;$ErrMsg="";
if ($title==''){
$FoundErr=1;
$ErrMsg=$ErrMsg."<li>标题不能为空</li>";
}
	
$rs=query("select id from zzcms_ask where title='$title' and ip='$ip'");
$row=num_rows($rs);
if ($row){
$FoundErr=1;
$ErrMsg=$ErrMsg."<li>重复的信息，发布失败！</li>";
}

	if ($FoundErr==1){
	tsmsg($ErrMsg);
	}else{
	$isok=query("Insert into zzcms_ask(classid,title,content,img,jifen,editor,ip,passed,sendtime)values('$classid','$title','$content','$img','0','未登陆用户','$ip',0,'".date('Y-m-d H:i:s')."')");  
	if ($isok){
	echo showmsg('发布成功，审核后显示。','back','noexit');
	}else{
	echo showmsg('发布失败！','back','noexit');
	}
	setcookie("askclassid",$classid,time()+3600*24,"ask");
	}  
}else{	
require("../inc/top2.php");
echo sitetop();
?>
<div class="main">
<div class="pagebody">
<div class="titles">提问</div>
<div class="content">
<form action="?" method="post" name="myform2" id="myform2" onSubmit="return CheckForm();">      
  <table width="100%" border="0" cellpadding="8" cellspacing="1">
    <tr> 
      <td width="130" align="right" class="border2">类别 <font color="#FF0000">*</font></td>
      <td class="border2"><span class="border">
        <?php
        $rs=get_class_list("zzcms_askclass");
        $str="<select name='classid' id='classid'>";
		$str.="<option value=0>请选择类别</option>";
        foreach ($rs as $key => $val) {
			if ($val['classid']==@$_COOKIE['askclassid']) { 
            $str.="<option selected value={$val['classid']}>{$val['classname']}</option>";
			}else{
			$str.="<option value={$val['classid']}>{$val['classname']}</option>";
			}
        }
        $str.="</select>";
        echo  $str;
		?>
      </span></td>
    </tr>
    <tr>
      <td align="right" class="border">问题 <font color="#FF0000">*</font></td>
      <td class="border"><input name="title" type="text" id="title" size="45" maxlength="45" value="<?php echo @$_POST['keyword']?>"/>      </td>
    </tr>
	
    <tr> 
    <td align="right" class="border2">内容：</td>      
    <td class="border2">
	<textarea name="content" id="content"></textarea> 
    <script type="text/javascript" src="/3/ckeditor/ckeditor.js"></script>
	<script type="text/javascript">CKEDITOR.replace('content');</script>	</td>
    </tr>
    <tr>
      <td align="right">答案：</td>
      <td><input name="yzm" type="text" id="yzm" value="" size="10" maxlength="50" style="width:60px"/>
          <img src="/one/code_math.php" id="getcode_math" title="看不清，点击换一张" align="absmiddle"> </td>
    </tr>
    <tr> 
      <td align="right" class="border">&nbsp;</td>
      <td class="border"> 
        <input name="Submit" type="submit" class="button_big" value="发 布">
        <input name="action" type="hidden" id="action3" value="add"></td>
    </tr>
  </table>
</form>

</div>
</div>
</div>
<?php
require("../inc/bottom.php");
echo sitebottom();
}
?>
</body>
</html>