<?php
require("../inc/conn.php");
require("sub.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("../inc/label.php");

require("../inc/get_cs_show.php");//获取参数
$sql="select * from zzcms_pinpai where id='$id'";
$rs=query($sql);
$row=fetch_array($rs);
if (!$row){
echo showmsg("不存在相关信息！");
}else{
query("update zzcms_pinpai set hit=hit+1 where id='$id'");
$editor=$row["editor"];
$title=$row["title"];
$img=$row["img"];
$imgs="<img src='".getsmallimg($row["img"])."' onload='resizeimg(70,70,this)'>";

$cid=$row["classid"];
$sendtime=$row["sendtime"];
$hit=$row["hit"];
$sm=$row["content"];
$comane=$row["comane"];

$sql="select * from zzcms_user where username='".$editor."'";
$rs=query($sql);
$row=fetch_array($rs);
$startdate=$row["startdate"];
$comane=$row["comane"];
$kind=$row["classid"];
$somane2=$row["somane"];
$userid=$row["id"];
$groupid=$row["groupid"];
$sex=$row["sex"];
$phone2=$row["phone"];
$fox2=$row["fox"];
$mobile2=$row["mobile"];
$qq2=$row["qq"];
$email2=$row["email"];

$contact=showcontact("pinpai",$id,$startdate,$comane,$kind,$editor,$userid,$groupid,$somane2,$sex,$phone2,$qq2,$email2,$mobile2,$fox2);
$strout=read_tpl('pinpai_show.htm');//读取模板文件
//dlform
$companyname="";$somane="";$phone="";$email="";
if (isset($_COOKIE["UserName"])) {
$rsn=query("select * from zzcms_user where username='".trim($_COOKIE["UserName"])."'");
$rown=fetch_array($rsn);
$companyname=$rown["comane"];
$somane=$rown["somane"];
$phone=$rown["phone"];
$email=$rown["email"];
}

$strout=str_replace("{textarea}","<textarea id='contents' rows=6 cols=30 name='contents' onfocus='check_contents()' onblur='check_contents()'>愿加盟“".$title."”这个品牌，请与我联系。</textarea>",$strout) ;
$strout=str_replace("{#companyname}",$companyname,$strout) ;
$strout=str_replace("{#somane}",$somane,$strout) ;
$strout=str_replace("{#phone}",$phone,$strout);
$strout=str_replace("{#email}",$email,$strout);
$strout=str_replace("{#editor}",$editor,$strout);
$strout=str_replace("{#img}",$img,$strout);
$strout=str_replace("{#imgs}",$imgs,$strout);
$strout=str_replace("{#cpid}",$id,$strout);
$strout=str_replace("{#title}",$title,$strout);
$strout=str_replace("{#comane}",$comane,$strout);
$strout=str_replace("{#sendtime}",$sendtime,$strout);
$strout=str_replace("{#hit}",$hit,$strout);
$strout=str_replace("{#sm}",nl2br($sm),$strout);
$strout=str_replace("{#contact}",$contact,$strout);

$pagetitle=$title.ppshowtitle;
$pagekeywords=$title.ppshowkeyword;
$pagedescription=$title.ppshowdescription;
require("../inc/replace_tpl.php");//替换模板中的变量标签
}
?>