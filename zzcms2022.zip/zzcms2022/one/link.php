<?php
require("../inc/conn.php");
require("../inc/top2.php");
require("../inc/bottom.php");
require("../inc/label.php");
if (isset($_REQUEST["action"])=="add"){
checkyzm($_POST["yzm"]);
$sitename = isset($_POST['sitename'])?$_POST['sitename']:"";
$url = isset($_POST['url'])?addhttp($_POST['url']):"";
$logo = isset($_POST['logo'])?addhttp($_POST['logo']):"";
$content = isset($_POST['content'])?$_POST['content']:"";

if ($sitename==''||$url==''||$logo==''||$content==''){
	showmsg('请完整填写您的信息');
}

query("insert into zzcms_link (sitename,url,logo,content,sendtime)values('$sitename','$url','$logo','$content','".date('Y-m-d H:i:s')."')");
showmsg('操作成功！提示：提交申请后，请做好本站链接——如果没有增加本站的链接，那么你的申请是不会被通过的。','link.php') ;
}

$strout=read_tpl('link.htm');//读取模板文件
$strout=str_replace("{#siteskin}",$siteskin,$strout) ;
$strout=str_replace("{#sitename}",sitename,$strout) ;
$strout=str_replace("{#siteurl}",siteurl,$strout) ;
$strout=str_replace("{#logourl}",logourl,$strout) ;
$strout=str_replace("{#sitebottom}",sitebottom(),$strout);
$strout=str_replace("{#sitetop}",sitetop(),$strout);
$strout=showlabel($strout);
echo  $strout;
?>