<?php
$t1 = microtime(true);
require("../inc/conn.php");
require("../inc/fy.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("sub.php");
require("../inc/label.php");
if( isset($_GET["page"]) && $_GET["page"]!="") {$page=$_GET['page'];}else{$page=1;}
checkid($page);
$c=isset($_GET["c"])?$_GET["c"]:'';
if ($c!=''){
$f="../html/".$siteskin."/daili/".$c."/".$page.".html";
}else{
$f="../html/".$siteskin."/daili/".$page.".html";
}
if (html_update_time!=0 && file_exists($f) && time()-filemtime($f)<3600*24*html_update_time) {
echo file_get_contents($f);//第三种方法,这种比require("$f")打开速度要快很多
}else{
$strout=read_tpl("daili_list.htm");
require("../inc/get_cs.php");//获取参数
$pagetitle=@$province.$classname.dllisttitle."-".sitename;
$pagekeywords=@$province.$classname.dllistkeyword."-".sitename;
$pagedescription=@$province.$classname.dllistdescription."-".sitename;

if ($c<>""){
$tables="zzcms_daili".$cid;//这里有命名不要与showclass中的重名
	if(mysqli_num_rows(query("SHOW TABLES LIKE '".$tables."'"))<>1) {
	addtable("zzcms_daili",$cid);//加表
	}
}else{
$tables="zzcms_daili";
}

	$sql="select count(*) as total from `$tables` where passed<>0 ";
	$sql2='';
	//if ($c<>"") {
	//$sql2=$sql2. " and classid={$cid}";
	//}
	
	if (liuyanysnum!=0){//最好是设成0，当数据量大时，查寻会变慢
	$liuyanysnum=liuyanysnum*3600*24;
	$sql2=$sql2. " and  not exists (select id from `$tables` where savergroupid>1 and unix_timestamp()-unix_timestamp(sendtime)<$liuyanysnum) ";
	}

if (@$province<>""){
$sql2=$sql2." and province ='".$province."' ";
}

$rs =query($sql.$sql2); 
$row = fetch_array($rs);
$totlenum = $row['total'];
$offset=($page-1)*$page_size;
$totlepage=ceil($totlenum/$page_size);

$sql="select id,title,truename,province,city,xiancheng,content,tel,sendtime,saver from `$tables` where passed<>0 ";
$sql=$sql.$sql2;
$sql=$sql." order by id desc limit $offset,$page_size";
//echo $sql.'<br>';
$rs = query($sql);   //MYSQLI_USE_RESULT默认为MYSQLI_STORE_RESULT这种模式，全部读入到内存。

$dl=strbetween($strout,"{dl}","{/dl}");
$dllist=strbetween($strout,"{loop}","{/loop}");
$content_num=strbetween($dllist,"{#content:","}");
if(!$totlenum){
$strout=str_replace("{dl}".$dl."{/dl}","暂无信息",$strout) ;
}else{
$i=0;
$dllist2='';
while($row= fetch_array($rs)){

$dllist2 = $dllist2. str_replace("{#id}" ,$row["id"],$dllist) ;

if ($i % 2==0) {
$dllist2=str_replace("{changebgcolor}" ,"class=bgcolor1",$dllist2) ;
}else{
$dllist2=str_replace("{changebgcolor}" ,"class=bgcolor2",$dllist2) ;
}
$dllist2 = str_replace("{#title}" ,"<a href='".getpageurl("daili",$row["id"])."'>".cutstr($row["title"],8)."</a> ",$dllist2) ;

if ($row["saver"]<>"") {
	$rsn=query("select comane,id from zzcms_user where username='".$row["saver"]."'");
	$r=mysqli_num_rows($rsn);
	if ($r){
	$r=fetch_array($rsn);
	$gs="<a href='".getpageurlzt($row["saver"],$r["id"])."'>".cutstr($r["comane"],6)."</a> ";
	}else{
	$gs="不存在该公司信息";
	}		
}else{
$gs="无意向公司";
}

if (isshowcontact=="Yes"){
$tel= $row["tel"];
}else{
$tel="<a style='color:red' href='".getpageurl("daili",$row["id"])."'>VIP点击可查看</a>";
}

$dllist2 = str_replace("{#gs}" ,$gs,$dllist2) ;
$dllist2 = str_replace("{#dls}" ,$row["truename"],$dllist2) ;
$dllist2 = str_replace("{#qy}" ,$row["province"]."&nbsp;".$row["city"]."&nbsp;".$row["xiancheng"],$dllist2) ;
$dllist2 = str_replace("{#tel}" ,$tel,$dllist2) ;
$dllist2 = str_replace("{#content:".$content_num."}",cutstr($row["content"],$content_num),$dllist2) ;
$dllist2 = str_replace("{#content}" ,cutstr($row["content"],10),$dllist2) ;
$dllist2 = str_replace("{#sendtime}" ,date("Y-m-d",strtotime($row["sendtime"])),$dllist2) ;
$i=$i+1;
}
//mysqli_free_result($rs);//释放记录集，经测试，会稍微拖慢几毫秒的速度
$strout=str_replace("{loop}".$dllist."{/loop}",$dllist2,$strout) ;
$strout=str_replace("{#fenyei}",showpage2("daili"),$strout) ;//采用showpage3倒显分页，可解决只生成新页，老页信息不变，缺点是当无大类不用缓存时大页码打开时慢，而到后面的小页码反页快。
$strout=str_replace("{dl}","",$strout) ;
$strout=str_replace("{/dl}","",$strout) ;
}//end if(!$totlenum)

require("../inc/replace_tpl.php");//替换模板中的变量标签
if (html_update_time!=0 ){
	if ($c<>''){
		$fpath=zzcmsroot."html/".$siteskin."/daili/".$c."/".$page.".html";
		if (!file_exists(zzcmsroot."html/".$siteskin."/daili/".$c)) {
		mkdir(zzcmsroot."html/".$siteskin."/daili/".$c,0777, true);
		}
	}else{
		if (!file_exists(zzcmsroot."html/".$siteskin."/daili")) {
		mkdir(zzcmsroot."html/".$siteskin."/daili",0777, true);
		}
		$fpath=zzcmsroot."html/".$siteskin."/daili/".$page.".html";
	}
	$fp=@fopen($fpath,"w+");//fopen()的其它开关请参看相关函数
	fputs($fp,stripfxg($strout));//写入文件
	fclose($fp);
}

}//end if(html_update_time!=0 && file_exists($f) && time()-filemtime($f)<3600*24*30)
//mysqli_close($conn);
$t2 = microtime(true);
//echo '耗时'.round($t2-$t1,3).'秒';
?>