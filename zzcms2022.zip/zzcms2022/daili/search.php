<?php
$t1 = microtime(true);
require("../inc/conn.php");
require("../inc/fy.php");
require("../inc/top.php");
require("../inc/bottom.php");
require("sub.php");
require("../inc/label.php");
require("../inc/get_cs_search.php");//获取参数
$strout=read_tpl('daili_search.htm');//读取模板文件

$dl_download_url="form1.action='/daili/download.php'";
$dl_print_url="form1.action='/daili/print.php'";
$dl_sendmail_url="form1.action='/daili/sendmail.php'";
$dl_sendsms_url="form1.action='/daili/sendsms.php'";
$buttontype="submit";

$strout=str_replace("{#dl_download_url}",$dl_download_url,$strout) ;
$strout=str_replace("{#dl_print_url}",$dl_print_url,$strout) ;
$strout=str_replace("{#dl_sendmail_url}",$dl_sendmail_url,$strout) ;
$strout=str_replace("{#dl_sendsms_url}",$dl_sendsms_url,$strout) ;
$strout=str_replace("{#buttontype}",$buttontype,$strout) ;		

if ($c<>"") {
	$sql="select count(*) as total from zzcms_daili where classid='$cid' ";
}else{
	$sql="select count(*) as total from zzcms_daili where passed<>0 ";
}
$sql2='';
if ($keyword<>"" && $keyword<>"输入".channeldl."产品名称") {
$sql2=$sql2." and title like '%".$keyword."%' ";
}
if ($province<>"") {
$sql2=$sql2." and province = '".$province."' ";
}
if ($city<>"" ){
$sql2=$sql2." and city ='".$city."' ";
}
if ($xiancheng<>"" ){
$sql2=$sql2." and xiancheng like '".$xiancheng."%' ";
}
	
//echo $sql;
$dl=strbetween($strout,"{dl}","{/dl}");
$dllist=strbetween($strout,"{loop}","{/loop}");

$rs =query($sql.$sql2); 
$row = fetch_array($rs);
$totlenum = $row['total'];
$offset=($page-1)*$page_size;//$page_size在上面被设为COOKIESS
$totlepage=ceil($totlenum/$page_size);
if ($c<>"") {
$sql="select id,title,truename,province,city,xiancheng,content,tel,sendtime,saver from zzcms_daili where classid=$cid ";
}else{
$sql="select id,title,truename,province,city,xiancheng,content,tel,sendtime,saver from zzcms_daili where passed=1 ";
}
$sql=$sql.$sql2;
$sql=$sql." order by id desc limit $offset,$page_size";
$rs = query($sql); 
if(!$totlenum){
$strout=str_replace("{dl}".$dl."{/dl}","暂无信息",$strout) ;
}else{
$i=0;$dllist2='';
while($row= fetch_array($rs)){
$dllist2 = $dllist2. str_replace("{#id}" ,$row["id"],$dllist) ;
if ($i % 2==0) {
$dllist2=str_replace("{changebgcolor}" ,"class=bgcolor1",$dllist2) ;
}else{
$dllist2=str_replace("{changebgcolor}" ,"class=bgcolor2",$dllist2) ;
}
$dllist2 = str_replace("{#title}" ,"<a href='".getpageurl("daili",$row["id"])."'>".cutstr($row["title"],8)."</a> ",$dllist2) ;
if ($row["saver"]<>"") {
	$rsn=query("select comane,id from zzcms_user where username='".$row["saver"]."'");
	$r=num_rows($rsn);
	if ($r){
	$r=fetch_array($rsn);
	$gs="<a href='".getpageurl("zhanting",$r["id"])."'>".cutstr($r["comane"],6)."</a> ";
	}else{
	$gs="不存在该公司信息";
	}		
}else{
$gs="无意向公司";
}

if (isshowcontact=="Yes"){
$tel= $row["tel"];
}else{
$tel="<a style='color:red' href='".getpageurl("daili",$row["id"])."'>VIP点击可查看</a>";
}

$dllist2 = str_replace("{#gs}" ,$gs,$dllist2) ;
$dllist2 = str_replace("{#dls}" ,$row["truename"],$dllist2) ;
$dllist2 = str_replace("{#qy}" ,$row["province"]."&nbsp;".$row["city"]."&nbsp;".$row["xiancheng"],$dllist2) ;
$dllist2 = str_replace("{#tel}" ,$tel,$dllist2) ;
$dllist2 = str_replace("{#content}" ,cutstr($row["content"],16),$dllist2) ;
$dllist2 = str_replace("{#sendtime}" ,date("Y-m-d",strtotime($row["sendtime"])),$dllist2) ;
$i=$i+1;
}
$strout=str_replace("{loop}".$dllist."{/loop}",$dllist2,$strout) ;
$strout=str_replace("{#fenyei}",showpage1(),$strout) ;
$strout=str_replace("{dl}","",$strout) ;
$strout=str_replace("{/dl}","",$strout) ;
}

if ($province=="") {
$strout=str_replace("{#formprovince}",formprovince(),$strout);
}else{
$strout=str_replace("{#formprovince}","",$strout);
}
if ($city=="") {
$strout=str_replace("{#formcity}",formcity(),$strout);
}else{
$strout=str_replace("{#formcity}","",$strout);
}

$strout=str_replace("{#formxiancheng}",formxiancheng(),$strout);
$strout=str_replace("{#keyword}",$keyword,$strout);
$strout=str_replace("{#selected}",$selected,$strout);
$strout=str_replace("{#dllist}",$dllist,$strout);

$pagetitle=$province.$classname.dllisttitle."-".sitename;
$pagekeywords=$province.$classname.dllisttitle."-".sitename;
$pagedescription=$province.$classname.dllistdescription."-".sitename;
require("../inc/replace_tpl.php");//替换模板中的变量标签

$t2 = microtime(true);
echo '耗时'.round($t2-$t1,3).'秒';	
?>